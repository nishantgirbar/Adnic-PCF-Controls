/// <reference types="powerapps-component-framework" />
import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class CustomListOfMembersB2E implements ComponentFramework.StandardControl<IInputs, IOutputs> {

  private container!: HTMLDivElement;
  private members: any[] = [];
  private notifyOutputChanged!: () => void;

  private currentPage = 1;
  private pageSize = 10;

  private gridRef!: HTMLDivElement;
  private paginationRef!: HTMLDivElement;

  private lastRaw: string | null = null;

  private enableUpload: boolean = false;

  public init(context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    state: ComponentFramework.Dictionary,
    container: HTMLDivElement): void {

    this.container = container;
    this.notifyOutputChanged = notifyOutputChanged;

    const wrapper = document.createElement("div");
    wrapper.className = "b2e-members-root";

    const actionBar = document.createElement("div");
    actionBar.className = "action-bar";

    const addBtn = document.createElement("button");
    addBtn.innerText = "Add Row";
    addBtn.className = "btn primary";

    addBtn.onclick = () => {
      this.members.push({
        relation: "",
        gender: "",
        dateOfBirth: "",
        salaryType: "",
        visaLocation: "",
        category: "",
        maritalStatus: "",
        document: "",
        documentName: ""
      });
      this.notifyOutputChanged();
      this.refresh();
    };

    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "Delete Selected";
    deleteBtn.className = "btn subtle";

    deleteBtn.onclick = () => {
      const checkboxes = this.container.querySelectorAll<HTMLInputElement>(".row-checkbox");
      this.members = this.members.filter((_, i) => !checkboxes[i]?.checked);
      this.notifyOutputChanged();
      this.refresh();
    };

    actionBar.appendChild(addBtn);
    actionBar.appendChild(deleteBtn);

    const grid = document.createElement("div");
    const pagination = document.createElement("div");
    pagination.className = "pagination";

    this.gridRef = grid;
    this.paginationRef = pagination;

    wrapper.appendChild(actionBar);
    wrapper.appendChild(grid);
    wrapper.appendChild(pagination);

    this.container.appendChild(wrapper);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {

    this.enableUpload = context.parameters.enableUpload.raw ?? false;

    const raw = context.parameters.memberData.raw;

    if (raw !== this.lastRaw) {
      this.lastRaw = raw;

      try {
        this.members = raw ? JSON.parse(raw) : [];
      } catch {
        this.members = [];
      }

      this.currentPage = 1;
      this.notifyOutputChanged();
    }

    this.refresh();
  }

  private getAge(dob: string): number {
    if (!dob) return 0;

    const birth = new Date(dob);
    const today = new Date();

    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;

    return age;
  }

  private refresh(): void {
    this.renderGrid(this.gridRef);
    this.renderPagination(this.paginationRef);
  }

  private renderGrid(container: HTMLDivElement): void {

    container.innerHTML = "";

    if (this.members.length === 0) {
      container.innerHTML = `<div class="empty-state">No members available</div>`;
      return;
    }

    const scroll = document.createElement("div");
    scroll.className = "grid-scroll";

    const grid = document.createElement("div");
    grid.className = "grid-container";

    const headers = ["", "#", "Relation", "Gender", "DOB", "Salary", "Visa", "Category", "Marital"];

    headers.forEach(h => {
      const d = document.createElement("div");
      d.className = "grid-header";
      d.innerText = h;
      grid.appendChild(d);
    });

    const start = (this.currentPage - 1) * this.pageSize;
    const rows = this.members.slice(start, start + this.pageSize);

    const createDropdown = (options: string[], value: string, field: string, idx: number) => {
      const select = document.createElement("select");
      select.className = "dropdown";

      options.forEach(o => {
        const opt = document.createElement("option");
        opt.value = o;
        opt.innerText = o;
        if (o === value) opt.selected = true;
        select.appendChild(opt);
      });

      select.onchange = () => {
        this.members[idx][field] = select.value;
        this.notifyOutputChanged();
      };

      return select;
    };

    rows.forEach((row, i) => {

      const idx = start + i;

      const cell = (el: HTMLElement | string) => {
        const d = document.createElement("div");
        d.className = "grid-cell";
        typeof el === "string" ? d.innerText = el : d.appendChild(el);
        return d;
      };

      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.className = "row-checkbox";

      grid.appendChild(cell(cb));
      grid.appendChild(cell((idx + 1).toString()));

      grid.appendChild(cell(createDropdown(["EMPLOYEE","SELF","SPOUSE","CHILD"], row.relation, "relation", idx)));
      grid.appendChild(cell(createDropdown(["Male","Female"], row.gender, "gender", idx)));

      const dob = document.createElement("input");
      dob.type = "date";
      dob.className = "date-input";
      dob.value = row.dateOfBirth || "";

      dob.onchange = () => {
        this.members[idx].dateOfBirth = dob.value;
        this.notifyOutputChanged();
        this.refresh();
      };

      grid.appendChild(cell(dob));

      grid.appendChild(cell(createDropdown(["Enhanced","LSB","USB"], row.salaryType, "salaryType", idx)));
      grid.appendChild(cell(createDropdown(["DXB","AUH","SHJ"], row.visaLocation, "visaLocation", idx)));
      grid.appendChild(cell(createDropdown(["A","B","C"], row.category, "category", idx)));
      grid.appendChild(cell(createDropdown(["Single","Married"], row.maritalStatus, "maritalStatus", idx)));

      const age = this.getAge(row.dateOfBirth);

      if (age > 65 && this.enableUpload) {

        const uploadRow = document.createElement("div");
        uploadRow.className = "upload-row";
        uploadRow.style.gridColumn = "1 / -1";

        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.style.display = "none";

        const btn = document.createElement("button");
        btn.className = "upload-btn";
        btn.innerHTML = `Upload`;

        const name = document.createElement("div");
        name.className = "file-name";

        btn.onclick = () => fileInput.click();

        fileInput.onchange = () => {
          const file = fileInput.files?.[0];
          if (!file) return;

          const reader = new FileReader();
          reader.onload = () => {
            this.members[idx].document = reader.result;
            this.members[idx].documentName = file.name;
            name.innerText = file.name;
            this.notifyOutputChanged();
          };
          reader.readAsDataURL(file);
        };

        uploadRow.appendChild(btn);
        uploadRow.appendChild(fileInput);
        uploadRow.appendChild(name);

        grid.appendChild(uploadRow);
      }
    });

    scroll.appendChild(grid);
    container.appendChild(scroll);
  }

  private renderPagination(container: HTMLDivElement): void {

    const total = this.members.length;
    const totalPages = Math.ceil(total / this.pageSize);

    container.innerHTML = "";

    const info = document.createElement("div");
    info.innerText = `Showing ${total === 0 ? 0 : (this.currentPage - 1) * this.pageSize + 1} to ${Math.min(this.currentPage * this.pageSize, total)} of ${total}`;

    const controls = document.createElement("div");

    const prev = document.createElement("button");
    prev.innerText = "Previous";
    prev.disabled = total === 0 || this.currentPage <= 1;

    const next = document.createElement("button");
    next.innerText = "Next";
    next.disabled = total === 0 || this.currentPage >= totalPages;

    prev.onclick = () => { this.currentPage--; this.refresh(); };
    next.onclick = () => { this.currentPage++; this.refresh(); };

    controls.appendChild(prev);
    controls.appendChild(next);

    container.appendChild(info);
    container.appendChild(controls);
  }

  public getOutputs(): IOutputs {
    return {
      memberData: JSON.stringify(this.members)
    };
  }

  public destroy(): void {}
}
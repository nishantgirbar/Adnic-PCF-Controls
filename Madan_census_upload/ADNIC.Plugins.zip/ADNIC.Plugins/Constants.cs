﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    internal class Constants
    {
        internal const string CensusMemberUpdate = "CensusMemberUpdate";
        internal const string CensusMemberDelete = "CensusMemberDelete";
        internal const string CensusUpload = "CensusUpload";
        internal const string AfterValidation = "AfterValidation";
        internal const string PolicyIssuance = "PolicyIssuance";

        internal const string MasterData_MARITAL_STATUS = "marital_status";
        internal const string MasterData_Gender = "gender";
        internal const string MasterData_COMMISSION = "commission";
        internal const string MasterData_Category = "category";
        internal const string MasterData_CITY_EMIRATES = "city_emirates";
        internal const string MasterData_Countries = "countries";
        internal const string MasterData_Visa_Type = "visa_type";
        internal const string MasterData_Visa_Emirate = "city_emirates";
        internal const string MasterData_Work_Location = "work_location";
        internal const string MasterData_SPONSER_TYPE = "sponser_type";
        internal const string MasterData_Member_Category = "member_category";

       internal const int Active = 0;
       internal const int Inactive = 1;
    }
}

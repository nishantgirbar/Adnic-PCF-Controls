﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ADNIC.Plugins
{
    public class Member
    {
        [JsonPropertyName("rowNumber")]
        public int RowNumber { get; set; }

        [JsonPropertyName("relation")]
        public string Relation { get; set; }

        [JsonPropertyName("gender")]
        public string Gender { get; set; }

        [JsonPropertyName("dateOfBirth")]
        public string DateOfBirth { get; set; }

        [JsonPropertyName("salaryType")]
        public string SalaryType { get; set; }

        [JsonPropertyName("visaLocation")]
        public string VisaLocation { get; set; }

        [JsonPropertyName("maritalStatus")]
        public string MaritalStatus { get; set; }

        [JsonPropertyName("requiresMedicalUnderwriting")]
        public bool RequiresMedicalUnderwriting { get; set; }

        [JsonPropertyName("srNo")]
        public int SrNo { get; set; }

        [JsonPropertyName("pfNo")]
        public string PfNo { get; set; }

        [JsonPropertyName("memberNo")]
        public string MemberNo { get; set; }

        [JsonPropertyName("memberName")]
        public string MemberName { get; set; }

        [JsonPropertyName("dependency")]
        public string Dependency { get; set; }

        [JsonPropertyName("effectiveDate")]
        public string EffectiveDate { get; set; }

        [JsonPropertyName("previousCoverageDate")]
        public string PreviousCoverageDate { get; set; }

        [JsonPropertyName("changeOfStatusDate")]
        public string ChangeOfStatusDate { get; set; }

        [JsonPropertyName("emiratesId")]
        public string EmiratesId { get; set; }

        [JsonPropertyName("eidApplicationNo")]
        public string EidApplicationNo { get; set; }

        [JsonPropertyName("entryPermitNo")]
        public string EntryPermitNo { get; set; }

        [JsonPropertyName("visaType")]
        public string VisaType { get; set; }

        [JsonPropertyName("visaEmirate")]
        public string VisaEmirate { get; set; }

        [JsonPropertyName("classNo")]
        public string ClassNo { get; set; }

        [JsonPropertyName("nationality")]
        public string Nationality { get; set; }

        [JsonPropertyName("passportNo")]
        public string PassportNo { get; set; }

        [JsonPropertyName("uidNo")]
        public string UidNo { get; set; }

        [JsonPropertyName("mobileNo")]
        public string MobileNo { get; set; }

        [JsonPropertyName("emailId")]
        public string EmailId { get; set; }

        [JsonPropertyName("thiqaCardNo")]
        public string ThiqaCardNo { get; set; }

        [JsonPropertyName("position")]
        public string Position { get; set; }

        [JsonPropertyName("workLocation")]
        public string WorkLocation { get; set; }

        [JsonPropertyName("residenceLocation")]
        public string ResidenceLocation { get; set; }

        [JsonPropertyName("memberCategory")]
        public string MemberCategory { get; set; }

        [JsonPropertyName("salaryBand")]
        public string SalaryBand { get; set; }

        [JsonPropertyName("commission")]
        public string Commission { get; set; }

        [JsonPropertyName("birthCertificateId")]
        public string BirthCertificateId { get; set; }

        [JsonPropertyName("sponsorType")]
        public string SponsorType { get; set; }

        [JsonPropertyName("sponsorId")]
        public string SponsorId { get; set; }

        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("height")]
        public string Height { get; set; }

        [JsonPropertyName("weight")]
        public string Weight { get; set; }

        [JsonPropertyName("documentStatus")]
        public string DocumentStatus { get; set; }

        [JsonPropertyName("entrantType")]
        public string EntrantType { get; set; }

        [JsonPropertyName("entryDate")]
        public string EntryDate { get; set; }

        [JsonPropertyName("recordStatus")]
        public string RecordStatus { get; set; }

        [JsonPropertyName("validationErrors")]
        public List<string> ValidationErrors { get; set; }
    }
}

﻿using System.Text.Json.Serialization;

namespace ADNIC.Plugins
{
    public class Summary
    {
        [JsonPropertyName("totalUploadedMembers")]
        public int TotalUploadedMembers { get; set; }

        [JsonPropertyName("matchedMembersCount")]
        public int MatchedMembersCount { get; set; }

        [JsonPropertyName("mismatchedMembersCount")]
        public int MismatchedMembersCount { get; set; }

        [JsonPropertyName("validationErrorCount")]
        public int ValidationErrorCount { get; set; }

        [JsonPropertyName("validationWarningCount")]
        public int ValidationWarningCount { get; set; }
    }
}

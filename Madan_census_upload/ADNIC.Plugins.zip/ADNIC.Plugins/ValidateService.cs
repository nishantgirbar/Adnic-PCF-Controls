﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    public class ValidateService : IPlugin
    {
        private Census_helper _census_Helper = null;
        private IOrganizationService _systemUserOrgService = null;

        public void Execute(IServiceProvider serviceProvider)
        {
            var tracingService = (ITracingService)serviceProvider
                   .GetService(typeof(ITracingService));

            var context = (IPluginExecutionContext)serviceProvider
                    .GetService(typeof(IPluginExecutionContext));

            string final_response = string.Empty;

            try
            {

               

                var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                    .GetService(typeof(IOrganizationServiceFactory));

                var service = orgServiceFactory
                    .CreateOrganizationService(context.UserId);

                _systemUserOrgService = orgServiceFactory.CreateOrganizationService(null);


                _census_Helper = new Census_helper();
                string policy_guid = string.Empty;
                string policy_number = string.Empty;
                string quote_number_crm = string.Empty;

                if (context.InputParameters.Contains("adnic_policy_guid"))
                {
                    policy_guid = context.InputParameters["adnic_policy_guid"].ToString();
                    var policy_record = service.Retrieve("adnic_policy", Guid.Parse(policy_guid), new ColumnSet(new string[] { "adnic_policy_number", "adnic_quotenumber" }));
                    policy_number = policy_record.GetAttributeValue<string>("adnic_policy_number");
                    quote_number_crm = policy_record.GetAttributeValue<string>("adnic_quotenumber");
                }

                tracingService.Trace($"Policy Number {policy_number}");
                tracingService.Trace($"quote_number_crm {quote_number_crm}");

                tracingService.Trace($"Policy Guid {policy_guid}");



                UploadValidationResponse jsonObject = _census_Helper.GetDataFromResponseJson(tracingService, service, Guid.Parse(policy_guid));

                var ff = $@"<fetch version='1.0' mapping='logical' distinct='true'  no-lock='false'>
    <entity name='adnic_census_data'>
<attribute name='adnic_birth_certificate_id' />
    <attribute name='adnic_category' />
    <attribute name='adnic_census_dataid' />
    <attribute name='adnic_change_of_status_date' />
    <attribute name='adnic_class_no' />
    <attribute name='adnic_coc_fine' />
    <attribute name='adnic_coc_payment_ref_no' />
    <attribute name='adnic_coc_status' />
    <attribute name='adnic_comission_id' />
    <attribute name='adnic_country_id' />
    <attribute name='adnic_dependency' />
    <attribute name='adnic_dob' />
    <attribute name='adnic_effective_date' />
    <attribute name='adnic_eid_visa_application_number' />
    <attribute name='adnic_email_id' />
    <attribute name='adnic_emirates_id' />
    <attribute name='adnic_entry_permit_file_no' />
    <attribute name='adnic_gender_id' />
    <attribute name='adnic_height' />
    <attribute name='adnic_is_matched' />
    <attribute name='adnic_marital_id' />
    <attribute name='adnic_med_dec_or_over_age' />
    <attribute name='adnic_medical_declaration' />
    <attribute name='adnic_member_category_id' />
    <attribute name='adnic_mobile_no' />
    <attribute name='adnic_name' />
    <attribute name='adnic_nationality_id' />
    <attribute name='adnic_passport_no' />
    <attribute name='adnic_pf_no' />
    <attribute name='adnic_policy_guid' />
    <attribute name='adnic_policy_id' />
    <attribute name='adnic_position' />
    <attribute name='adnic_pp_check_remarks' />
    <attribute name='adnic_pp_check_status' />
    <attribute name='adnic_previous_coverage_date' />
    <attribute name='adnic_relation' />
    <attribute name='adnic_residencelocation' />
    <attribute name='adnic_retrieve_all' />
    <attribute name='adnic_retrieve_from_service' />
    <attribute name='adnic_salary_band' />
    <attribute name='adnic_sno' />
    <attribute name='adnic_sponsor_id' />
    <attribute name='adnic_sponsor_type' />
    <attribute name='adnic_thiga_card_no' />
    <attribute name='adnic_validation_remarks' />
    <attribute name='adnic_validation_status' />
    <attribute name='adnic_visa_emirate_id' />
    <attribute name='adnic_visa_type_id' />
    <attribute name='adnic_weight' />
    <attribute name='adnic_work_location_id' />
    <attribute name='adnic_work_type_id' />
     <attribute name='ownerid' />
    <attribute name='owningbusinessunit' />
    <attribute name='statecode' />
    <attribute name='statuscode' />
        <filter type='and'>
            <condition attribute='statecode' operator='eq' value='0'/>
                    </filter>
        <link-entity name='adnic_policy' from='adnic_policyid' to='adnic_policy_id' alias='bb'>
            <filter type='and'>
                <condition attribute='adnic_policyid' operator='eq' value='{policy_guid}'/>
            </filter>
        </link-entity>
    </entity>
</fetch>";

                var basic_data_resultset = service.RetrieveMultiple(new FetchExpression(ff));

                var matched_members = this._census_Helper.GetMatchedMembers_Validate("adnic_census_data", service, tracingService, jsonObject, basic_data_resultset, Guid.Parse(policy_guid));

                tracingService.Trace($"Matched count {matched_members.Count}");

                var mis_matched_members = this._census_Helper.GetMismatchedMembers_Validate("adnic_census_data", service, tracingService, jsonObject, basic_data_resultset, Guid.Parse(policy_guid));

                tracingService.Trace($"MisMatched count {mis_matched_members.Count}");

                var total_members1 = matched_members.Concat(mis_matched_members).ToList();

                tracingService.Trace($"Total members {total_members1.Count}");

                var jsonString = JsonSerializer.Serialize(total_members1, new JsonSerializerOptions
                {
                    WriteIndented = true,
                });

                // tracingService.Trace($"Json string {jsonString}");

                var response = this.CallValidateService(service, tracingService, jsonString).GetAwaiter().GetResult();

                var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_external_dataid' />
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='{Constants.CensusUpload}' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policy_guid}' />                                       
                                      <condition attribute='adnic_description' operator='eq' value='{Constants.AfterValidation}' />  
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";


                tracingService.Trace("Executing JSON query");

                var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));

                tracingService.Trace($"Count {resultSet.Entities.Count}");

                if (resultSet.Entities.Any())
                {
                    var validation_record = resultSet.Entities.FirstOrDefault();
                    tracingService.Trace($"Validation record guid in external data table {validation_record.Id}");
                    validation_record["adnic_json_string"] = response;
                    service.Update(validation_record);
                }
                else
                {
                    var en = new Entity();
                    en.LogicalName = "adnic_external_data";
                    en["adnic_name"] = Constants.CensusUpload;
                    en["adnic_json_string"] = response;
                    en["adnic_description"] = Constants.AfterValidation;
                    en["adnic_source"] = Constants.PolicyIssuance;
                    en["adnic_policy_guid"] = policy_guid;

                    var recId = service.Create(en);
                    tracingService.Trace($"new Record Id for validation {recId}");
                }


                var afterValidationJsonObj = JsonSerializer.Deserialize<UploadValidationResponse>(
                             response,
                             new JsonSerializerOptions
                             {
                                 PropertyNameCaseInsensitive = true
                             });

                tracingService.Trace($" Is Valid {afterValidationJsonObj?.Valid}");

                final_response = afterValidationJsonObj?.Valid.ToString();

                var isNewMemberFound = afterValidationJsonObj?.MismatchedMembers?.FirstOrDefault(mm =>
                 {
                     var validationErrors = string.Join(",", mm.MatchReasons);
                     var finalRes = validationErrors.Any() && validationErrors.ToLower().Contains("new member") && mm.Member.RequiresMedicalUnderwriting;
                     return finalRes;
                 });

                tracingService.Trace($"New member found in mismatched members with medical or overage ? :: {isNewMemberFound != null}");

                //if (isNewMemberFound != null)
                //{
                //    throw new Exception("Newly added members in the policy Census have medical declarations or exceed the permissible age limit. Please either remove the additional members or initiate a quote iteration,"
                //}

                //10%
                var fetchXml_quote = $@"<fetch>
                                  <entity name='adnic_quote'>
                                    <attribute name='adnic_status' />
                                    <attribute name='adnic_adnic_quoteid' />
                                    <attribute name='adnic_quoteid' />
                                    <attribute name='adnic_totalmembers' />
                                    <filter>
                                      <condition attribute='adnic_quotenumber' operator='eq' value='{quote_number_crm}' />
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var resultSet_quote = service.RetrieveMultiple(new FetchExpression(fetchXml_quote));

                tracingService.Trace($"resultSet_quote count {resultSet_quote.Entities.Count}");

                bool? is_valid_census_members_count = null;
                if (resultSet_quote?.Entities.Count > 0)
                {
                    var policy_quote = resultSet_quote.Entities[0];
                    var total_quotes_string = policy_quote.GetAttributeValue<string>("adnic_totalmembers");
                    var total_census_members_count = jsonObject.Members.Count;
                    int total_quotes = 0;
                    int.TryParse(total_quotes_string, out total_quotes);
                    total_quotes =(int) Math.Round(total_quotes + (total_quotes * 0.10));
                    is_valid_census_members_count = (total_census_members_count < total_quotes);
                    tracingService.Trace($"total_census_members_count {total_census_members_count} - total_quotes {total_quotes}");
                }

                if (isNewMemberFound != null)
                {
                    final_response = "new_member_found_mismatch_medical";
                }
                else if (is_valid_census_members_count.HasValue && !is_valid_census_members_count.Value)
                {
                    final_response = "census_count_greater";
                }
                else
                {
                    //if (afterValidationJsonObj.Valid)
                    if (true)
                    {
                        tracingService.Trace("Got VALID response.");
                        policy_number = "30"; //"49";
                        final_response = "true";

                        //Check ALL Service
                        tracingService.Trace("Calling Check all service");
                        var checkAll_response = this.CallCheckAll_ValidateService(service, tracingService, policy_number).GetAwaiter().GetResult();

                        var checkAllJsonObj = JsonSerializer.Deserialize<CheckAllResponse>(
                                 checkAll_response,
                                 new JsonSerializerOptions
                                 {
                                     PropertyNameCaseInsensitive = true
                                 });
                        tracingService.Trace("Calling Check all service-End");

                        //Check all Status
                        tracingService.Trace("Calling Check all STATUS service");

                        tracingService.Trace($"coc job id {checkAllJsonObj.CocJobId} PP job id {checkAllJsonObj.PpJobId}");

                        var checkAll_ = this.CallCheckAll_Status_ValidateService(service, tracingService, policy_number, checkAllJsonObj.CocJobId, checkAllJsonObj.PpJobId).GetAwaiter().GetResult();

                        var checkAll_status_JsonObj = JsonSerializer.Deserialize<CheckAllResponse>(
                               checkAll_,
                               new JsonSerializerOptions
                               {
                                   PropertyNameCaseInsensitive = true
                               });

                        tracingService.Trace("Calling Check all STATUS service -- END");

                        //Get PP Members
                        tracingService.Trace("Calling PP Members service -- Start");

                        policy_number = "11";
                        var pp_members = this.Call_Get_PpCOC_Members_Service(service, tracingService, policy_number).GetAwaiter().GetResult();

                        var pp_members_JsonObj = JsonSerializer.Deserialize<List<PP_COC_Member>>(
                               pp_members,
                               new JsonSerializerOptions
                               {
                                   PropertyNameCaseInsensitive = true
                               });

                        tracingService.Trace("Calling PP Members service -- END");

                        var ref_data = this._census_Helper.GetReferenceData(service, tracingService);

                        tracingService.Trace($"Reference records count {ref_data.Count}");

                        var fetxhXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_pp_coc_check'>
                                    <attribute name='adnic_pp_coc_checkid' />
                                    <filter>
                                      <condition attribute='statecode' operator='eq' value='0' />                                      
                                     <condition attribute='adnic_policy_id' operator='eq' value='{policy_guid}' />
                                    </filter>
                                  </entity>
                                </fetch>";
                        var resultSet_pp = service.RetrieveMultiple(new FetchExpression(fetxhXml));

                        tracingService.Trace($" Total existing PP COC records in CRM {resultSet?.Entities?.Count}");

                        foreach (var eachMember in pp_members_JsonObj)
                        {
                            UpsertPPCOCCheck(tracingService, service, policy_guid, ref_data, resultSet_pp, eachMember);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Exception {ex.Message} details :: {ex.InnerException?.ToString()}");
                final_response = $"Exception :: {ex.Message}";
            }

            context.OutputParameters["adnic_validation_response"] = final_response; // afterValidationJsonObj?.Valid.ToString();
        }

        private void UpsertPPCOCCheck(ITracingService tracingService, IOrganizationService service, string policy_guid, IList<Entity> ref_data, EntityCollection resultSet_pp, PP_COC_Member eachMember)
        {
            tracingService.Trace($"UpsertPPCOCCheck started.");
            try
            {
                var foundRecord = resultSet_pp?.Entities?.FirstOrDefault(e =>
                {
                    var crm_member_name = e.GetAttributeValue<string>("adnic_name");
                    var crm_pf_no = e.GetAttributeValue<string>("adnic_pf_no");

                    return crm_member_name == eachMember.MemberName && crm_pf_no == eachMember.PfNo;
                });

                var entity = new Entity("adnic_pp_coc_check");
                entity["adnic_policy_id"] = new EntityReference("adnic_policy", Guid.Parse(policy_guid));
                entity["adnic_name"] = eachMember.MemberName;
                entity["adnic_pf_no"] = eachMember.PfNo;
                entity["adnic_dob"] = _census_Helper.ConvertDobToCrmDateTime(eachMember.DateOfBirth, tracingService);
                entity["adnic_pr_remarks"] = eachMember.PpRemark;

                if (eachMember.SrNo.HasValue)
                {
                    entity["adnic_si_no"] = eachMember.SrNo.Value;
                }

                entity["adnic_coc_amount"] = eachMember.CocFine;

                tracingService.Trace($"COC PP status {eachMember.CocStatus} {eachMember.PrStatus}");

                entity["adnic_coc_status"] = eachMember.CocStatus;
                entity["adnic_pp_status"] = eachMember.PrStatus;

                this._census_Helper.SetEntityField(eachMember.VisaType, "adnic_visa_type", Constants.MasterData_Visa_Type, tracingService, ref_data, entity);

                this._census_Helper.SetEntityField(eachMember.VisaEmirate, "adnic_visa_emirates_id", Constants.MasterData_Visa_Emirate, tracingService, ref_data, entity);

                if (foundRecord != null)
                {
                    entity["adnic_pp_coc_checkid"] = foundRecord.Id;
                    service.Update(entity);
                }
                else
                {
                    var record_id = _systemUserOrgService.Create(entity);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            tracingService.Trace($"UpsertPPCOCCheck end.");
        }

        private async Task<string> CallCheckAll_ValidateService(IOrganizationService service, ITracingService tracingService, string policyNumber)
        {
            string responseContent = string.Empty;

            try
            {
                var service_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_CensusCheckAllValidation");

                service_url= string.Format(service_url, policyNumber);
                tracingService.Trace($" service url {service_url}");

                using (var client = new HttpClient())
                {

                    var content = new StringContent(
                        "",
                        Encoding.UTF8,
                        "application/json");

                    HttpResponseMessage response = await client.PostAsync(service_url, content);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    tracingService.Trace(responseContent);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            return responseContent;
        }

        private async Task<string> CallCheckAll_Status_ValidateService(IOrganizationService service, ITracingService tracingService, string policyNumber, string cocJobId, string ppJobId)
        {
            string responseContent = string.Empty;

            try
            {
                var service_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_CensusCheckAllStatus");


                service_url = string.Format(service_url, policyNumber, cocJobId, ppJobId);

                tracingService.Trace($" service url {service_url}");

                using (var client = new HttpClient())
                {

                    HttpResponseMessage response = await client.GetAsync(service_url);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    tracingService.Trace(responseContent);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            return responseContent;
        }

        private async Task<string> Call_Get_PpCOC_Members_Service(IOrganizationService service, ITracingService tracingService, string policyNumber)
        {
            string responseContent = string.Empty;

            try
            {
                var service_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_CensusPPCOCMembers");


                service_url = string.Format(service_url, policyNumber);

                tracingService.Trace($" service url {service_url}");

                using (var client = new HttpClient())
                {

                    HttpResponseMessage response = await client.GetAsync(service_url);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    //tracingService.Trace(responseContent);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            return responseContent;
        }

        private async Task<string> CallValidateService(IOrganizationService service,ITracingService tracingService, string jsonString)
        {
            string responseContent = string.Empty;

            try
            {
                var validtion_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_census_validation");

                tracingService.Trace($" service url {validtion_url}");

                using (var client = new HttpClient())
                {

                    //client.DefaultRequestHeaders.Add("Authorization", "Bearer YOUR_TOKEN"); // if required

                    var content = new StringContent(
                        jsonString,
                        Encoding.UTF8,
                        "application/json");

                    HttpResponseMessage response = await client.PostAsync(validtion_url, content);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    //tracingService.Trace(responseContent);
                }
            }
            catch(Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

           return responseContent;
        }
        private string ConvertEntityCollectionToJson(
    EntityCollection entityCollection,
    ITracingService tracingService)
        {
            if (entityCollection == null || entityCollection.Entities.Count == 0)
            {
                tracingService.Trace("EntityCollection is null or empty.");
                return "[]";
            }

            tracingService.Trace("Converting {0} entities to JSON.",
                entityCollection.Entities.Count);

            var list = new List<Dictionary<string, object>>();

            foreach (var entity in entityCollection.Entities)
            {
                var dict = this.ConvertEntityToDictionary(entity, tracingService);
                list.Add(dict);
            }

            string json = System.Text.Json.JsonSerializer.Serialize(list,
                new System.Text.Json.JsonSerializerOptions
                {
                    WriteIndented = false
                });

            tracingService.Trace("JSON converted. Length: {0}", json);

            return json;
        }

        private Dictionary<string, object> ConvertEntityToDictionary(
    Entity entity,
    ITracingService tracingService)
        {
            var dict = new Dictionary<string, object>();

            // Always include entity ID
            dict["id"] = entity.Id.ToString();

            foreach (var attr in entity.Attributes)
            {
                var key = attr.Key;
                var value = attr.Value;

                if (value == null)
                {
                    dict[key] = null;
                    continue;
                }

                // Convert each CRM type to JSON-friendly value
                if (value is string s)
                {
                    dict[key] = s;
                }
                else if (value is int i)
                {
                    dict[key] = i;
                }
                else if (value is decimal d)
                {
                    dict[key] = d;
                }
                else if (value is double db)
                {
                    dict[key] = db;
                }
                else if (value is bool b)
                {
                    dict[key] = b;
                }
                else if (value is Guid g)
                {
                    dict[key] = g.ToString();
                }
                else if (value is DateTime dt)
                {
                    dict[key] = dt.ToString("yyyy-MM-dd HH:mm:ss");
                }
                else if (value is Money m)
                {
                    dict[key] = m.Value;
                }
                else if (value is OptionSetValue osv)
                {
                    // Return both value and label
                    dict[key] = new Dictionary<string, object>
            {
                { "value", osv.Value },
                { "label", entity.FormattedValues.ContainsKey(key)
                    ? entity.FormattedValues[key]
                    : osv.Value.ToString() }
            };
                }
                else if (value is EntityReference er)
                {
                    // Return both id and name
                    dict[key] = new Dictionary<string, object>
            {
                { "id",          er.Id.ToString()       },
                { "logicalName", er.LogicalName          },
                { "name",        er.Name ?? string.Empty }
            };
                }
                else if (value is OptionSetValueCollection osvc)
                {
                    // Multi-select optionset
                    dict[key] = osvc.Select(o => o.Value).ToList();
                }
                else if (value is AliasedValue av)
                {
                    dict[key] = av.Value?.ToString() ?? null;
                }
                else
                {
                    dict[key] = value.ToString();
                }
            }

            return dict;
        }
    }
}

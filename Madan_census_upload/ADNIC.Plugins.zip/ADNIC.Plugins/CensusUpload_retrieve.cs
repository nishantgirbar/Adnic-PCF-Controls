﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    
    public class CensusUpload_retrieve : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
//            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
//            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
//            try
//            {
               
              
//                IOrganizationServiceFactory orgServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

//                tracingService.Trace("Started");

//                var service = orgServiceFactory.CreateOrganizationService(context.UserId);

//                var target = context.InputParameters["Target"] as Entity;


//               // var dob=target["dateOfBirth"].ToString();
//               if(target == null)
//                {
//                    tracingService.Trace("Target is empty");
//                    context.OutputParameters["BusinessEntity"] = new Entity("adnic_census_upload_virtual");
//                    return;
//                }

//                if (target.Contains("adnic_name"))
//                {
//                    tracingService.Trace("Name empy");
//                }
//                var name = target["adnic_name"].ToString();

//                tracingService.Trace($"dob  name {name}");



//                var fetchXml = @"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
//  <entity name='adnic_application_configurations'>
//    <attribute name='adnic_policy_id' />
//    <attribute name='adnic_service_response' />
//    <filter>
//      <condition attribute='adnic_name' operator='eq' value='Census_Upload' />
//    </filter>
//  </entity>
//</fetch>";
//                tracingService.Trace("Executing query");
//                var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));
//                IList<Entity> mis_matchedOnes = new List<Entity>();

//                tracingService.Trace($"Count {resultSet.Entities.Count}");

//                if (resultSet.Entities.Any())
//                {
//                    var jsonResponse = resultSet.Entities[0]["adnic_service_response"].ToString();
//                    var jsonObject = JsonSerializer.Deserialize<UploadValidationResponse>(
//                        jsonResponse,
//                        new JsonSerializerOptions
//                        {
//                            PropertyNameCaseInsensitive = true
//                        });
//                    tracingService.Trace($"Mismatch count {jsonObject.MismatchedMembers.Count}");

//                    var foundRecordInMisMatch = jsonObject.MismatchedMembers.Find(mm =>  mm.Member.MemberName.Equals(name));
//                    var foundRecordInMatch = jsonObject.MatchedMembers.Find(mm =>  mm.Member.MemberName.Equals(name));

//                    if (foundRecordInMisMatch != null)
//                    {
//                        var eachMember = foundRecordInMisMatch;
//                        var eachOne = new Entity("adnic_census_upload_virtual")
//                        {
//                            Attributes =
//                            {
//                            ["adnic_census_upload_virtualid"]=Guid.NewGuid(),
//                            ["adnic_sno"]=eachMember.Member.RowNumber,
//                            ["adnic_pf_no"]=eachMember.Member.PfNo,
//                            //["adnic_member_name"]= eachMember.Member.MemberName,
//                            //["adnic_dob"]=eachMember.Member.DateOfBirth,
//                            //["adnic_category"]=eachMember.Member.MemberCategory,
//                            //["adnic_gender"]=eachMember.Member.Gender,
//                            ["adnic_name"]=eachMember.Member.MemberName
//                            }
//                        };

//                        tracingService.Trace($"SNo:{eachMember.Member.RowNumber}\nName:{eachMember.Member.MemberName}\n PF NO:{eachMember.Member.PfNo}\nCategory:{eachMember.Member.MemberCategory}\nGender:{eachMember.Member.Gender}\nDOB:{eachMember.Member.DateOfBirth}\n");

//                        mis_matchedOnes.Add(eachOne);
//                    }
                    
//                }

//                var entityCollection = new EntityCollection() { EntityName = "adnic_census_upload_virtual",  TotalRecordCount = mis_matchedOnes.Count };

//                entityCollection.Entities.AddRange(mis_matchedOnes);

//                tracingService.Trace($"entity collection 1 {entityCollection.Entities.Count}");


//                context.OutputParameters["BusinessEntity"] = entityCollection.Entities.First();
//            }
//            catch (Exception ex)
//            {
//                tracingService.Trace(ex.Message);
//                context.OutputParameters["BusinessEntity"] = new Entity("adnic_census_upload_virtual");
//            }
        }
    }

    
}

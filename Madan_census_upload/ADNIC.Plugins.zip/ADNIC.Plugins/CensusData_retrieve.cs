﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{

    public class CensusData_retrieve : IPlugin
    {
        private Census_helper census_Helper = null;

        public void Execute(IServiceProvider serviceProvider)
        {
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            try
            {
                if (context.Depth > 1)
                {
                    tracingService.Trace("Depth {0} — exiting to prevent loop.", context.Depth);
                    return;
                }

                var userGuid = context.UserId;

                tracingService.Trace($"User guid {userGuid}");

                census_Helper = new Census_helper();

                IOrganizationServiceFactory orgServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

                tracingService.Trace("Started");

                var service = orgServiceFactory.CreateOrganizationService(context.UserId);

                tracingService.Trace("PrimaryEntityId: {0}", context.PrimaryEntityId);
                tracingService.Trace("PrimaryEntityName: {0}", context.PrimaryEntityName);
                tracingService.Trace("MessageName: {0}", context.MessageName);

                //tracingService.Trace("All InputParameters:");
                //foreach (var param in context.InputParameters)
                //{
                //    tracingService.Trace(" - Key: {0} | Type: {1} | Value: {2}",
                //        param.Key,
                //        param.Value?.GetType()?.Name ?? "null",
                //        param.Value?.ToString() ?? "null");
                //}

                // Get ID directly from PrimaryEntityId
                Guid recordId = context.PrimaryEntityId;

                var enRef = context.InputParameters["Target"] as EntityReference;

                var cols = new string[] {  "adnic_sno", "adnic_pf_no", "adnic_name", "adnic_policy_id" };

                var crm_record = service.Retrieve(enRef.LogicalName, enRef.Id, new ColumnSet(cols));

                var policyRef = crm_record.GetAttributeValue<EntityReference>("adnic_policy_id");
                var policyGuid = policyRef.Id;

                tracingService.Trace($"policy guid {policyGuid}");

                var jsonObj = census_Helper.GetDataFromResponseJson(tracingService, service, policyGuid);

                //get updated details from external data table
                var updatedMemberInfo = census_Helper.GetUpdatedMember(service, tracingService, policyGuid.ToString(), context.PrimaryEntityId.ToString());

                tracingService.Trace("After GetUpdatedMember");

                if (jsonObj == null)
                {
                    tracingService.Trace("jsonobj is null;");
                }

                var found_record = jsonObj.MatchedMembers.FirstOrDefault(m =>
                 {
                     var name = crm_record.GetAttributeValue<string>("adnic_name") ?? string.Empty;
                     var pfno = crm_record.GetAttributeValue<string>("adnic_pf_no") ?? string.Empty;

                     bool res = m.Member.MemberName == name && m.Member.PfNo == pfno;
                     return res;
                 });

                tracingService.Trace($"Found {found_record}");

                var finalEntity = new Entity("adnic_census_data", enRef.Id);

                if (found_record == null)
                {
                    tracingService.Trace("looking into mismatched list");

                    var found_record_in_mismatch = jsonObj.MismatchedMembers.FirstOrDefault(m =>
                    {
                        var name = crm_record.GetAttributeValue<string>("adnic_name");
                        var pfno = crm_record.GetAttributeValue<string>("adnic_pf_no");
                        bool res = m.Member.MemberName == name && m.Member.PfNo == pfno;
                        return res;
                    });

                    if (found_record_in_mismatch != null)
                    {
                        tracingService.Trace("Found in mismatched");
                        this.census_Helper.UpdateOriginalMember(found_record_in_mismatch.Member, updatedMemberInfo, tracingService);
                        this.MapMemberToEntity(found_record_in_mismatch.Member, finalEntity, tracingService, service, enRef.Id, userGuid, policyGuid, false);
                    }
                }
                else
                {
                    //matched
                    this.census_Helper.UpdateOriginalMember(found_record.Member, updatedMemberInfo, tracingService);
                    this.MapMemberToEntity(found_record.Member, finalEntity, tracingService, service, enRef.Id, userGuid, policyGuid, true);
                }

                if (enRef != null)
                {
                    var recid = enRef.Id;
                    tracingService.Trace($"id {recid}");
                    context.OutputParameters["BusinessEntity"] = finalEntity;
                }
                else
                {
                    context.OutputParameters["BusinessEntity"] = new Entity("adnic_census_data");
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
                context.OutputParameters["BusinessEntity"] = new Entity("adnic_census_data");
            }
        }

        
       
        private Entity MapMemberToEntity(
    Member member,
    Entity crm_record,
    ITracingService tracingService,
    IOrganizationService service,
   Guid crm_guid,
   Guid userGuid,
   Guid policyGuid,
   bool isMatched
    )
        {
            var ref_collection = this.census_Helper.GetReferenceData(service, tracingService);
            var entity = crm_record;

            entity[$"{crm_record.LogicalName}id"] = crm_guid;

            tracingService.Trace($"MapMemberToEntity::member name {member.MemberName}");

            entity["adnic_name"] = member.MemberName ?? string.Empty;
            entity["adnic_dob"] = census_Helper.ConvertToCRMDateTime(member.DateOfBirth, tracingService);
            //entity["adnic_gender"] = member.Gender.ToLower() == "male" ? new OptionSetValue(371320000) : new OptionSetValue(371320001);


            //Madan
            this.census_Helper.SetEntityField(member.Gender, "adnic_gender_id",Constants.MasterData_Gender, tracingService, ref_collection, entity);
            this.census_Helper.SetEntityField(member.MaritalStatus, "adnic_marital_id",Constants.MasterData_MARITAL_STATUS, tracingService, ref_collection, entity);


            this.census_Helper.SetEntityField(member.Commission, "adnic_comission_id", Constants.MasterData_COMMISSION, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.Country, "adnic_country_id", Constants.MasterData_Countries, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.MemberCategory, "adnic_member_category_id", Constants.MasterData_Member_Category, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.Nationality, "adnic_nationality_id", Constants.MasterData_Countries, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.SponsorType, "adnic_sponsor_type", Constants.MasterData_SPONSER_TYPE, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.VisaEmirate, "adnic_visa_emirate_id", Constants.MasterData_Visa_Emirate, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.VisaType, "adnic_visa_type_id", Constants.MasterData_Visa_Type, tracingService, ref_collection, entity);

            this.census_Helper.SetEntityField(member.WorkLocation, "adnic_work_location_id", Constants.MasterData_Work_Location, tracingService, ref_collection, entity);

            //this.census_Helper.SetEntityField(member.MaritalStatus, "adnic_work_type_id", Constants.Work, tracingService, ref_collection, entity);

            entity["adnic_relation"] = member.Relation ?? string.Empty;
            entity["adnic_dependency"] = member.Dependency ?? string.Empty;
            //entity["adnic_category"] = member.MemberCategory ?? string.Empty;
            entity["adnic_sno"] = member.SrNo;
            entity["adnic_pf_no"] = member.PfNo;
            entity["ownerid"] = new EntityReference("systemuser", userGuid);
            entity["adnic_policy_id"] = new EntityReference("adnic_policy", policyGuid);


            // ── Identity ──────────────────────────────────────────────────
            entity["adnic_emirates_id"] = member.EmiratesId ?? string.Empty;
            entity["adnic_passport_no"] = member.PassportNo ?? string.Empty;
            entity["adnic_eid_visa_application_number"] = member.EidApplicationNo ?? string.Empty;
            entity["adnic_entry_permit_file_no"] = member.EntryPermitNo ?? string.Empty;
            entity["adnic_birth_certificate_id"] = member.BirthCertificateId ?? string.Empty;
            entity["adnic_thiga_card_no"] = member.ThiqaCardNo ?? string.Empty;

            // ── Contact ───────────────────────────────────────────────────
            entity["adnic_mobile_no"] = member.MobileNo ?? string.Empty;
            entity["adnic_email_id"] = member.EmailId ?? string.Empty;
            entity["adnic_position"] = member.Position ?? string.Empty;

            // ── Dates ─────────────────────────────────────────────────────
            entity["adnic_effective_date"] = census_Helper.ConvertToCRMDateTime(member.EffectiveDate, tracingService);
            entity["adnic_previous_coverage_date"] = census_Helper.ConvertToCRMDateTime(member.PreviousCoverageDate, tracingService);
            entity["adnic_change_of_status_date"] = census_Helper.ConvertToCRMDateTime(member.ChangeOfStatusDate, tracingService);

            // ── Location ──────────────────────────────────────────────────
            entity["adnic_residencelocation"] = member.ResidenceLocation ?? string.Empty;
            entity["adnic_salary_band"] = member.SalaryBand ?? string.Empty;
            entity["adnic_sponsor_id"] = member.SponsorId ?? string.Empty;
            entity["adnic_class_no"] = member.ClassNo ?? string.Empty;

            // ── Medical ───────────────────────────────────────────────────

            tracingService.Trace($"medicla decla {member.RequiresMedicalUnderwriting}");

            entity["adnic_medical_declaration"] = member.RequiresMedicalUnderwriting;//.ToLower() == "true";
            entity["adnic_height"] = census_Helper.ConvertToDecimal(member.Height);
            entity["adnic_weight"] = census_Helper.ConvertToDecimal(member.Weight); // TODO: add Weight to Member class

            // ── Validation ────────────────────────────────────────────────
            entity["adnic_validation_status"] = member.RecordStatus ?? string.Empty;
            entity["adnic_validation_remarks"] = member.ValidationErrors != null
                ? string.Join(", ", member.ValidationErrors)
                : string.Empty;

            // ── Match Info ────────────────────────────────────────────────
            entity["adnic_pp_check_status"] = string.Empty;
            entity["adnic_pp_check_remarks"] = string.Empty;

            tracingService.Trace($"Is matched {isMatched}");

            int stateCode = isMatched ? Constants.Inactive : Constants.Active;
            entity["statecode"] = stateCode;

            return entity;
        }

        

    }
   

}

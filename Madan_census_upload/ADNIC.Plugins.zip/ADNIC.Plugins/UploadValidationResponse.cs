﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ADNIC.Plugins
{
    public class  UploadValidationResponse
    {
        [JsonPropertyName("members")]
        public List<Member> Members { get; set; }

        [JsonPropertyName("matchedMembers")]
        public List<MatchedMember> MatchedMembers { get; set; }

        [JsonPropertyName("mismatchedMembers")]
        public List<MismatchedMember> MismatchedMembers { get; set; }

        [JsonPropertyName("errors")]
        public List<string> Errors { get; set; }

        [JsonPropertyName("warnings")]
        public List<string> Warnings { get; set; }

        [JsonPropertyName("summary")]
        public Summary Summary { get; set; }

        [JsonPropertyName("totalRows")]
        public int TotalRows { get; set; }

        [JsonPropertyName("valid")]
        public bool Valid { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ADNIC.Plugins
{
    public class MatchedMember
    {
        [JsonPropertyName("member")]
        public Member Member { get; set; }

        [JsonPropertyName("matchStatus")]
        public string MatchStatus { get; set; }

        [JsonPropertyName("matchReasons")]
        public List<string> MatchReasons { get; set; }
    }
}

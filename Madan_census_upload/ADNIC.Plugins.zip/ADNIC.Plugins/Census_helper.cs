﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IdentityModel.Metadata;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    internal class Census_helper
    {
        internal IList<Entity> _referenec_data;

        internal void SetReferenceData(IOrganizationService service,ITracingService tracingService)
        {
            this._referenec_data= this.GetReferenceData(service, tracingService);
        }

        internal DateTime ConvertDobToCrmDateTime(string dob, ITracingService tracingService)
        {
            if (string.IsNullOrEmpty(dob))
            {
                tracingService.Trace("DOB is null or empty.");
                return DateTime.MinValue;
            }

            // Parse 1986-12-23 format
            if (DateTime.TryParseExact(
                    dob,
                    "yyyy-MM-dd",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None,
                    out DateTime parsedDate))
            {
                // CRM stores DateTime in UTC
                var utcDate = DateTime.SpecifyKind(parsedDate, DateTimeKind.Utc);

                tracingService.Trace("DOB converted: {0} → {1}", dob, utcDate);

                return utcDate;
            }

            tracingService.Trace("Failed to parse DOB: {0}", dob);
            return DateTime.MinValue;
        }
        internal decimal? ConvertToDecimal(string value)
        {
            if (string.IsNullOrEmpty(value)) return null;

            return decimal.TryParse(value,
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out decimal result)
                ? result
                : (decimal?)null;
        }

        internal DateTime ConvertToCRMDateTime(
   string dob,
   ITracingService tracingService)
        {
            if (string.IsNullOrEmpty(dob))
            {
                tracingService.Trace("DOB is null or empty.");
                return DateTime.MinValue;
            }

            // Parse 1986-12-23 format
            if (DateTime.TryParseExact(
                    dob,
                    "yyyy-MM-dd",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None,
                    out DateTime parsedDate))
            {
                // CRM stores DateTime in UTC
                var utcDate = DateTime.SpecifyKind(parsedDate, DateTimeKind.Utc);

                tracingService.Trace("DOB converted: {0} → {1}", dob, utcDate);

                return utcDate;
            }

            tracingService.Trace("Failed to parse DOB: {0}", dob);
            return DateTime.MinValue;
        }
        internal Member GetUpdatedMember(IOrganizationService service, ITracingService tracingService, string policyGuid, string censusMemberGuid)
        {
            Member member = null;
            tracingService.Trace($"UpdateJSONResponse::policy guid {policyGuid}");
            tracingService.Trace($"UpdateJSONResponse::census data guid  {censusMemberGuid}");

            var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='{Constants.CensusMemberUpdate}' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policyGuid}' />  
                                      <condition attribute='adnic_census_data_id' operator='eq' value='{censusMemberGuid}' />  
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";

            tracingService.Trace("UpdateJSONResponse::Executing JSON query");

            var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));

            tracingService.Trace($"UpdateJSONResponse::Count {resultSet.Entities.Count}");

            if (resultSet.Entities.Any())
            {
                var memberInfo = resultSet.Entities.FirstOrDefault();
                string member_updates_json = memberInfo.GetAttributeValue<string>("adnic_json_string");

                var jsonNode = JsonNode.Parse(member_updates_json);

                if (jsonNode["requiresMedicalUnderwriting"] != null)
                {
                    var value = jsonNode["requiresMedicalUnderwriting"].ToString();

                    jsonNode["requiresMedicalUnderwriting"] =
                        string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);
                }

                member_updates_json = jsonNode.ToJsonString();

                tracingService.Trace($"Updated Member JSON {member_updates_json}");

               member = JsonSerializer.Deserialize<Member>(
                        member_updates_json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                tracingService.Trace($"Member passportno :: {member.PassportNo}");
            }

            return member;
        }

        internal IDictionary<Guid, UploadValidationResponse> GetOriginalJson(IOrganizationService service, ITracingService tracingService, Guid policyGuid)
        {
            UploadValidationResponse uploadValidationResponse = null;
            var result = new Dictionary<Guid, UploadValidationResponse>();
            Guid entity_Id = Guid.Empty;

            tracingService.Trace($"GetOriginalJson::policy guid {policyGuid}");
            //tracingService.Trace($"UpdateJSONResponse::census data guid  {censusMemberGuid}");

            var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />    
                                    <attribute name='adnic_json_updated_staring' />                          
                                    <attribute name='adnic_external_dataid' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='{Constants.CensusUpload}' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policyGuid}' />  
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";

            tracingService.Trace("GetOriginalJson::Executing JSON query");

            var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));

            tracingService.Trace($"GetOriginalJson::Count {resultSet.Entities.Count}");

            if (resultSet.Entities.Any())
            {
                JsonNode jsonNode = null;
                var memberInfo = resultSet.Entities.FirstOrDefault();
                entity_Id = Guid.Parse(memberInfo["adnic_external_dataid"]?.ToString());
                tracingService.Trace($"GetOriginalJson:: external data record guid:: {entity_Id}");

                string json_string = memberInfo.GetAttributeValue<string>("adnic_json_string");
                string json_updated_string = memberInfo.GetAttributeValue<string>("adnic_json_updated_staring");

                if (string.IsNullOrEmpty(json_updated_string))
                {
                    jsonNode = JsonNode.Parse(json_string);
                }
                else
                {
                    jsonNode = JsonNode.Parse(json_updated_string);
                }

                if (jsonNode["requiresMedicalUnderwriting"] != null)
                {
                    var value = jsonNode["requiresMedicalUnderwriting"].ToString();

                    jsonNode["requiresMedicalUnderwriting"] =
                        string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);
                }

                json_string = jsonNode.ToJsonString();

                tracingService.Trace(json_string);

                uploadValidationResponse = JsonSerializer.Deserialize<UploadValidationResponse>(
                         json_string,
                         new JsonSerializerOptions
                         {
                             PropertyNameCaseInsensitive = true
                         });

                tracingService.Trace($"Original json valid flag :: {uploadValidationResponse?.Valid}");
            }

            result.Add(entity_Id, uploadValidationResponse);
            return result;
        }
        internal UploadValidationResponse GetDataFromResponseJson(ITracingService tracingService, IOrganizationService service, Guid policyGuid)
        {
            UploadValidationResponse jsonObject = null;

            try
            {
                var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='{Constants.CensusUpload}' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policyGuid}' />  
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";


                tracingService.Trace("Executing JSON query");

                var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));

                tracingService.Trace($"Count {resultSet.Entities.Count}");

                if (resultSet.Entities.Any())
                {
                    var jsonResponse = resultSet.Entities[0]["adnic_json_string"].ToString();
                    jsonObject = JsonSerializer.Deserialize<UploadValidationResponse>(
                        jsonResponse,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });
                    tracingService.Trace($"Mismatch count {jsonObject.MismatchedMembers.Count}");
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }
            return jsonObject;
        }
        private IEnumerable<Entity> GetMembersFromCRM(ITracingService tracingService, EntityCollection basic_data_from_CRM, bool is_matched)
        {
            tracingService.Trace($"basic_data_from_CRM {basic_data_from_CRM.Entities.Count}");

            var matched_crm_records = basic_data_from_CRM.Entities.Where((e) =>
            {
                bool ismatched = e.GetAttributeValue<bool>("adnic_is_matched") == is_matched;
                return ismatched;
            });

            tracingService.Trace($"GetMembersFromCRM  after applying isMatched {is_matched}:: count {matched_crm_records.Count()}");
            return matched_crm_records;
        }

        internal IList<Entity> GetMismatchedMembers(string entityName, IOrganizationService service, ITracingService tracingService, UploadValidationResponse jsonObject, EntityCollection basic_data_from_CRM, Guid _policy_guid)
        {
            tracingService.Trace($"GetMismatchedMembers started");
            IList<Entity> members = new List<Entity>();

            if (jsonObject == null) { return members; }

            var misMatched_crm_records = GetMembersFromCRM(tracingService, basic_data_from_CRM, false);

            //misMatched_crm_records.ToList().ForEach((e) =>
            //{
            //    this.PrintEntityAttributes(e, tracingService);
            //});

            foreach (MismatchedMember eachMember in jsonObject.MismatchedMembers)
            {
                tracingService.Trace($" pf no {eachMember.Member.PfNo}");

                var crm_matched_record = misMatched_crm_records.FirstOrDefault((e) =>
                {
                    //tracingService.Trace($" CRM pf no {e.GetAttributeValue<string>("adnic_pf_no")}");
                    var pfno = e.GetAttributeValue<string>("adnic_pf_no");
                    var name = e.GetAttributeValue<string>("adnic_name");
                    return (pfno == eachMember.Member.PfNo && name == eachMember.Member.MemberName);
                });

                var crm_guid = crm_matched_record?.Id;

                if (crm_guid == null)
                {
                    tracingService.Trace($"No reocrd is found in CRM. Continuing with other records.");
                    continue;
                }

                tracingService.Trace($"Mismatched CRM Record GUID {crm_guid}");

                var updatedMember = this.GetUpdatedMember(service, tracingService, _policy_guid.ToString(), crm_guid.ToString());
                if (updatedMember != null)
                {
                    this.UpdateOriginalMember(eachMember.Member, updatedMember, tracingService);
                }

                Entity eachOne = PrepareCRMRecord(entityName, tracingService, eachMember.Member, crm_guid, false);

                // tracingService.Trace($"SNo:{eachMember.Member.RowNumber}\nName:{eachMember.Member.MemberName}\n PF NO:{eachMember.Member.PfNo}\nCategory:{eachMember.Member.MemberCategory}\nGender:{eachMember.Member.Gender}\nDOB:{eachMember.Member.DateOfBirth}\n");
                if (eachOne != null)
                {
                    members.Add(eachOne);
                }
            }

            tracingService.Trace($"GetMismatchedMembers end");

            return members;
        }


        internal IList<Member> GetMismatchedMembers_Validate(string entityName, IOrganizationService service, ITracingService tracingService, UploadValidationResponse jsonObject, EntityCollection basic_data_from_CRM, Guid _policy_guid)
        {
            tracingService.Trace($"GetMismatchedMembers_Validate started");
            IList<Member> members = new List<Member>();

            if (jsonObject == null) { return members; }

            var misMatched_crm_records = GetMembersFromCRM(tracingService, basic_data_from_CRM, false);


            foreach (MismatchedMember eachMember in jsonObject.MismatchedMembers)
            {
                tracingService.Trace($" pf no {eachMember.Member.PfNo}");

                var crm_matched_record = misMatched_crm_records.FirstOrDefault((e) =>
                {
                    //tracingService.Trace($" CRM pf no {e.GetAttributeValue<string>("adnic_pf_no")}");
                    var pfno = e.GetAttributeValue<string>("adnic_pf_no");
                    var name = e.GetAttributeValue<string>("adnic_name");
                    return (pfno == eachMember.Member.PfNo && name == eachMember.Member.MemberName);
                });

                var crm_guid = crm_matched_record?.Id;

                if (crm_guid == null)
                {
                    tracingService.Trace($"No reocrd is found in CRM. Continuing with other records.");
                    continue;
                }

                tracingService.Trace($"Mismatched CRM Record GUID {crm_guid}");

                var updatedMember = this.GetUpdatedMember(service, tracingService, _policy_guid.ToString(), crm_guid.ToString());
                if (updatedMember != null)
                {
                    this.UpdateOriginalMember(eachMember.Member, updatedMember, tracingService);
                }

                //Entity eachOne = PrepareCRMRecord(entityName, tracingService, eachMember.Member, crm_guid);

                // tracingService.Trace($"SNo:{eachMember.Member.RowNumber}\nName:{eachMember.Member.MemberName}\n PF NO:{eachMember.Member.PfNo}\nCategory:{eachMember.Member.MemberCategory}\nGender:{eachMember.Member.Gender}\nDOB:{eachMember.Member.DateOfBirth}\n");

                members.Add(eachMember.Member);
            }

            tracingService.Trace($"GetMismatchedMembers_Validate end");

            return members;
        }

        internal IList<Member> GetMatchedMembers_Validate(string entityName, IOrganizationService service, ITracingService tracingService, UploadValidationResponse jsonObject, EntityCollection basic_data_from_CRM, Guid _policy_guid)
        {
            tracingService.Trace($"GetMatchedMembers_Validate started");

            IList<Member> members = new List<Member>();

            if (jsonObject == null) { return null; }

            var matched_crm_records = GetMembersFromCRM(tracingService, basic_data_from_CRM, true);

            foreach (MatchedMember eachMember in jsonObject.MatchedMembers)
            {
                //adnic_census_upload_virtual
                var crm_matched_record = matched_crm_records.FirstOrDefault(e => e.GetAttributeValue<string>("adnic_pf_no") == eachMember.Member.PfNo);
                var crm_guid = crm_matched_record?.Id;

                tracingService.Trace($"Member Name {eachMember.Member.MemberName}");

                tracingService.Trace($"Matched CRM Record GUID {crm_guid}");

                var updatedMember = this.GetUpdatedMember(service, tracingService, _policy_guid.ToString(), crm_guid.ToString());

                if (updatedMember != null)
                {
                    this.UpdateOriginalMember(eachMember.Member, updatedMember, tracingService);
                }

                members.Add(eachMember.Member);
            }
            tracingService.Trace($"GetMatchedMembers_Validate End");
            return members;
        }
        internal IList<Entity> GetMatchedMembers(string entityName, IOrganizationService service, ITracingService tracingService, UploadValidationResponse jsonObject, EntityCollection basic_data_from_CRM,Guid _policy_guid)
        {
            tracingService.Trace($"GetMatchedMembers started");

            IList<Entity> members = new List<Entity>();

            if (jsonObject == null) { return members; }

            var matched_crm_records = GetMembersFromCRM(tracingService, basic_data_from_CRM, true);

            foreach (MatchedMember eachMember in jsonObject.MatchedMembers)
            {
                //adnic_census_upload_virtual
                var crm_matched_record = matched_crm_records.FirstOrDefault(e => e.GetAttributeValue<string>("adnic_pf_no") == eachMember.Member.PfNo);
                var crm_guid = crm_matched_record?.Id;

                tracingService.Trace($"Member Name {eachMember.Member.MemberName}");

                tracingService.Trace($"Matched CRM Record GUID {crm_guid}");

                var updatedMember = this.GetUpdatedMember(service, tracingService, _policy_guid.ToString(), crm_guid.ToString());

                if (updatedMember != null)
                {
                    this.UpdateOriginalMember(eachMember.Member, updatedMember, tracingService);
                }

                Entity eachOne = PrepareCRMRecord(entityName, tracingService, eachMember.Member, crm_guid,true);

                //tracingService.Trace($"SNo:{eachMember.Member.RowNumber}\nName:{eachMember.Member.MemberName}\n PF NO:{eachMember.Member.PfNo}\nCategory:{eachMember.Member.MemberCategory}\nGender:{eachMember.Member.Gender}\nDOB:{eachMember.Member.DateOfBirth}\n");
                if (eachOne != null)
                {
                    members.Add(eachOne);
                }
            }
            tracingService.Trace($"GetMatchedMembers End");
            return members;
        }
        private Entity PrepareCRMRecord(string entityName, ITracingService tracingService, Member eachMember, Guid? crm_guid,bool isMatched)
        {
            if (!crm_guid.HasValue)
            {
                tracingService.Trace("PrepareCRMRecord::CRM GUid is null.");
                return null;
            }

            var gender_ref = this.getReferenceRecord(Constants.MasterData_Gender, eachMember.Gender, this._referenec_data, tracingService);
            var martial_ref = this.getReferenceRecord(Constants.MasterData_MARITAL_STATUS, eachMember.MaritalStatus, this._referenec_data, tracingService);

            var eachOne = new Entity(entityName, crm_guid.Value)
            {
                Attributes =
                            {
                            [$"{entityName}id"]=crm_guid.Value,
                            ["adnic_sno"]=eachMember.RowNumber,
                            ["adnic_pf_no"]=eachMember.PfNo,
                             ["adnic_dob"]=ConvertDobToCrmDateTime(eachMember.DateOfBirth,tracingService),
                            ["adnic_medical_declaration"]=eachMember.RequiresMedicalUnderwriting, //.ToLower() == "true",
                            ["adnic_relation"]=eachMember.Relation,
                            ["adnic_name"]=eachMember.MemberName,
                             ["statecode"]=new OptionSetValue(0),
                             ["adnic_validation_remarks"]=string.Join(";", eachMember.ValidationErrors),
                            ["adnic_validation_status"]=eachMember.RecordStatus,
                             ["adnic_is_matched"]=isMatched
                }
            }; //

            this.SetEntityField(eachMember.Gender, "adnic_gender_id", Constants.MasterData_Gender, tracingService, this._referenec_data, eachOne);
            this.SetEntityField(eachMember.MaritalStatus, "adnic_marital_id", Constants.MasterData_MARITAL_STATUS, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.Commission, "adnic_comission_id", Constants.MasterData_COMMISSION, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.Country, "adnic_country_id", Constants.MasterData_Countries, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.MemberCategory, "adnic_member_category_id", Constants.MasterData_Member_Category, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.Nationality, "adnic_nationality_id", Constants.MasterData_Countries, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.SponsorType, "adnic_sponsor_type", Constants.MasterData_SPONSER_TYPE, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.VisaEmirate, "adnic_visa_emirate_id", Constants.MasterData_Visa_Emirate, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.VisaType, "adnic_visa_type_id", Constants.MasterData_Visa_Type, tracingService, this._referenec_data, eachOne);

            this.SetEntityField(eachMember.WorkLocation, "adnic_work_location_id", Constants.MasterData_Work_Location, tracingService, this._referenec_data, eachOne);

            //this.SetFormattedValueForMasterData(eachMember.Gender, "adnic_gender_id", tracingService, gender_ref, eachOne);
            //this.SetFormattedValueForMasterData(eachMember.MaritalStatus, "adnic_marital_id", tracingService, martial_ref, eachOne);


            return eachOne;
        }
        internal void SetEntityField(string member_value, string fieldSchema,string category, ITracingService tracingService, IList<Entity> ref_collection, Entity entity)
        {
            tracingService.Trace($"SetEntityField:: Field name {fieldSchema}");

            string m_value = member_value;
            string fieldName = fieldSchema;

            var md_ref = this.getReferenceRecord(category, m_value, ref_collection, tracingService);
            entity[fieldName] = md_ref;
            this.SetFormattedValueForMasterData(m_value, fieldName, tracingService, md_ref, entity);
        }
        internal void SetFormattedValueForMasterData(string displayValue, string fieldSchemaName, ITracingService tracingService, EntityReference masterRecord_ref, Entity entity)
        {

            entity[fieldSchemaName] = masterRecord_ref;
            if (masterRecord_ref != null)
            {
                tracingService.Trace($"Setting formatted value {displayValue}");
                entity.FormattedValues[fieldSchemaName] = displayValue;
            }
        }

        internal void MergeMember(Member original, Member updated)
        {
            foreach (PropertyInfo property in typeof(Member).GetProperties())
            {
                object updatedValue = property.GetValue(updated);

                // Handle strings
                if (property.PropertyType == typeof(string))
                {
                    if (!string.IsNullOrWhiteSpace(updatedValue as string))
                    {
                        property.SetValue(original, updatedValue);
                    }
                }
                // Handle collections
                else if (property.PropertyType == typeof(List<string>))
                {
                    if (updatedValue != null && ((List<string>)updatedValue).Count > 0)
                    {
                        property.SetValue(original, updatedValue);
                    }
                }
                // Handle value types (bool, int, etc.)
                else if (updatedValue != null)
                {
                    property.SetValue(original, updatedValue);
                }
            }
        }

        internal IList<Entity> GetReferenceData(IOrganizationService service, ITracingService tracingService)
        {
            var fetchXml = @"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                          <entity name='adnic_refernce_data'>
                            <attribute name='adnic_key' />
                            <attribute name='adnic_name' />
                            <attribute name='adnic_type' />
                            <attribute name='adnic_value' />
                            <attribute name='adnic_refernce_dataid' />
                            <filter>
                              <condition attribute='statecode' operator='eq' value='0' />
                            </filter>
                          </entity>
                        </fetch>";

            var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));
            return resultSet?.Entities;
        }

        internal EntityReference getReferenceRecord(string category, string displayValue, IList<Entity> ref_collection, ITracingService tracingService)
        {
            tracingService.Trace($" Category {category} :: code {displayValue}");

            if (string.IsNullOrEmpty(displayValue)) return null;

            var ref_Record = ref_collection.ToList().Where(e => e.GetAttributeValue<string>("adnic_type").ToLower() == category.ToLower()).FirstOrDefault(e =>
            {
                return e.GetAttributeValue<string>("adnic_value").ToLower() == displayValue.ToLower();
            });

            tracingService.Trace($"Ref record Guid {ref_Record?.Id}");

            var ef = ref_Record == null ? null : new EntityReference(ref_Record.LogicalName, ref_Record.Id);

            return ef;
        }

        public string GetEnvironmentVariableValue(
    IOrganizationService service,
    string schemaName)
        {
            var query = new QueryExpression("environmentvariabledefinition")
            {
                ColumnSet = new ColumnSet(
                    "environmentvariabledefinitionid",
                    "defaultvalue")
            };

            query.Criteria.AddCondition(
                "schemaname",
                ConditionOperator.Equal,
                schemaName);

            query.LinkEntities.Add(new LinkEntity(
                "environmentvariabledefinition",
                "environmentvariablevalue",
                "environmentvariabledefinitionid",
                "environmentvariabledefinitionid",
                JoinOperator.LeftOuter)
            {
                EntityAlias = "value",
                Columns = new ColumnSet("value")
            });

            var result = service.RetrieveMultiple(query)
                .Entities
                .FirstOrDefault();

            if (result == null)
                return null;

            // Current Value
            if (result.Contains("value.value"))
            {
                return ((AliasedValue)result["value.value"])
                    .Value
                    ?.ToString();
            }

            // Fallback to Default Value
            return result.GetAttributeValue<string>("defaultvalue");
        }
        internal void UpdateOriginalMember(
    Member original,
    Member updated,
    ITracingService tracingService)
        {
            if (original == null || updated == null)
            {
                tracingService.Trace("original or updated Member is null");
                return;
            }

            tracingService.Trace("Updating original member: {0}",
                original.MemberName);

            tracingService.Trace($"Updated Member name :: {updated?.MemberName}");

            // Only update if value changed
            //if (original.MemberName != updated.MemberName)
            if (!string.IsNullOrEmpty(updated.MemberName))
            {
                tracingService.Trace("MemberName: {0} → {1}",
                    original.MemberName, updated.MemberName);
                original.MemberName = updated.MemberName;
            }

            tracingService.Trace("memeber name");
            if (!string.IsNullOrEmpty(updated.DateOfBirth))
            {
                tracingService.Trace("DateOfBirth: {0} → {1}",
                    original.DateOfBirth, updated.DateOfBirth);
                original.DateOfBirth = updated.DateOfBirth;
            }

            tracingService.Trace("2");

            if (!string.IsNullOrEmpty(updated.Gender))
            {
                tracingService.Trace("Gender: {0} → {1}",
                    original.Gender, updated.Gender);
                original.Gender = updated.Gender;
            }

            if (!string.IsNullOrEmpty(updated.SponsorType))
            {
                tracingService.Trace("SponsorType: {0} → {1}",
                    original.SponsorType, updated.SponsorType);
                original.SponsorType = updated.SponsorType;
            }

            if (!string.IsNullOrEmpty(updated.MemberCategory))
            {
                tracingService.Trace("SponsorType: {0} → {1}",
                    original.MemberCategory, updated.MemberCategory);
                original.MemberCategory = updated.MemberCategory;
            }

            if (!string.IsNullOrEmpty(updated.WorkLocation))
            {
                tracingService.Trace("SponsorType: {0} → {1}",
                    original.WorkLocation, updated.WorkLocation);
                original.WorkLocation = updated.WorkLocation;
            }

            //Madan
            if (!string.IsNullOrEmpty(updated.MaritalStatus))
            {
                tracingService.Trace("MaritalStatus: {0} → {1}",
                    original.MaritalStatus, updated.MaritalStatus);
                original.MaritalStatus = updated.MaritalStatus;
            }

            if (!string.IsNullOrEmpty(updated.VisaEmirate))
            {
                tracingService.Trace("VisaEmirate: {0} → {1}",
                    original.VisaEmirate, updated.VisaEmirate);
                original.VisaEmirate = updated.VisaEmirate;
            }

            if (!string.IsNullOrEmpty(updated.VisaType))
            {
                tracingService.Trace("VisaType: {0} → {1}",
                    original.VisaType, updated.VisaType);
                original.VisaType = updated.VisaType;
            }

            if (!string.IsNullOrEmpty(updated.VisaLocation))
            {
                tracingService.Trace("VisaLocation: {0} → {1}",
                    original.VisaLocation, updated.VisaLocation);
                original.VisaLocation = updated.VisaLocation;
            }

            tracingService.Trace("3");
            if (!string.IsNullOrEmpty(updated.Relation))
            {
                tracingService.Trace("Relation: {0} → {1}",
                    original.Relation, updated.Relation);
                original.Relation = updated.Relation;
            }

            tracingService.Trace("4");

            if (!string.IsNullOrEmpty(updated.Dependency))
            {
                tracingService.Trace("Dependency: {0} → {1}",
                    original.Dependency, updated.Dependency);
                original.Dependency = updated.Dependency;
            }

            tracingService.Trace("5");

            if (!string.IsNullOrEmpty(updated.PfNo))
            {
                tracingService.Trace("PfNo: {0} → {1}",
                    original.PfNo, updated.PfNo);
                original.PfNo = updated.PfNo;
            }

            tracingService.Trace("6");


            if (!string.IsNullOrEmpty(updated.EmiratesId))
            {
                tracingService.Trace("EmiratesId: {0} → {1}",
                    original.EmiratesId, updated.EmiratesId);
                original.EmiratesId = updated.EmiratesId;
            }

            tracingService.Trace("7");


            if (!string.IsNullOrEmpty(updated.PassportNo))
            {
                tracingService.Trace("PassportNo: {0} → {1}",
                    original.PassportNo, updated.PassportNo);
                original.PassportNo = updated.PassportNo;
            }


            tracingService.Trace("8");

            if (!string.IsNullOrEmpty(updated.MobileNo))
            {
                tracingService.Trace("MobileNo: {0} → {1}",
                    original.MobileNo, updated.MobileNo);
                original.MobileNo = updated.MobileNo;
            }

            tracingService.Trace("9");

            if (!string.IsNullOrEmpty(updated.EmailId))
            {
                tracingService.Trace("EmailId: {0} → {1}",
                    original.EmailId, updated.EmailId);
                original.EmailId = updated.EmailId;
            }

            tracingService.Trace("10");

            if (!string.IsNullOrEmpty(updated.EffectiveDate))
            {
                tracingService.Trace("EffectiveDate: {0} → {1}",
                    original.EffectiveDate, updated.EffectiveDate);
                original.EffectiveDate = updated.EffectiveDate;
            }

            tracingService.Trace("11");

            if (!string.IsNullOrEmpty(updated.PreviousCoverageDate))
            {
                tracingService.Trace("PreviousCoverageDate: {0} → {1}",
                    original.PreviousCoverageDate, updated.PreviousCoverageDate);
                original.PreviousCoverageDate = updated.PreviousCoverageDate;
            }

            tracingService.Trace("12");

            if (!string.IsNullOrEmpty(updated.ChangeOfStatusDate))
            {
                tracingService.Trace("ChangeOfStatusDate: {0} → {1}",
                    original.ChangeOfStatusDate, updated.ChangeOfStatusDate);
                original.ChangeOfStatusDate = updated.ChangeOfStatusDate;
            }

            tracingService.Trace("13");

            if (!string.IsNullOrEmpty(updated.ResidenceLocation))
            {
                tracingService.Trace("ResidenceLocation: {0} → {1}",
                    original.ResidenceLocation, updated.ResidenceLocation);
                original.ResidenceLocation = updated.ResidenceLocation;
            }

            tracingService.Trace("14");

            if (!string.IsNullOrEmpty(updated.SalaryBand))
            {
                tracingService.Trace("SalaryBand: {0} → {1}",
                    original.SalaryBand, updated.SalaryBand);
                original.SalaryBand = updated.SalaryBand;
            }

            tracingService.Trace("15");

            if (!string.IsNullOrEmpty(updated.ClassNo))
            {
                tracingService.Trace("ClassNo: {0} → {1}",
                    original.ClassNo, updated.ClassNo);
                original.ClassNo = updated.ClassNo;
            }

            tracingService.Trace("16");

            if (!string.IsNullOrEmpty(updated.BirthCertificateId))
            {
                tracingService.Trace("BirthCertificateId: {0} → {1}",
                    original.BirthCertificateId, updated.BirthCertificateId);
                original.BirthCertificateId = updated.BirthCertificateId;
            }

            tracingService.Trace("17");

            if (!string.IsNullOrEmpty(updated.Nationality))
            {
                tracingService.Trace("Nationality: {0} → {1}",
                    original.Nationality, updated.Nationality);
                original.Nationality = updated.Nationality;
            }

            tracingService.Trace("18");

            //if (!string.IsNullOrEmpty(updated.RequiresMedicalUnderwriting))
            //{
                tracingService.Trace("RequiresMedicalUnderwriting: {0} → {1}",
                    original.RequiresMedicalUnderwriting,
                    updated.RequiresMedicalUnderwriting);
                original.RequiresMedicalUnderwriting =
                    updated.RequiresMedicalUnderwriting;
            //}

            tracingService.Trace("19");

            if (!string.IsNullOrEmpty(updated.RecordStatus))
            {
                tracingService.Trace("RecordStatus: {0} → {1}",
                    original.RecordStatus, updated.RecordStatus);
                original.RecordStatus = updated.RecordStatus;
            }

            tracingService.Trace("20");

            if (!string.IsNullOrEmpty(updated.Height))
            {
                tracingService.Trace("Height: {0} → {1}",
                    original.Height, updated.Height);
                original.Height = updated.Height;
            }

            if (!string.IsNullOrEmpty(updated.Weight))
            {
                tracingService.Trace("Height: {0} → {1}",
                    original.Weight, updated.Weight);
                original.Weight = updated.Weight;
            }

            tracingService.Trace("Original member updated successfully.");
        }
        internal void PrintEntityAttributes(
    Entity entity,
    ITracingService tracingService)
        {
            if (entity == null)
            {
                tracingService.Trace("Entity is null.");
                return;
            }

            tracingService.Trace("=== Entity: {0}, ID: {1} ===",
                entity.LogicalName, entity.Id);

            tracingService.Trace("Total Attributes: {0}",
                entity.Attributes.Count);

            foreach (var attribute in entity.Attributes)
            {
                var key = attribute.Key;
                var value = attribute.Value;

                if (value == null)
                {
                    tracingService.Trace("  {0} = null", key);
                    continue;
                }

                // Format value based on type
                switch (value)
                {
                    case string s:
                        tracingService.Trace("  {0} = '{1}' [String]", key, s);
                        break;

                    case int i:
                        tracingService.Trace("  {0} = {1} [Int]", key, i);
                        break;

                    case decimal d:
                        tracingService.Trace("  {0} = {1} [Decimal]", key, d);
                        break;

                    case double db:
                        tracingService.Trace("  {0} = {1} [Double]", key, db);
                        break;

                    case bool b:
                        tracingService.Trace("  {0} = {1} [Bool]", key, b);
                        break;

                    case DateTime dt:
                        tracingService.Trace("  {0} = {1} [DateTime]",
                            key, dt.ToString("yyyy-MM-dd HH:mm:ss"));
                        break;

                    case Guid g:
                        tracingService.Trace("  {0} = {1} [Guid]", key, g);
                        break;

                    case Money m:
                        tracingService.Trace("  {0} = {1} [Money]", key, m.Value);
                        break;

                    case OptionSetValue osv:
                        tracingService.Trace("  {0} = {1} [OptionSet]",
                            key, osv.Value);
                        break;

                    case EntityReference er:
                        tracingService.Trace("  {0} = {1} | {2} | {3} [EntityRef]",
                            key, er.Id, er.LogicalName, er.Name ?? "null");
                        break;

                    case EntityCollection ec:
                        tracingService.Trace("  {0} = [{1} records] [EntityCollection]",
                            key, ec.Entities.Count);
                        break;



                    case AliasedValue av:
                        tracingService.Trace("  {0} = {1} | EntityAlias: {2} [Aliased]",
                            key,
                            av.Value?.ToString() ?? "null",
                            av.EntityLogicalName);
                        break;

                    default:
                        tracingService.Trace("  {0} = {1} [{2}]",
                            key,
                            value.ToString(),
                            value.GetType().Name);
                        break;
                }
            }

            tracingService.Trace("=== End of Entity ===");
        }

       
    }
   
}

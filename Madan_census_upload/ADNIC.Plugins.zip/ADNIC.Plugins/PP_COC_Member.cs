﻿using System;
using System.Text.Json.Serialization;

namespace ADNIC.Plugins
{
    public class PP_COC_Member
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("srNo")]
        public int? SrNo { get; set; }

        [JsonPropertyName("pfNo")]
        public string PfNo { get; set; }

        [JsonPropertyName("memberNo")]
        public string MemberNo { get; set; }

        [JsonPropertyName("memberName")]
        public string MemberName { get; set; }

        [JsonPropertyName("dateOfBirth")]
        public string DateOfBirth { get; set; }

        [JsonPropertyName("gender")]
        public string Gender { get; set; }

        [JsonPropertyName("dependency")]
        public string Dependency { get; set; }

        [JsonPropertyName("maritalStatus")]
        public string MaritalStatus { get; set; }

        [JsonPropertyName("effectiveDate")]
        public string EffectiveDate { get; set; }

        [JsonPropertyName("previousCoverageDate")]
        public string PreviousCoverageDate { get; set; }

        [JsonPropertyName("changeOfStatusDate")]
        public string ChangeOfStatusDate { get; set; }

        [JsonPropertyName("emiratesId")]
        public string EmiratesId { get; set; }

        [JsonPropertyName("eidApplicationNo")]
        public string EidApplicationNo { get; set; }

        [JsonPropertyName("entryPermitNo")]
        public string EntryPermitNo { get; set; }

        [JsonPropertyName("visaType")]
        public string VisaType { get; set; }

        [JsonPropertyName("visaEmirate")]
        public string VisaEmirate { get; set; }

        [JsonPropertyName("classNo")]
        public string ClassNo { get; set; }

        [JsonPropertyName("nationality")]
        public string Nationality { get; set; }

        [JsonPropertyName("passportNo")]
        public string PassportNo { get; set; }

        [JsonPropertyName("uidNo")]
        public string UidNo { get; set; }

        [JsonPropertyName("mobileNo")]
        public string MobileNo { get; set; }

        [JsonPropertyName("emailId")]
        public string EmailId { get; set; }

        [JsonPropertyName("thiqaCardNo")]
        public string ThiqaCardNo { get; set; }

        [JsonPropertyName("position")]
        public string Position { get; set; }

        [JsonPropertyName("workLocation")]
        public string WorkLocation { get; set; }

        [JsonPropertyName("residenceLocation")]
        public string ResidenceLocation { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("memberCategory")]
        public string MemberCategory { get; set; }

        [JsonPropertyName("salaryBand")]
        public string SalaryBand { get; set; }

        [JsonPropertyName("commission")]
        public string Commission { get; set; }

        [JsonPropertyName("birthCertificateId")]
        public string BirthCertificateId { get; set; }

        [JsonPropertyName("sponsorType")]
        public string SponsorType { get; set; }

        [JsonPropertyName("sponsorId")]
        public string SponsorId { get; set; }

        [JsonPropertyName("heightCm")]
        public decimal? HeightCm { get; set; }

        [JsonPropertyName("weightKg")]
        public decimal? WeightKg { get; set; }

        [JsonPropertyName("medicalCondition")]
        public string MedicalCondition { get; set; }

        [JsonPropertyName("documentStatus")]
        public string DocumentStatus { get; set; }

        [JsonPropertyName("premium")]
        public decimal? Premium { get; set; }

        [JsonPropertyName("loadingAmount")]
        public decimal? LoadingAmount { get; set; }

        [JsonPropertyName("premiumAfterLoading")]
        public decimal? PremiumAfterLoading { get; set; }

        [JsonPropertyName("entrantType")]
        public string EntrantType { get; set; }

        [JsonPropertyName("entryDate")]
        public string EntryDate { get; set; }

        [JsonPropertyName("cocFine")]
        public decimal? CocFine { get; set; }

        [JsonPropertyName("cocStatus")]
        public string CocStatus { get; set; }

        [JsonPropertyName("prStatus")]
        public string PrStatus { get; set; }

        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("createdBy")]
        public string CreatedBy { get; set; }

        [JsonPropertyName("updatedBy")]
        public string UpdatedBy { get; set; }

        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; }

        [JsonPropertyName("updatedAt")]
        public DateTime UpdatedAt { get; set; }

        [JsonPropertyName("version")]
        public int Version { get; set; }

        [JsonPropertyName("deleted")]
        public bool Deleted { get; set; }

        [JsonPropertyName("validationStatus")]
        public string ValidationStatus { get; set; }

        [JsonPropertyName("validationRemark")]
        public string ValidationRemark { get; set; }

        [JsonPropertyName("cocCalcType")]
        public string CocCalcType { get; set; }

        [JsonPropertyName("cocPaymentReferenceNumber")]
        public string CocPaymentReferenceNumber { get; set; }

        [JsonPropertyName("dohReferenceNumber")]
        public string DohReferenceNumber { get; set; }

        [JsonPropertyName("cocValidityDate")]
        public string CocValidityDate { get; set; }

        [JsonPropertyName("cocBatchId")]
        public string CocBatchId { get; set; }

        [JsonPropertyName("cocBatchStatus")]
        public string CocBatchStatus { get; set; }

        [JsonPropertyName("cocNonInsuranceDays")]
        public int? CocNonInsuranceDays { get; set; }

        [JsonPropertyName("cocGapInCoverDays")]
        public int? CocGapInCoverDays { get; set; }

        [JsonPropertyName("cocGapInCoverMonthsWeeks")]
        public string CocGapInCoverMonthsWeeks { get; set; }

        [JsonPropertyName("cocWaiveOffPer")]
        public decimal? CocWaiveOffPer { get; set; }

        [JsonPropertyName("cocPerMemberError")]
        public string CocPerMemberError { get; set; }

        [JsonPropertyName("cocLastCheckedAt")]
        public DateTime? CocLastCheckedAt { get; set; }

        [JsonPropertyName("cocIntegrationTxnId")]
        public int? CocIntegrationTxnId { get; set; }

        [JsonPropertyName("ppTargetErrorCode")]
        public int? PpTargetErrorCode { get; set; }

        [JsonPropertyName("ppTargetErrorDesc")]
        public string PpTargetErrorDesc { get; set; }

        [JsonPropertyName("ppSponsorNo")]
        public string PpSponsorNo { get; set; }

        [JsonPropertyName("ppSponsorEn")]
        public string PpSponsorEn { get; set; }

        [JsonPropertyName("ppOccupationEn")]
        public string PpOccupationEn { get; set; }

        [JsonPropertyName("ppNationalityEn")]
        public string PpNationalityEn { get; set; }

        [JsonPropertyName("ppPassportExpiry")]
        public string PpPassportExpiry { get; set; }

        [JsonPropertyName("ppLastCheckedAt")]
        public DateTime? PpLastCheckedAt { get; set; }

        [JsonPropertyName("ppRemark")]
        public string PpRemark { get; set; }

        [JsonPropertyName("ppIntegrationTxnId")]
        public int? PpIntegrationTxnId { get; set; }
    }
}

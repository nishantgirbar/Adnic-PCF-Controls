﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    public class CensusData_PreDelete : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider
                .GetService(typeof(IPluginExecutionContext));

            var tracingService = (ITracingService)serviceProvider
                .GetService(typeof(ITracingService));

            var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                .GetService(typeof(IOrganizationServiceFactory));

            var systemOrgService = orgServiceFactory
                .CreateOrganizationService(null);

            try
            {
                tracingService.Trace("PreOperation Delete started.");
                tracingService.Trace("Record ID: {0}", context.PrimaryEntityId);

                // Step 1: Get updated fields from Target
                var target = (Entity)context.InputParameters["Target"];

                Guid policyGuid = Guid.Empty;
                if (context.PreEntityImages.Contains("PreImage"))
                {
                    tracingService.Trace("pre image exists");

                    var pi = context.PreEntityImages["PreImage"];
                    policyGuid = pi.GetAttributeValue<EntityReference>("adnic_policy_id").Id;
                }

                tracingService.Trace("Policy Guid: {0}", policyGuid);

                SaveToExternalTable(
                    policyGuid,
                    context.PrimaryEntityId,
                    systemOrgService,
                    tracingService);

                //target = new Entity(context.PrimaryEntityName, context.PrimaryEntityId);

                tracingService.Trace("PreOperation completed.");
            }
            catch (Exception ex)
            {
                tracingService.Trace("Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(ex.Message, ex);
            }
        }
        private Entity MergeRecords(
            Entity preImage,
            Entity target,
            ITracingService tracingService)
        {
            // Start with PreImage as base
            var merged = new Entity(target.LogicalName, target.Id);

            // Copy all PreImage attributes
            //foreach (var attr in preImage.Attributes)
            //    merged[attr.Key] = attr.Value;

            // Override with Target (updated values)
            foreach (var attr in target.Attributes)
            {
                if (attr.Key.StartsWith("adnic_"))
                {
                    tracingService.Trace("Updated field — {0}: {1}",
                        attr.Key, attr.Value?.ToString() ?? "null");
                    merged[attr.Key] = attr.Value;
                }
            }

            tracingService.Trace("Merged record attributes: {0}",
                merged.Attributes.Count);

            return merged;
        }

        private object BuildMemberJson(
            Entity record,
            ITracingService tracingService)
        {
            return new
            {
                pfNo = GetString(record, "adnic_pf_no"),
                memberName = GetString(record, "adnic_name"),
                dob = GetDateString(record, "adnic_dob"),
            };
        }

        private void SaveToExternalTable(
            Guid policyId,
            Guid censusRecordId,
            IOrganizationService orgService,
            ITracingService tracingService)
        {
            tracingService.Trace("Saving JSON to adnic_external_data.");
            if (policyId != Guid.Empty)
            {
                // Check if record already exists
                var existingId = GetExistingValidationRecord(policyId, censusRecordId, orgService, tracingService);

                var entity = new Entity("adnic_external_data");

                tracingService.Trace($"Policy guid {policyId}");
                tracingService.Trace($"censusRecordId guid {censusRecordId}");
                // Link to Policy

                entity["adnic_policy_guid"] = policyId.ToString();
                entity["adnic_is_deleted"] = true;
                entity.Id = existingId;
                orgService.Update(entity);
                tracingService.Trace("Updated is_delete field in adnic_external_data record: {0}", existingId);
            }
        }


        private Guid GetExistingValidationRecord(
            Guid policyGuid,
            Guid currentRecordGuid,
            IOrganizationService service,
            ITracingService tracingService)
        {
            var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />
                                    <attribute name='adnic_external_dataid' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='CensusMemberUpdate' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policyGuid}' />                                       
                                    <condition attribute='adnic_census_data_id' operator='eq' value='{currentRecordGuid}' />  
 
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";


            tracingService.Trace("adnic_external_data::Executing JSON query");

            var results = service.RetrieveMultiple(new FetchExpression(fetchXml));

            tracingService.Trace($"Count {results.Entities.Count}");

            if (results.Entities.Count > 0)
            {
                var id = results.Entities[0].GetAttributeValue<Guid>("adnic_external_dataid");
                tracingService.Trace("adnic_external_data::Existing validation record found: {0}", id);
                return id;
            }

            tracingService.Trace("adnic_external_data::No existing validation record.");
            return Guid.Empty;
        }

        private Guid GetPolicyId(
            Entity record,
            ITracingService tracingService)
        {
            if (record.Contains("adnic_policy_id") &&
                record["adnic_policy_id"] is EntityReference er)
            {
                tracingService.Trace("Policy ID: {0}", er.Id);
                return er.Id;
            }

            tracingService.Trace("Policy ID not found.");
            return Guid.Empty;
        }

        private string GetString(Entity record, string field)
        {
            if (!record.Contains(field) || record[field] == null)
                return string.Empty;

            var value = record[field];

            if (value is OptionSetValue osv)
                return osv.Value.ToString();

            if (value is EntityReference er)
                return er.Name ?? er.Id.ToString();

            if (value is Money m)
                return m.Value.ToString();

            if (value is bool b)
                return b.ToString().ToLower();

            if (value is DateTime dt)
                return dt.ToString("yyyy-MM-dd HH:mm:ss");

            if (value is decimal d)
                return d.ToString();

            if (value is int i)
                return i.ToString();

            return value.ToString();
        }

        private string GetDateString(Entity record, string field)
        {
            if (!record.Contains(field) || record[field] == null)
                return string.Empty;

            if (record[field] is DateTime dt)
                return dt.ToString("yyyy-MM-dd");

            return string.Empty;
        }

        private bool GetBool(Entity record, string field)
        {
            return record.Contains(field) &&
                   record[field] is bool b && b;
        }
    }
}

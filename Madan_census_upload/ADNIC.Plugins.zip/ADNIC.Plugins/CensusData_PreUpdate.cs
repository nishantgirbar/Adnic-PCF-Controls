﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    public class CensusData_PreUpdate : IPlugin
    {
        private Census_helper _census_Helper = null;
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider
                .GetService(typeof(IPluginExecutionContext));

            var tracingService = (ITracingService)serviceProvider
                .GetService(typeof(ITracingService));

            var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                .GetService(typeof(IOrganizationServiceFactory));

            var service = orgServiceFactory
                .CreateOrganizationService(context.UserId);

            try
            {
                tracingService.Trace("PreOperation Update started.");
                tracingService.Trace("Record ID: {0}", context.PrimaryEntityId);

                _census_Helper = new Census_helper();

                // Step 1: Get updated fields from Target
                var target = (Entity)context.InputParameters["Target"];
                Entity preImage = null;
                Guid policyGuid = Guid.Empty;

                if (context.PreEntityImages.Contains("PreImage"))
                {
                    tracingService.Trace("pre image exists");
                    var pi = context.PreEntityImages["PreImage"];
                    preImage = pi;
                    policyGuid = pi.GetAttributeValue<EntityReference>("adnic_policy_id").Id;
                }


                //UPDATE 
                var mergedRecord = MergeRecords(target, policyGuid, service, tracingService);

                tracingService.Trace("Policy Guid: {0}", policyGuid);

                var memberJson = BuildMemberJson(mergedRecord, tracingService, service);

                string json = System.Text.Json.JsonSerializer.Serialize(
                    memberJson,
                    new System.Text.Json.JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                tracingService.Trace("JSON built: {0}", json);

                SaveToExternalTable(
                    policyGuid,
                    context.PrimaryEntityId,
                    json,
                    service,
                    tracingService);

                this.UpdateCensusUpload_with_updatedJson(tracingService, service, target, policyGuid, json, preImage);

                target.Attributes.Clear();

                tracingService.Trace("PreOperation completed.");
            }
            catch (Exception ex)
            {
                tracingService.Trace("Error: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(ex.Message, ex);
            }
        }

        private void UpdateCensusUpload_with_updatedJson(ITracingService tracingService, IOrganizationService service, Entity target, Guid policyGuid, string json,Entity preImage)
        {
            tracingService.Trace($"UpdateCensusUpload_with_updatedJson started.");

            if (!string.IsNullOrEmpty(json))
            {
                var original_json_obj_dict = _census_Helper.GetOriginalJson(service, tracingService, policyGuid);
                tracingService.Trace($"original_json_obj_dict count {original_json_obj_dict.Count}");

                if (original_json_obj_dict.Count > 0)
                {
                    var original_json_obj = original_json_obj_dict.FirstOrDefault();

                    Member member = _census_Helper.GetUpdatedMember(service, tracingService, policyGuid.ToString(), target.Id.ToString());
                    this.MergeMemberDetails_with_originalJson(tracingService, original_json_obj.Value, member, preImage);

                    var options = new JsonSerializerOptions { WriteIndented = true };
                    string jsonString = JsonSerializer.Serialize(original_json_obj.Value, options);

                    this.UpdateExternalTableWith_updatedJson(service, tracingService, original_json_obj.Key, jsonString);
                }
            }

            tracingService.Trace($"UpdateCensusUpload_with_updatedJson End.");
        }


        public void MergeMemberDetails_with_originalJson(ITracingService tracingService, UploadValidationResponse response, Member memberDetails,Entity preImage)
        {
            tracingService.Trace($"MergeMemberDetails_with_originalJson started");

            if (memberDetails == null)
                return;

            var name = preImage.GetAttributeValue<string>("adnic_name");
            var pf_no = preImage.GetAttributeValue<string>("adnic_pf_no");

            tracingService.Trace($"MergeMemberDetails_with_originalJson:: PreImage:: Name: {name} pf_no::{pf_no}");

            if (response?.Members != null)
            {
                tracingService.Trace($"Members applymatch");
                foreach (var responseMember in response.Members)
                {
                    ApplyMatch(tracingService, responseMember, memberDetails,preImage);
                }
            }

            if (response?.MatchedMembers != null)
            {
                tracingService.Trace($"MatchedMembers applymatch");
                foreach (var matchedMember in response.MatchedMembers)
                {
                    ApplyMatch(tracingService, matchedMember.Member, memberDetails,preImage);
                }
            }

            if (response?.MismatchedMembers != null)
            {
                tracingService.Trace($"MismatchedMembers applymatch");

                foreach (var mismatchedMember in response.MismatchedMembers)
                {
                    ApplyMatch(tracingService, mismatchedMember.Member, memberDetails,preImage);
                }
            }

            tracingService.Trace($"MergeMemberDetails_with_originalJson End");
        }

        private void ApplyMatch(ITracingService tracingService, Member responseMember, Member memberDetails, Entity preImage)
        {
            //tracingService.Trace($"ApplyMatch started");

            if (responseMember == null)
                return;

            var name=preImage.GetAttributeValue<string>("adnic_name");
            var pf_no=preImage.GetAttributeValue<string>("adnic_pf_no");

            tracingService.Trace($"preimage details :: {name} {pf_no}");
            tracingService.Trace($"original details :: {responseMember.MemberName} {responseMember.PfNo}");

            if (!string.Equals(responseMember.MemberName, name, StringComparison.OrdinalIgnoreCase) && !string.Equals(responseMember.PfNo, pf_no, StringComparison.OrdinalIgnoreCase))
            {
                tracingService.Trace($"ApplyMatch::matched details not found");
                return;
            }

            
            tracingService.Trace($"ApplyMatch::matched details found");


            if (!string.IsNullOrEmpty(memberDetails.Relation))
                responseMember.Relation = memberDetails.Relation;
            if (!string.IsNullOrEmpty(memberDetails.Gender))
                responseMember.Gender = memberDetails.Gender;
            if (!string.IsNullOrEmpty(memberDetails.DateOfBirth))
                responseMember.DateOfBirth = memberDetails.DateOfBirth;
            if (!string.IsNullOrEmpty(memberDetails.SalaryType))
                responseMember.SalaryType = memberDetails.SalaryType;
            if (!string.IsNullOrEmpty(memberDetails.VisaLocation))
                responseMember.VisaLocation = memberDetails.VisaLocation;
            if (!string.IsNullOrEmpty(memberDetails.MaritalStatus))
                responseMember.MaritalStatus = memberDetails.MaritalStatus;
            if (memberDetails.SrNo != 0)
                responseMember.SrNo = memberDetails.SrNo;
            if (!string.IsNullOrEmpty(memberDetails.PfNo))
                responseMember.PfNo = memberDetails.PfNo;
            if (!string.IsNullOrEmpty(memberDetails.MemberNo))
                responseMember.MemberNo = memberDetails.MemberNo;
            if (!string.IsNullOrEmpty(memberDetails.MemberName))
                responseMember.MemberName = memberDetails.MemberName;
            if (!string.IsNullOrEmpty(memberDetails.Dependency))
                responseMember.Dependency = memberDetails.Dependency;
            if (!string.IsNullOrEmpty(memberDetails.EffectiveDate))
                responseMember.EffectiveDate = memberDetails.EffectiveDate;
            if (!string.IsNullOrEmpty(memberDetails.PreviousCoverageDate))
                responseMember.PreviousCoverageDate = memberDetails.PreviousCoverageDate;
            if (!string.IsNullOrEmpty(memberDetails.ChangeOfStatusDate))
                responseMember.ChangeOfStatusDate = memberDetails.ChangeOfStatusDate;
            if (!string.IsNullOrEmpty(memberDetails.EmiratesId))
                responseMember.EmiratesId = memberDetails.EmiratesId;
            if (!string.IsNullOrEmpty(memberDetails.EidApplicationNo))
                responseMember.EidApplicationNo = memberDetails.EidApplicationNo;
            if (!string.IsNullOrEmpty(memberDetails.EntryPermitNo))
                responseMember.EntryPermitNo = memberDetails.EntryPermitNo;
            if (!string.IsNullOrEmpty(memberDetails.VisaType))
                responseMember.VisaType = memberDetails.VisaType;
            if (!string.IsNullOrEmpty(memberDetails.VisaEmirate))
                responseMember.VisaEmirate = memberDetails.VisaEmirate;
            if (!string.IsNullOrEmpty(memberDetails.ClassNo))
                responseMember.ClassNo = memberDetails.ClassNo;
            if (!string.IsNullOrEmpty(memberDetails.Nationality))
                responseMember.Nationality = memberDetails.Nationality;
            if (!string.IsNullOrEmpty(memberDetails.PassportNo))
                responseMember.PassportNo = memberDetails.PassportNo;
            if (!string.IsNullOrEmpty(memberDetails.UidNo))
                responseMember.UidNo = memberDetails.UidNo;
            if (!string.IsNullOrEmpty(memberDetails.MobileNo))
                responseMember.MobileNo = memberDetails.MobileNo;
            if (!string.IsNullOrEmpty(memberDetails.EmailId))
                responseMember.EmailId = memberDetails.EmailId;
            if (!string.IsNullOrEmpty(memberDetails.ThiqaCardNo))
                responseMember.ThiqaCardNo = memberDetails.ThiqaCardNo;
            if (!string.IsNullOrEmpty(memberDetails.Position))
                responseMember.Position = memberDetails.Position;
            if (!string.IsNullOrEmpty(memberDetails.WorkLocation))
                responseMember.WorkLocation = memberDetails.WorkLocation;
            if (!string.IsNullOrEmpty(memberDetails.ResidenceLocation))
                responseMember.ResidenceLocation = memberDetails.ResidenceLocation;
            if (!string.IsNullOrEmpty(memberDetails.MemberCategory))
                responseMember.MemberCategory = memberDetails.MemberCategory;
            if (!string.IsNullOrEmpty(memberDetails.SalaryBand))
                responseMember.SalaryBand = memberDetails.SalaryBand;
            if (!string.IsNullOrEmpty(memberDetails.Commission))
                responseMember.Commission = memberDetails.Commission;
            if (!string.IsNullOrEmpty(memberDetails.BirthCertificateId))
                responseMember.BirthCertificateId = memberDetails.BirthCertificateId;
            if (!string.IsNullOrEmpty(memberDetails.SponsorType))
                responseMember.SponsorType = memberDetails.SponsorType;
            if (!string.IsNullOrEmpty(memberDetails.SponsorId))
                responseMember.SponsorId = memberDetails.SponsorId;
            if (!string.IsNullOrEmpty(memberDetails.Country))
                responseMember.Country = memberDetails.Country;
            if (!string.IsNullOrEmpty(memberDetails.Height))
                responseMember.Height = memberDetails.Height;
            if (!string.IsNullOrEmpty(memberDetails.Weight))
                responseMember.Weight = memberDetails.Weight;
            if (!string.IsNullOrEmpty(memberDetails.DocumentStatus))
                responseMember.DocumentStatus = memberDetails.DocumentStatus;
            if (!string.IsNullOrEmpty(memberDetails.EntrantType))
                responseMember.EntrantType = memberDetails.EntrantType;
            if (!string.IsNullOrEmpty(memberDetails.EntryDate))
                responseMember.EntryDate = memberDetails.EntryDate;
            if (!string.IsNullOrEmpty(memberDetails.RecordStatus))
                responseMember.RecordStatus = memberDetails.RecordStatus;
            if (memberDetails.ValidationErrors != null && memberDetails.ValidationErrors.Count > 0)
                responseMember.ValidationErrors = memberDetails.ValidationErrors;

            //tracingService.Trace($"ApplyMatch End");

        }
        private Entity MergeRecords(
            Entity target,
            Guid policyGuid,
            IOrganizationService service,
            ITracingService tracingService)
        {
            

            // Start with PreImage as base
            var merged = new Entity(target.LogicalName, target.Id);

            // Copy all PreImage attributes
            //foreach (var attr in preImage.Attributes)
            //    merged[attr.Key] = attr.Value;

            // Override with Target (updated values)
            foreach (var attr in target.Attributes)
            {
                if (attr.Key.StartsWith("adnic_"))
                {
                    tracingService.Trace("Updated field — {0}: {1}",
                        attr.Key, attr.Value?.ToString() ?? "null");
                    merged[attr.Key] = attr.Value;
                }
            }

            tracingService.Trace("target record attributes: {0}",
                merged.Attributes.Count);

            Member member = _census_Helper.GetUpdatedMember(service, tracingService, policyGuid.ToString(), target.Id.ToString());

            tracingService.Trace("MaptoMember started");
            //this.MapMemberToEntity(member, target, tracingService, service);
            this.MapMemberToEntity(member, merged, tracingService, service);
            tracingService.Trace("MaptoMember end");


            tracingService.Trace("Merged record attributes: {0}",
                merged.Attributes.Count);

            return merged;
        }

        private Entity MapMemberToEntity(
   Member member,
   Entity entity,
   ITracingService tracingService,
   IOrganizationService service
   )
        {

            if (member == null)
            {
                tracingService.Trace("MapMemberToEntity:: Member is null.");
                return entity;
            }

            tracingService.Trace($"MapMemberToEntity :: Printing values");
            foreach (var property in typeof(Member).GetProperties())
            {
                var value = property.GetValue(member);
                tracingService.Trace("{0}: {1}",
                    property.Name,
                    value?.ToString() ?? "null");
            }

            tracingService.Trace($"MapMemberToEntity :: Printing values END");

            var ref_collection = this._census_Helper.GetReferenceData(service, tracingService);

            

            //var entity = crm_record;

            //entity[$"{crm_record.LogicalName}id"] = crm_guid;

            // ── Basic Info ────────────────────────────────────────────────
            tracingService.Trace($"MapMemberToEntity::member name {member.MemberName}");

            if (!string.IsNullOrEmpty(member.MemberName) && !entity.Contains("adnic_pf_no"))
            {
                
                    entity["adnic_name"] = member.MemberName ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.DateOfBirth) && !entity.Contains("adnic_pf_no"))
            {
                entity["adnic_dob"] = _census_Helper.ConvertToCRMDateTime(member.DateOfBirth, tracingService);
            }

            if (!string.IsNullOrEmpty(member.Gender) && !entity.Contains("adnic_gender_id"))
            {
                string attribute_schema = "adnic_gender_id";
                string member_value = member.Gender;
                this._census_Helper.SetEntityField(member_value, attribute_schema,Constants.MasterData_Gender, tracingService, ref_collection, entity);

                //entity["adnic_gender"] = member.Gender.ToLower() == "male" ? new OptionSetValue(371320000) : new OptionSetValue(371320001);
                //var gender_ref = this._census_Helper.getReferenceRecord(Constants.MasterData_Gender, member.Gender, ref_collection, tracingService);
                //entity["adnic_gender_id"] = gender_ref;
                //this._census_Helper.SetFormattedValueForMasterData(member.Gender, "adnic_gender_id", tracingService, gender_ref, entity);
                //if (gender_ref != null)
                //{
                //    tracingService.Trace($"Setting formatted value {member.Gender}");
                //    entity.FormattedValues["adnic_gender_id"] = member.Gender;
                //}
            }
            //Madan
            if (!string.IsNullOrEmpty(member.MaritalStatus) && !entity.Contains("adnic_marital_id"))
            {
                string attribute_schema = "adnic_marital_id";
                string member_value = member.MaritalStatus;

                this._census_Helper.SetEntityField(member_value, attribute_schema,Constants.MasterData_MARITAL_STATUS, tracingService, ref_collection, entity);
                
            }

            if (!string.IsNullOrEmpty(member.Country) && !entity.Contains("adnic_country_id"))
            {
                string attribute_schema = "adnic_country_id";
                string member_value = member.Country;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Countries, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.Commission) && !entity.Contains("adnic_comission_id"))
            {
                string attribute_schema = "adnic_comission_id";
                string member_value = member.Commission;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_COMMISSION, tracingService, ref_collection, entity);

            }


            if (!string.IsNullOrEmpty(member.MemberCategory) && !entity.Contains("adnic_member_category_id"))
            {
                string attribute_schema = "adnic_member_category_id";
                string member_value = member.MemberCategory;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Member_Category, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.Nationality) && !entity.Contains("adnic_nationality_id"))
            {
                string attribute_schema = "adnic_nationality_id";
                string member_value = member.Nationality;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Countries, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.SponsorType) && !entity.Contains("adnic_sponsor_type"))
            {
                string attribute_schema = "adnic_sponsor_type";
                string member_value = member.SponsorType;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_SPONSER_TYPE, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.VisaEmirate) && !entity.Contains("adnic_visa_emirate_id"))
            {
                string attribute_schema = "adnic_visa_emirate_id";
                string member_value = member.VisaEmirate;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Visa_Emirate, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.VisaType) && !entity.Contains("adnic_visa_type_id"))
            {
                string attribute_schema = "adnic_visa_type_id";
                string member_value = member.VisaType;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Visa_Type, tracingService, ref_collection, entity);

            }

            if (!string.IsNullOrEmpty(member.WorkLocation) && !entity.Contains("adnic_work_location_id"))
            {
                string attribute_schema = "adnic_work_location_id";
                string member_value = member.WorkLocation;

                this._census_Helper.SetEntityField(member_value, attribute_schema, Constants.MasterData_Work_Location, tracingService, ref_collection, entity);

            }


            if (!string.IsNullOrEmpty(member.Relation) && !entity.Contains("adnic_relation"))
            {
                entity["adnic_relation"] = member.Relation ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.Dependency) && !entity.Contains("adnic_dependency"))
            {
                entity["adnic_dependency"] = member.Dependency ?? string.Empty;
            }

            if (member.SrNo != null   && !entity.Contains("adnic_sno"))
            {
                //entity["adnic_category"] = member.MemberCategory ?? string.Empty;
                entity["adnic_sno"] = member.SrNo;
            }

            if (!string.IsNullOrEmpty(member.PfNo))
            {
                if (!entity.Contains("adnic_pf_no"))
                {
                    entity["adnic_pf_no"] = member.PfNo;
                }
            }

            if (!string.IsNullOrEmpty(member.EmiratesId))
            {
                if (!entity.Contains("adnic_emirates_id"))
                {
                    entity["adnic_emirates_id"] = member.EmiratesId ?? string.Empty;
                }
            }

            if (!string.IsNullOrEmpty(member.PassportNo))
            {
                if (!entity.Contains("adnic_passport_no"))
                {
                    entity["adnic_passport_no"] = member.PassportNo ?? string.Empty;
                }
            }

            if (!string.IsNullOrEmpty(member.EidApplicationNo) && !entity.Contains("adnic_eid_visa_application_number"))
            {
                entity["adnic_eid_visa_application_number"] = member.EidApplicationNo ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.EntryPermitNo) && !entity.Contains("adnic_entry_permit_file_no"))
            {
                entity["adnic_entry_permit_file_no"] = member.EntryPermitNo ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.BirthCertificateId) && !entity.Contains("adnic_birth_certificate_id"))
            {
                entity["adnic_birth_certificate_id"] = member.BirthCertificateId ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.ThiqaCardNo) && !entity.Contains("adnic_thiga_card_no"))
            {
                entity["adnic_thiga_card_no"] = member.ThiqaCardNo ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.MobileNo) && !entity.Contains("adnic_mobile_no"))
            {

                // ── Contact ───────────────────────────────────────────────────
                entity["adnic_mobile_no"] = member.MobileNo ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.EmailId) && !entity.Contains("adnic_email_id"))
            {
                entity["adnic_email_id"] = member.EmailId ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.Position) && !entity.Contains("adnic_position"))
            {
                entity["adnic_position"] = member.Position ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.EffectiveDate) && !entity.Contains("adnic_effective_date"))
            {
                // ── Dates ─────────────────────────────────────────────────────
                entity["adnic_effective_date"] = _census_Helper.ConvertToCRMDateTime(member.EffectiveDate, tracingService);
            }

            if (!string.IsNullOrEmpty(member.PreviousCoverageDate) && !entity.Contains("adnic_previous_coverage_date"))
            {
                entity["adnic_previous_coverage_date"] = _census_Helper.ConvertToCRMDateTime(member.PreviousCoverageDate, tracingService);
            }

            if (!string.IsNullOrEmpty(member.ChangeOfStatusDate) && !entity.Contains("adnic_change_of_status_date"))
            {
                entity["adnic_change_of_status_date"] = _census_Helper.ConvertToCRMDateTime(member.ChangeOfStatusDate, tracingService);
            }

            if (!string.IsNullOrEmpty(member.ResidenceLocation) && !entity.Contains("adnic_residencelocation"))
            {
                // ── Location ──────────────────────────────────────────────────
                entity["adnic_residencelocation"] = member.ResidenceLocation ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.SalaryBand) && !entity.Contains("adnic_salary_band"))
            {
                entity["adnic_salary_band"] = member.SalaryBand ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.SponsorId) && !entity.Contains("adnic_sponsor_id"))
            {
                entity["adnic_sponsor_id"] = member.SponsorId ?? string.Empty;
            }

            if (!string.IsNullOrEmpty(member.ClassNo) && !entity.Contains("adnic_class_no"))
            {
                entity["adnic_class_no"] = member.ClassNo ?? string.Empty;
            }


            // ── Medical ───────────────────────────────────────────────────
           
            entity["adnic_medical_declaration"] = member.RequiresMedicalUnderwriting;//.ToLower() == "true";
            
            if (!string.IsNullOrEmpty(member.Height) && !entity.Contains("adnic_height"))
            {
                entity["adnic_height"] = _census_Helper.ConvertToDecimal(member.Height);
            }
            if (!string.IsNullOrEmpty(member.Weight) && !entity.Contains("adnic_weight"))
            {
                entity["adnic_weight"] = _census_Helper.ConvertToDecimal(member.Weight); // TODO: add Weight to Member class
            }

            if (!string.IsNullOrEmpty(member.RecordStatus) && !entity.Contains("adnic_validation_status"))
            {
                // ── Validation ────────────────────────────────────────────────
                entity["adnic_validation_status"] = member.RecordStatus ?? string.Empty;
            }

            if (member.ValidationErrors?.Count > 0)
            {
                entity["adnic_validation_remarks"] = member.ValidationErrors != null
                ? string.Join(", ", member.ValidationErrors)
                : string.Empty;
            }


            // ── Match Info ────────────────────────────────────────────────
          
            //entity["adnic_pp_check_status"] = string.Empty;
            //entity["adnic_pp_check_remarks"] = string.Empty;


            return entity;
        }
        private Dictionary<string, object> BuildMemberJson(
    Entity target,
    ITracingService tracingService,
    IOrganizationService service)
        {
            var json = new Dictionary<string, object>();

            if (target == null)
            {
                tracingService.Trace("Target is null.");
                return json;
            }

            tracingService.Trace("Building JSON from {0} updated fields.",
                target.Attributes.Count);

            // Only add fields that exist in Target
            if (target.Contains("adnic_name"))
            {
                json["memberName"] = GetString(target, "adnic_name");
                tracingService.Trace("Added memberName: {0}", json["memberName"]);
            }

            if (target.Contains("adnic_dob"))
            {
                json["dateOfBirth"] = GetDateString(target, "adnic_dob");
                tracingService.Trace("Added dateOfBirth: {0}", json["dateOfBirth"]);
            }

            //if (target.Contains("adnic_gender"))
            //{
            //    json["gender"] = GetString(target, "adnic_gender");
            //    tracingService.Trace("Added gender: {0}", json["gender"]);
            //}

            //Madan
            if (target.Contains("adnic_gender_id"))
            {
                this.SetFieldValueInJson("adnic_gender_id", "gender", target, tracingService, service, json);
            }

            if (target.Contains("adnic_marital_id"))
            {
                this.SetFieldValueInJson("adnic_marital_id", "maritalStatus", target, tracingService, service, json);
                //var enRef = target.GetAttributeValue<EntityReference>("adnic_marital_id");
                //var refText = this.GetRefData_Value(enRef, service, tracingService);
                //json["maritalStatus"] = refText;
                //tracingService.Trace("Added gender: {0}", json["maritalStatus"]);
            }

            if (target.Contains("adnic_relation"))
            {
                json["relation"] = GetString(target, "adnic_relation");
                tracingService.Trace("Added relation: {0}", json["relation"]);
            }

            if (target.Contains("adnic_dependency"))
            {
                json["dependency"] = GetString(target, "adnic_dependency");
                tracingService.Trace("Added dependency: {0}", json["dependency"]);
            }

            if (target.Contains("adnic_pf_no"))
            {
                json["pfNo"] = GetString(target, "adnic_pf_no");
                tracingService.Trace("Added pfNo: {0}", json["pfNo"]);
            }

            if (target.Contains("adnic_emirates_id"))
            {
                json["emiratesId"] = GetString(target, "adnic_emirates_id");
                tracingService.Trace("Added emiratesId: {0}", json["emiratesId"]);
            }

            if (target.Contains("adnic_passport_no"))
            {
                json["passportNo"] = GetString(target, "adnic_passport_no");
                tracingService.Trace("Added passportNo: {0}", json["passportNo"]);
            }

            if (target.Contains("adnic_eid_visa_application_number"))
            {
                json["eidApplicationNo"] = GetString(
                    target, "adnic_eid_visa_application_number");
                tracingService.Trace("Added eidApplicationNo: {0}",
                    json["eidApplicationNo"]);
            }

            if (target.Contains("adnic_entry_permit_file_no"))
            {
                json["entryPermitNo"] = GetString(
                    target, "adnic_entry_permit_file_no");
                tracingService.Trace("Added entryPermitNo: {0}",
                    json["entryPermitNo"]);
            }

            if (target.Contains("adnic_birth_certificate_id"))
            {
                json["birthCertificateId"] = GetString(
                    target, "adnic_birth_certificate_id");
                tracingService.Trace("Added birthCertificateId: {0}",
                    json["birthCertificateId"]);
            }

            if (target.Contains("adnic_thiga_card_no"))
            {
                json["thiqaCardNo"] = GetString(target, "adnic_thiga_card_no");
                tracingService.Trace("Added thiqaCardNo: {0}", json["thiqaCardNo"]);
            }

            if (target.Contains("adnic_mobile_no"))
            {
                json["mobileNo"] = GetString(target, "adnic_mobile_no");
                tracingService.Trace("Added mobileNo: {0}", json["mobileNo"]);
            }

            if (target.Contains("adnic_email_id"))
            {
                json["emailId"] = GetString(target, "adnic_email_id");
                tracingService.Trace("Added emailId: {0}", json["emailId"]);
            }

            if (target.Contains("adnic_position"))
            {
                json["position"] = GetString(target, "adnic_position");
                tracingService.Trace("Added position: {0}", json["position"]);
            }

            if (target.Contains("adnic_effective_date"))
            {
                json["effectiveDate"] = GetDateString(
                    target, "adnic_effective_date");
                tracingService.Trace("Added effectiveDate: {0}",
                    json["effectiveDate"]);
            }

            if (target.Contains("adnic_previous_coverage_date"))
            {
                json["previousCoverageDate"] = GetDateString(
                    target, "adnic_previous_coverage_date");
                tracingService.Trace("Added previousCoverageDate: {0}",
                    json["previousCoverageDate"]);
            }

            if (target.Contains("adnic_change_of_status_date"))
            {
                json["changeOfStatusDate"] = GetDateString(
                    target, "adnic_change_of_status_date");
                tracingService.Trace("Added changeOfStatusDate: {0}",
                    json["changeOfStatusDate"]);
            }

            if (target.Contains("adnic_residencelocation"))
            {
                json["residenceLocation"] = GetString(
                    target, "adnic_residencelocation");
                tracingService.Trace("Added residenceLocation: {0}",
                    json["residenceLocation"]);
            }

            if (target.Contains("adnic_salary_band"))
            {
                json["salaryBand"] = GetString(target, "adnic_salary_band");
                tracingService.Trace("Added salaryBand: {0}", json["salaryBand"]);
            }

            if (target.Contains("adnic_sponsor_id"))
            {
                json["sponsorId"] = GetString(target, "adnic_sponsor_id");
                tracingService.Trace("Added sponsorId: {0}", json["sponsorId"]);
            }

            if (target.Contains("adnic_class_no"))
            {
                json["classNo"] = GetString(target, "adnic_class_no");
                tracingService.Trace("Added classNo: {0}", json["classNo"]);
            }

            if (target.Contains("adnic_category"))
            {
                json["category"] = GetString(target, "adnic_category");
                tracingService.Trace("Added category: {0}", json["category"]);
            }

            if (target.Contains("adnic_med_dec_or_over_age"))
            {
                json["requiresMedicalUnderwriting"] = GetBool(
                    target, "adnic_med_dec_or_over_age");
                tracingService.Trace("Added requiresMedicalUnderwriting: {0}",
                    json["requiresMedicalUnderwriting"]);
            }

            if (target.Contains("adnic_height"))
            {
                json["height"] = GetString(target, "adnic_height");
                tracingService.Trace("Added height: {0}", json["height"]);
            }

            if (target.Contains("adnic_weight"))
            {
                json["weight"] = GetString(target, "adnic_weight");
                tracingService.Trace("Added weight: {0}", json["weight"]);
            }

            if (target.Contains("adnic_validation_status"))
            {
                json["recordStatus"] = GetString(target, "adnic_validation_status");
                tracingService.Trace("Added recordStatus: {0}", json["recordStatus"]);
            }

            if (target.Contains("adnic_validation_remarks"))
            {
                json["validationRemarks"] = GetString(
                    target, "adnic_validation_remarks");
                tracingService.Trace("Added validationRemarks: {0}",
                    json["validationRemarks"]);
            }

            if (target.Contains("adnic_is_matched"))
            {
                json["isMatched"] = GetBool(target, "adnic_is_matched");
                tracingService.Trace("Added isMatched: {0}", json["isMatched"]);
            }

            if (target.Contains("adnic_pp_check_status"))
            {
                json["ppCheckStatus"] = GetString(target, "adnic_pp_check_status");
                tracingService.Trace("Added ppCheckStatus: {0}",
                    json["ppCheckStatus"]);
            }

            if (target.Contains("adnic_pp_check_remarks"))
            {
                json["ppCheckRemarks"] = GetString(
                    target, "adnic_pp_check_remarks");
                tracingService.Trace("Added ppCheckRemarks: {0}",
                    json["ppCheckRemarks"]);
            }

            tracingService.Trace("JSON built with {0} fields.", json.Count);

            return json;
        }

        private void SetFieldValueInJson(string fieldSchema,string jsonFieldName,Entity target, ITracingService tracingService, IOrganizationService service, Dictionary<string, object> json)
        {
            var enRef = target.GetAttributeValue<EntityReference>(fieldSchema);
            var ref_record_Text = this.GetRefData_Value(enRef, service, tracingService);
            json[jsonFieldName] = ref_record_Text;
            tracingService.Trace($"Added {jsonFieldName}: {json[jsonFieldName]}");
        }

        private object BuildMemberJson1(
            Entity record,
            ITracingService tracingService)
        {
            return new
            {
                pfNo = GetString(record, "adnic_pf_no"),
                memberNo = string.Empty,
                memberName = GetString(record, "adnic_name"),
                dob = GetDateString(record, "adnic_dob"),
                gender = GetString(record, "adnic_gender"),
                dependency = GetString(record, "adnic_dependency"),
                relation = GetString(record, "adnic_relation"),
                effectiveDate = GetDateString(record, "adnic_effective_date"),
                previousCoverageDate = GetDateString(record, "adnic_previous_coverage_date"),
                changeOfStatusDate = GetDateString(record, "adnic_change_of_status_date"),
                emiratesId = GetString(record, "adnic_emirates_id"),
                passportNo = GetString(record, "adnic_passport_no"),
                eidApplicationNo = GetString(record, "adnic_eid_visa_application_number"),
                entryPermitNo = GetString(record, "adnic_entry_permit_file_no"),
                birthCertificateId = GetString(record, "adnic_birth_certificate_id"),
                thiqaCardNo = GetString(record, "adnic_thiga_card_no"),
                mobileNo = GetString(record, "adnic_mobile_no"),
                emailId = GetString(record, "adnic_email_id"),
                position = GetString(record, "adnic_position"),
                residenceLocation = GetString(record, "adnic_residencelocation"),
                salaryBand = GetString(record, "adnic_salary_band"),
                sponsorId = GetString(record, "adnic_sponsor_id"),
                classNo = GetString(record, "adnic_class_no"),
                category = GetString(record, "adnic_category"),
                height = GetString(record, "adnic_height"),
                weight = GetString(record, "adnic_weight"),
                requiresMedicalUnderwriting = !GetBool(record, "adnic_medical_declaration")?"":"yes",
                recordStatus = GetString(record, "adnic_validation_status"),
                validationRemarks = GetString(record, "adnic_validation_remarks"),
                isMatched = GetBool(record, "adnic_is_matched"),
                ppCheckStatus = GetString(record, "adnic_pp_check_status"),
                ppCheckRemarks = GetString(record, "adnic_pp_check_remarks"),
                updatedOn = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
            };
        }

        private void UpdateExternalTableWith_updatedJson(IOrganizationService service,ITracingService tracingService,Guid entityGuid, string updatedJson)
        {
            tracingService.Trace($"UpdateExternalTableWith_updatedJson Start.");
            tracingService.Trace($"UpdateExternalTableWith_updatedJson :: Guid {entityGuid}.");

            if (!string.IsNullOrEmpty(updatedJson))
            {
                var entity = new Entity("adnic_external_data");
                entity.Id = entityGuid;
                entity["adnic_json_updated_staring"] = updatedJson;
                service.Update(entity);
            }
            tracingService.Trace($"UpdateExternalTableWith_updatedJson End.");
        }

        private void SaveToExternalTable(
            Guid policyId,
            Guid censusRecordId,
            string json,
            IOrganizationService orgService,
            ITracingService tracingService)
        {
            tracingService.Trace("Saving JSON to adnic_external_data.");

            // Check if record already exists
            var existingId = GetExistingRecord(policyId, censusRecordId, orgService, tracingService);

            var entity = new Entity("adnic_external_data");

            tracingService.Trace($"Policy guid {policyId}");
            tracingService.Trace($"censusRecordId guid {censusRecordId}");
            // Link to Policy
            if (policyId != Guid.Empty)
            {
                entity["adnic_policy_guid"] = policyId.ToString();
            }

            // Store JSON
            entity["adnic_json_string"] = json;
           

            if (existingId == Guid.Empty)
            {
                tracingService.Trace("creating record for member in external data");
                entity["adnic_census_data_id"] = censusRecordId.ToString();
                entity["adnic_name"] = "CensusMemberUpdate";
                entity["adnic_source"] = "PolicyIssuance";

                var newId = orgService.Create(entity);
                tracingService.Trace("Created  record in adnic_external_data: {0}", newId);
            }
            else
            {
                entity.Id = existingId;
                orgService.Update(entity);
                tracingService.Trace("Updated adnic_external_data record: {0}", existingId);
            }
        }


        private Guid GetExistingRecord(
            Guid policyGuid,
            Guid currentRecordGuid,
            IOrganizationService service,
            ITracingService tracingService)
        {
            var fetchXml = $@"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
                                  <entity name='adnic_external_data'>
                                    <attribute name='adnic_policyid' />
                                    <attribute name='adnic_json_string' />
                                    <attribute name='adnic_external_dataid' />
                                    <filter>
                                      <condition attribute='adnic_name' operator='eq' value='CensusMemberUpdate' />
                                      <condition attribute='adnic_json_string' operator='not-null' />   
                                      <condition attribute='adnic_policy_guid' operator='eq' value='{policyGuid}' />                                       
                                    <condition attribute='adnic_census_data_id' operator='eq' value='{currentRecordGuid}' />  
 
                                    </filter>
                                    <order descending='true' attribute='createdon' />
                                  </entity>     
                                </fetch>";


            tracingService.Trace("adnic_external_data::Executing JSON query");

            var results = service.RetrieveMultiple(new FetchExpression(fetchXml));

            tracingService.Trace($"Count {results.Entities.Count}");

            if (results.Entities.Count > 0)
            {
                var id = results.Entities[0].GetAttributeValue<Guid>("adnic_external_dataid");
                tracingService.Trace("adnic_external_data::Existing member record found: {0}", id);
                return id;
            }

            tracingService.Trace("adnic_external_data::No existing member record.");
            return Guid.Empty;
        }

        private Guid GetPolicyId(
            Entity record,
            ITracingService tracingService)
        {
            if (record.Contains("adnic_policy_id") &&
                record["adnic_policy_id"] is EntityReference er)
            {
                tracingService.Trace("Policy ID: {0}", er.Id);
                return er.Id;
            }

            tracingService.Trace("Policy ID not found.");
            return Guid.Empty;
        }

        private string GetRefData_Value(EntityReference entityReference, IOrganizationService service, ITracingService tracingService)
        {
            var ref_record = service.Retrieve(entityReference.LogicalName, entityReference.Id, new ColumnSet(new string[] { "adnic_value" }));
            var ref_record_value = ref_record.GetAttributeValue<string>("adnic_value");
            return ref_record_value;
        }

        private string GetString(Entity record, string field)
        {
            if (!record.Contains(field) || record[field] == null)
                return string.Empty;

            var value = record[field];

            if (value is OptionSetValue osv)
                return osv.Value.ToString();

            if (value is EntityReference er)
                return er.Name ?? er.Id.ToString();

            if (value is Money m)
                return m.Value.ToString();

            if (value is bool b)
                return b.ToString().ToLower();

            if (value is DateTime dt)
                return dt.ToString("yyyy-MM-dd HH:mm:ss");

            if (value is decimal d)
                return d.ToString();

            if (value is int i)
                return i.ToString();

            return value.ToString();
        }

        private string GetDateString(Entity record, string field)
        {
            if (!record.Contains(field) || record[field] == null)
                return string.Empty;

            if (record[field] is DateTime dt)
                return dt.ToString("yyyy-MM-dd");

            return string.Empty;
        }

        private bool GetBool(Entity record, string field)
        {
            return record.Contains(field) &&
                   record[field] is bool b && b;
        }
    }
}

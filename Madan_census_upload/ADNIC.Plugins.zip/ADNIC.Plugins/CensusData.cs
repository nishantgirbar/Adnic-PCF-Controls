﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{

    public class CensusUpload : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            //var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            //try
            //{
            //    var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            //    IOrganizationServiceFactory orgServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            //    tracingService.Trace("Started");
            //    var service = orgServiceFactory.CreateOrganizationService(context.UserId);

            //    tracingService.Trace("VirtualEntityRetrieveMultiple: Starting execution");

            //    // Step 2: Extract QueryExpression from input parameters
            //    QueryExpression query = null;
            //    FetchExpression fetchquery = null;

            //    if (context.InputParameters.Contains("Query"))
            //    {
            //        query = context.InputParameters["Query"] as QueryExpression;
            //    }

            //    tracingService.Trace("after query");


            //    //tracingService.Trace($"query {query.ToString()}");
            //    if (context.InputParameters.Contains("Query"))
            //    {
            //        fetchquery = context.InputParameters["Query"] as FetchExpression;
            //    }

            //    tracingService.Trace($"fquery {fetchquery.Query}");

            //    query = this.getQuery(tracingService, context, service);

            //    tracingService.Trace($"input cnt {context.InputParameters.Count}");

            //    PrintInputs(tracingService, context);

            //    //var sort = this.BuildSortParameters(query, tracingService);

            //    //var fin = this.BuildQueryString(sort, null, null);

            //    //tracingService.Trace($"soritng {fin}");



            //    var fetchXml = @"<fetch version='1.0' mapping='logical' no-lock='false' distinct='true'>
            //                    <entity name='adnic_census_upload_virtual'>
            //                        <all-attributes />
            //                    </entity>
            //                </fetch>";

            //    tracingService.Trace("Executing query");
            //    var resultSet = service.RetrieveMultiple(new FetchExpression(fetchXml));
            //    IList<Entity> mis_matchedOnes = new List<Entity>();

            //    tracingService.Trace($"Count {resultSet.Entities.Count}");

            //    if (resultSet.Entities.Any())
            //    {
            //        foreach (var eachEntity in resultSet.Entities)
            //        {
            //            var eachOne = new Entity("adnic_census_data")
            //            {
            //                Attributes =
            //                {
            //                ["adnic_census_dataid"]=Guid.NewGuid(),
            //                ["adnic_sno"]=eachEntity["adnic_sno"].ToString(),
            //                ["adnic_pf_no"]=eachEntity["adnic_pf_no"].ToString(),
            //                //["adnic_member_name"]= eachEntity.Member.MemberName,
            //               // ["adnic_dob"]=eachEntity.Member.DateOfBirth,
            //                //["adnic_category"]=eachEntity.Member.MemberCategory,
            //                //["adnic_gender"]=eachEntity.Member.Gender,
            //                ["adnic_name"]=eachEntity["adnic_name"].ToString(),
            //                ["statecode"]=new OptionSetValue(0),
            //                ["adnic_is_matched"]="true",
            //                }
            //            };

            //            mis_matchedOnes.Add(eachOne);
            //        }
            //    }

            //    var entityCollection = new EntityCollection() { EntityName = "adnic_census_data", TotalRecordCount = mis_matchedOnes.Count };

            //    entityCollection.Entities.AddRange(mis_matchedOnes);

            //    tracingService.Trace($"entity collection 1 {entityCollection.Entities.Count}");


            //    tracingService.Trace("sort.SortField");
            //    //entityCollection = FilterEntityCollection(entityCollection, query, tracingService);
            //    entityCollection = SortEntityCollection(entityCollection, query, tracingService);

            //    context.OutputParameters["BusinessEntityCollection"] = entityCollection;
            //}
            //catch (Exception ex)
            //{
            //    tracingService.Trace(ex.Message);
            //}
        }


        private EntityCollection FilterEntityCollection(
    EntityCollection entityCollection,
    QueryExpression query,
    ITracingService tracingService)
        {
            if (query.Criteria == null || query.Criteria.Filters.Count == 0)
            {
                tracingService.Trace("No filters applied. Returning as-is.");
                return entityCollection;
            }

            var entities = entityCollection.Entities.ToList();

            foreach (FilterExpression fe in query.Criteria.Filters)
            {
                foreach (ConditionExpression condition in fe.Conditions)
                {
                    tracingService.Trace("Applying filter — Field: {0}, Operator: {1}, Value: {2}",
                        condition.AttributeName,
                        condition.Operator,
                        condition.Values.Count > 0 ? condition.Values[0] : "null");

                    entities = entities.Where(e =>
                        MatchesCondition(e, condition, tracingService)).ToList();
                }
            }

            entityCollection.Entities.Clear();
            foreach (var entity in entities)
                entityCollection.Entities.Add(entity);

            tracingService.Trace("Filter applied. Remaining records: {0}",
                entityCollection.Entities.Count);

            return entityCollection;
        }


        private bool MatchesCondition(
     Entity entity,
     ConditionExpression condition,
     ITracingService tracingService)
        {
            var fieldName = condition.AttributeName;
            var filterValue = condition.Values.Count > 0
                ? condition.Values[0]?.ToString()
                : null;

            // Field doesn't exist on entity
            if (!entity.Contains(fieldName) || entity[fieldName] == null)
            {
                tracingService.Trace("Field {0} is null on entity.", fieldName);
                return condition.Operator == ConditionOperator.Null;
            }

            var rawValue = entity[fieldName];

            tracingService.Trace("Comparing — Field: {0}, EntityValueType: {1}, EntityValue: {2}, FilterValue: {3}, Operator: {4}",
                fieldName,
                rawValue?.GetType()?.Name ?? "null",
                rawValue?.ToString() ?? "null",
                filterValue ?? "null",
                condition.Operator);

            switch (condition.Operator)
            {
                case ConditionOperator.Equal:
                    return AreEqual(rawValue, filterValue);

                case ConditionOperator.NotEqual:
                    return !AreEqual(rawValue, filterValue);

                case ConditionOperator.Like:
                case ConditionOperator.Contains:
                    return GetStringValue(rawValue)
                        .IndexOf(filterValue ?? "", StringComparison.OrdinalIgnoreCase) >= 0;

                case ConditionOperator.NotLike:
                    return GetStringValue(rawValue)
                        .IndexOf(filterValue ?? "", StringComparison.OrdinalIgnoreCase) < 0;

                case ConditionOperator.BeginsWith:
                    return GetStringValue(rawValue)
                        .StartsWith(filterValue ?? "", StringComparison.OrdinalIgnoreCase);

                case ConditionOperator.EndsWith:
                    return GetStringValue(rawValue)
                        .EndsWith(filterValue ?? "", StringComparison.OrdinalIgnoreCase);

                case ConditionOperator.Null:
                    return rawValue == null;

                case ConditionOperator.NotNull:
                    return rawValue != null;

                case ConditionOperator.GreaterThan:
                    return CompareValues(rawValue, filterValue) > 0;

                case ConditionOperator.GreaterEqual:
                    return CompareValues(rawValue, filterValue) >= 0;

                case ConditionOperator.LessThan:
                    return CompareValues(rawValue, filterValue) < 0;

                case ConditionOperator.LessEqual:
                    return CompareValues(rawValue, filterValue) <= 0;

                case ConditionOperator.In:
                    return condition.Values.Any(v =>
                        AreEqual(rawValue, v?.ToString()));

                case ConditionOperator.NotIn:
                    return !condition.Values.Any(v =>
                        AreEqual(rawValue, v?.ToString()));

                case ConditionOperator.Between:
                    if (condition.Values.Count == 2)
                        return CompareValues(rawValue, condition.Values[0].ToString()) >= 0 &&
                               CompareValues(rawValue, condition.Values[1].ToString()) <= 0;
                    return false;

                case ConditionOperator.Today:
                    return rawValue is DateTime dt && dt.Date == DateTime.Today;

                case ConditionOperator.ThisMonth:
                    return rawValue is DateTime dtm &&
                           dtm.Month == DateTime.Today.Month &&
                           dtm.Year == DateTime.Today.Year;

                case ConditionOperator.ThisYear:
                    return rawValue is DateTime dty &&
                           dty.Year == DateTime.Today.Year;

                default:
                    tracingService.Trace("Unhandled operator: {0}. Including record.", condition.Operator);
                    return true;
            }
        }
        private string GetStringValue(object rawValue)
        {
            if (rawValue == null) return string.Empty;

            switch (rawValue)
            {
                case string s: return s;
                case OptionSetValue osv: return osv.Value.ToString();
                case EntityReference er: return er.Name ?? er.Id.ToString();
                case Money m: return m.Value.ToString();
                case DateTime dt: return dt.ToString("yyyy-MM-dd");
                default: return rawValue.ToString();
            }
        }
        private bool AreEqual(object rawValue, string filterValue)
        {
            if (rawValue == null) return false;

            switch (rawValue)
            {
                // String
                case string s:
                    return string.Equals(s, filterValue, StringComparison.OrdinalIgnoreCase);

                // OptionSet — compare int value
                case OptionSetValue osv:
                    return int.TryParse(filterValue, out int osvInt) && osv.Value == osvInt;

                // Lookup — compare Guid
                case EntityReference er:
                    return Guid.TryParse(filterValue, out Guid erGuid) && er.Id == erGuid;

                // DateTime
                case DateTime dt:
                    return DateTime.TryParse(filterValue, out DateTime filterDt) &&
                           dt.Date == filterDt.Date;

                // Money
                case Money m:
                    return decimal.TryParse(filterValue, out decimal moneyDec) &&
                           m.Value == moneyDec;

                // Boolean
                case bool b:
                    return bool.TryParse(filterValue, out bool filterBool) && b == filterBool;

                // Integer
                case int i:
                    return int.TryParse(filterValue, out int filterInt) && i == filterInt;

                // Decimal
                case decimal d:
                    return decimal.TryParse(filterValue, out decimal filterDec) && d == filterDec;

                // Fallback
                default:
                    return string.Equals(
                        rawValue.ToString(), filterValue,
                        StringComparison.OrdinalIgnoreCase);
            }
        }
        private int CompareValues(object entityValue, string filterValue)
        {
            if (entityValue == null) return -1;

            // DateTime comparison
            if (entityValue is DateTime dt && DateTime.TryParse(filterValue, out var filterDt))
                return dt.CompareTo(filterDt);

            // Numeric comparison
            if (decimal.TryParse(entityValue.ToString(), out var entityDecimal) &&
                decimal.TryParse(filterValue, out var filterDecimal))
                return entityDecimal.CompareTo(filterDecimal);

            // Money comparison
            if (entityValue is Money money &&
                decimal.TryParse(filterValue, out var moneyFilter))
                return money.Value.CompareTo(moneyFilter);

            // String fallback
            return string.Compare(
                entityValue.ToString(),
                filterValue,
                StringComparison.OrdinalIgnoreCase);
        }
        private IComparable GetAttributeValue(Entity entity, string attributeName)
        {
            if (!entity.Contains(attributeName) || entity[attributeName] == null)
                return null;

            var value = entity[attributeName];

            // Handle all CRM field types
            switch (value)
            {
                case string s:
                    return s.ToLower(); // Text, Lookup name

                case DateTime dt:
                    return dt; // Date, DateTime

                case int i:
                    return i; // Integer, Picklist

                case decimal d:
                    return d; // Decimal

                case double db:
                    return db; // Float

                case bool b:
                    return b.ToString(); // Two Option

                case Money m:
                    return m.Value; // Currency

                case OptionSetValue osv:
                    return osv.Value; // Option Set

                case EntityReference er:
                    return er.Name?.ToLower(); // Lookup

                default:
                    return value.ToString();
            }
        }

        
        private EntityCollection SortEntityCollection(
                              EntityCollection entityCollection,
                              QueryExpression query,
                              ITracingService tracingService)
        {
            if (query.Orders == null || query.Orders.Count == 0)
            {
                tracingService.Trace("No sort orders. Returning as-is.");
                return entityCollection;
            }

            var entities = entityCollection.Entities.ToList();

            // Build ordered query dynamically from query.Orders
            IOrderedEnumerable<Entity> sortedEntities = null;

            for (int i = 0; i < query.Orders.Count; i++)
            {
                var order = query.Orders[i];
                bool isAscending = order.OrderType == OrderType.Ascending;
                string field = order.AttributeName;

                tracingService.Trace("Sorting by field: {0}, Direction: {1}",
                  field, isAscending ? "ASC" : "DESC");

                if (i == 0)
                {
                    // Primary sort
                    sortedEntities = isAscending
                ? entities.OrderByDescending(e => GetAttributeValue(e, field))
                : entities.OrderBy(e => GetAttributeValue(e, field));
                    
                }
                else
                {
                    // Secondary sort (Shift+Click)
                    sortedEntities = isAscending
                ? sortedEntities.ThenByDescending(e => GetAttributeValue(e, field))
                : sortedEntities.ThenBy(e => GetAttributeValue(e, field));
                    
                }
            }

            entityCollection.Entities.Clear();

            foreach (var entity in sortedEntities)
                entityCollection.Entities.Add(entity);

            return entityCollection;
        }

        
        private static void PrintInputs(ITracingService tracingService, IPluginExecutionContext context)
        {
            foreach (var parameter in context.InputParameters)
            {
                tracingService.Trace($"Param Key:{parameter.Key} | Type : {parameter.Value?.GetType()?.Name ?? "null"} | value : {parameter.Value?.ToString() ?? null}");
            }
            
        }

        private QueryExpression getQuery(ITracingService tracingService, IPluginExecutionContext context,IOrganizationService orgService)
        {

            QueryExpression query = null;

            // Method 1: Direct QueryExpression
            if (context.InputParameters.Contains("Query") &&
              context.InputParameters["Query"] is QueryExpression)
            {
                query = (QueryExpression)context.InputParameters["Query"];
                tracingService.Trace("Query found as QueryExpression.");
            }

            // Method 2: FetchXml — convert to QueryExpression
            else if (context.InputParameters.Contains("Query") &&
              context.InputParameters["Query"] is FetchExpression)
            {

                var fetchXml = ((FetchExpression)context.InputParameters["Query"]).Query;

                tracingService.Trace("Query found as FetchXml: {0}", fetchXml);

                //var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                //  .GetService(typeof(IOrganizationServiceFactory));
                //var orgService = orgServiceFactory.CreateOrganizationService(context.UserId);
                var cc = new FetchXmlToQueryExpressionRequest
                {
                    FetchXml= fetchXml,
                };
                var cRes = (FetchXmlToQueryExpressionResponse)orgService.Execute(cc);
                query = cRes.Query;
                //query = ((QueryExpressionResponse)orgService.Execute(
                //  new FetchXmlToQueryExpressionRequest { FetchXml = fetchXml }
                //)).Query;
            }

            // Method 3: Wrapped in RetrieveMultipleRequest
            else if (context.InputParameters.Contains("Request"))
            {
                var request = context.InputParameters["Request"] as RetrieveMultipleRequest;
                if (request?.Query is QueryExpression qe)
                {
                    query = qe;
                    tracingService.Trace("Query found inside RetrieveMultipleRequest.");
                }
            }

            if (query == null)
            {
                // Log all available parameters for debugging
                tracingService.Trace("Available InputParameters:");
                foreach (var key in context.InputParameters.Keys)
                {
                    tracingService.Trace(" - Key: {0}, Type: {1}",
                      key, context.InputParameters[key]?.GetType()?.Name ?? "null");
                }
                throw new InvalidPluginExecutionException("Could not resolve Query from input parameters.");
            }
            return query;
        }
        private string BuildQueryString(
            SortParameters sortParams,
            FilterParameters filterParams,
            PagingParameters pagingParams)
        {
            var sb = new StringBuilder();

            // ── Sort (OData style) ──────────────────────────────────────────
            if (!string.IsNullOrEmpty(sortParams.SortField))
            {
                sb.Append($"$orderby={sortParams.SortField} {(sortParams.IsAscending ? "asc" : "desc")}");

                if (sortParams.SecondarySorts != null && sortParams.SecondarySorts.Count > 0)
                {
                    foreach (var secondary in sortParams.SecondarySorts)
                    {
                        sb.Append($",{secondary.FieldName} {(secondary.IsAscending ? "asc" : "desc")}");
                    }
                }
                sb.Append("&");
            }

            // ── Filters ────────────────────────────────────────────────────
            //if (filterParams.Conditions.Count > 0)
            //{
            //    var filterParts = new List<string>();
            //    foreach (var condition in filterParams.Conditions)
            //    {
            //        filterParts.Add($"{condition.FieldName} eq '{condition.Value}'");
            //    }
            //    sb.Append($"$filter={string.Join(" and ", filterParts)}&");
            //}

            //// ── Paging ─────────────────────────────────────────────────────
            //sb.Append($"$top={pagingParams.PageSize}&");
            //sb.Append($"$skip={(pagingParams.PageNumber - 1) * pagingParams.PageSize}");

            return sb.ToString();
        }
        private SortParameters BuildSortParameters(QueryExpression query, ITracingService tracingService)
        {
            var sortParams = new SortParameters();

            if (query.Orders == null || query.Orders.Count == 0)
            {
                // Default sort if no column is clicked
                sortParams.SortField = "createdon";
                sortParams.IsAscending = false;
                tracingService.Trace("No sort orders found. Using default sort: createdon DESC");
                return sortParams;
            }

            // CRM sends the column the user clicked on
            var primaryOrder = query.Orders[0];
            sortParams.SortField = primaryOrder.AttributeName;
            sortParams.IsAscending = primaryOrder.OrderType == OrderType.Ascending;

            tracingService.Trace(
                "Sort applied — Field: {0}, Direction: {1}",
                sortParams.SortField,
                sortParams.IsAscending ? "ASC" : "DESC"
            );

            // Handle multi-column sort (Shift+Click in grid)
            if (query.Orders.Count > 1)
            {
                sortParams.SecondarySorts = new List<SortField>();
                for (int i = 1; i < query.Orders.Count; i++)
                {
                    sortParams.SecondarySorts.Add(new SortField
                    {
                        FieldName = query.Orders[i].AttributeName,
                        IsAscending = query.Orders[i].OrderType == OrderType.Ascending
                    });
                    tracingService.Trace(
                        "Secondary sort {0} — Field: {1}, Direction: {2}",
                        i,
                        query.Orders[i].AttributeName,
                        query.Orders[i].OrderType == OrderType.Ascending ? "ASC" : "DESC"
                    );
                }
            }

            return sortParams;
        }
    }

    public class SortParameters
    {
        public string SortField { get; set; }
        public bool IsAscending { get; set; }
        public List<SortField> SecondarySorts { get; set; } = new List<SortField>();
    }

    public class SortField
    {
        public string FieldName { get; set; }
        public bool IsAscending { get; set; }
    }

    public class FilterParameters
    {
        public List<FilterCondition> Conditions { get; set; } = new List<FilterCondition>();
    }

    public class FilterCondition
    {
        public string FieldName { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
    }

    public class PagingParameters
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string PagingCookie { get; set; }
    }

    

}

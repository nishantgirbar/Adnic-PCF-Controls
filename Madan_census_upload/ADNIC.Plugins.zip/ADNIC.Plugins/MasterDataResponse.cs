﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    using System.Text.Json.Serialization;
    using System.Collections.Generic;


    public class Country
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("isoAlpha2")]
        public string IsoAlpha2 { get; set; }

        [JsonPropertyName("isoAlpha3")]
        public string IsoAlpha3 { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class MasterDataResponse
    {
        [JsonPropertyName("lookupValues")]
        public LookupValues LookupValues { get; set; }

        [JsonPropertyName("medicalQuestions")]
        public List<MedicalQuestion> MedicalQuestions { get; set; }

        [JsonPropertyName("productDetails")]
        public List<object> ProductDetails { get; set; }

        [JsonPropertyName("products")]
        public List<Product> Products { get; set; }

        [JsonPropertyName("networkProviders")]
        public List<NetworkProvider> NetworkProviders { get; set; }

        [JsonPropertyName("networkTypes")]
        public List<NetworkType> NetworkTypes { get; set; }

        [JsonPropertyName("benefits")]
        public List<Benefit> Benefits { get; set; }

        [JsonPropertyName("networkBenefits")]
        public List<object> NetworkBenefits { get; set; }

        [JsonPropertyName("categories")]
        public List<Category> Categories { get; set; }
    }

    public class LookupValues
    {
        [JsonPropertyName("BUSINESS_NATURE")]
        public List<LookupValue> BusinessNature { get; set; }

        [JsonPropertyName("CATEGORY")]
        public List<LookupValue> Category { get; set; }

        [JsonPropertyName("CITY_EMIRATES")]
        public List<LookupValue> CityEmirates { get; set; }

        [JsonPropertyName("COMMISSION")]
        public List<LookupValue> Commission { get; set; }

        [JsonPropertyName("DOCUMENT_CATEGORY")]
        public List<LookupValue> DocumentCategory { get; set; }

        [JsonPropertyName("EBP_ANNUAL_LIMIT_MAP")]
        public List<LookupValue> EbpAnnualLimitMap { get; set; }

        [JsonPropertyName("EBP_ECARE_PLAN_TIER")]
        public List<LookupValue> EbpEcarePlanTier { get; set; }

        [JsonPropertyName("EBP_ECARE_THRESHOLD")]
        public List<LookupValue> EbpEcareThreshold { get; set; }

        [JsonPropertyName("EBP_FMC_PLAN_TIER")]
        public List<LookupValue> EbpFmcPlanTier { get; set; }

        [JsonPropertyName("EBP_FMC_THRESHOLD")]
        public List<LookupValue> EbpFmcThreshold { get; set; }

        [JsonPropertyName("EBP_NETWORK_TYPE_MAP")]
        public List<LookupValue> EbpNetworkTypeMap { get; set; }

        [JsonPropertyName("EBP_SALARY_TYPE")]
        public List<LookupValue> EbpSalaryType { get; set; }

        [JsonPropertyName("GENDER")]
        public List<LookupValue> Gender { get; set; }

        [JsonPropertyName("MARITAL_STATUS")]
        public List<LookupValue> MaritalStatus { get; set; }

        [JsonPropertyName("QUOTE_STATE")]
        public List<LookupValue> QuoteState { get; set; }

        [JsonPropertyName("RELATION")]
        public List<LookupValue> Relation { get; set; }

        [JsonPropertyName("SALARY_TYPE")]
        public List<LookupValue> SalaryType { get; set; }

        [JsonPropertyName("SOURCE_OF_BUSINESS")]
        public List<LookupValue> SourceOfBusiness { get; set; }

        [JsonPropertyName("VISA_LOCATION")]
        public List<LookupValue> VisaLocation { get; set; }
    }

    public class LookupValue
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("displayValue")]
        public string DisplayValue { get; set; }

        [JsonPropertyName("sortOrder")]
        public int SortOrder { get; set; }

        [JsonPropertyName("requiresUw")]
        public bool RequiresUw { get; set; }
    }

    public class MedicalQuestion
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("question")]
        public string Question { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("displayOrder")]
        public int DisplayOrder { get; set; }
    }

    public class Product
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("productName")]
        public string ProductName { get; set; }

        [JsonPropertyName("productCode")]
        public string ProductCode { get; set; }
    }

    public class NetworkProvider
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("productId")]
        public int ProductId { get; set; }
    }

    public class NetworkType
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("networkProviderId")]
        public int NetworkProviderId { get; set; }
    }

    public class Benefit
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("values")]
        public List<BenefitValue> Values { get; set; }
    }

    public class BenefitValue
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }

        [JsonPropertyName("benefitId")]
        public int BenefitId { get; set; }
    }

    public class Category
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}

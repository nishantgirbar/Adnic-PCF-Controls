﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{
    public class MasterData_Load : IPlugin
    {
        private Census_helper _census_Helper = null;

        public void Execute(IServiceProvider serviceProvider)
        {
            var tracingService = (ITracingService)serviceProvider
                  .GetService(typeof(ITracingService));
            try
            {
                var context = (IPluginExecutionContext)serviceProvider
                   .GetService(typeof(IPluginExecutionContext));



                var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                    .GetService(typeof(IOrganizationServiceFactory));

                var service = orgServiceFactory
                    .CreateOrganizationService(context.UserId);

                _census_Helper = new Census_helper();

                var ref_data_crm = _census_Helper.GetReferenceData(service, tracingService);

                var jsonString = this.CallServiceForMasterData(service, tracingService).GetAwaiter().GetResult();

                var ref_Data = System.Text.Json.JsonSerializer
                            .Deserialize<MasterDataResponse>(jsonString,
                                new System.Text.Json.JsonSerializerOptions
                                {
                                    PropertyNameCaseInsensitive = true
                                });

                tracingService.Trace($"Master data after Deserialize {ref_Data.LookupValues?.Gender?.Count}");

                this.DoActionOnReferenceData(tracingService, service, ref_Data, ref_data_crm);

                var jsonString_countries = this.CallServiceForCountries(service, tracingService).GetAwaiter().GetResult();

                tracingService.Trace($"countries json {jsonString_countries}");

                var country_Data = System.Text.Json.JsonSerializer
                           .Deserialize<List<Country>>(jsonString_countries,
                               new System.Text.Json.JsonSerializerOptions
                               {
                                   PropertyNameCaseInsensitive = true
                               });
                tracingService.Trace($"Total countries {country_Data.Count}");

                foreach (var eachCntry in country_Data)
                {
                    
                     var code = eachCntry.IsoAlpha2;

                    var ref_record = ref_data_crm.ToList().FirstOrDefault(e =>
                    {
                        var crm_code = e.GetAttributeValue<string>("adnic_key");
                        var category = e.GetAttributeValue<string>("adnic_type");

                        return crm_code == code && category.ToLower() == Constants.MasterData_Countries.ToLower();
                    });

                    var lpV = new LookupValue();
                    lpV.DisplayValue = eachCntry.Name;
                    lpV.Category = Constants.MasterData_Countries;
                    lpV.Code = eachCntry.IsoAlpha2;

                    UpsertRecordInRefMaster(tracingService, service, lpV, ref_record);
                }

            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }
        }

        private void DoActionOnReferenceData(ITracingService tracingService, IOrganizationService service, MasterDataResponse ref_Data,IList<Entity> ref_data_crm)
        {
            var gender_list = ref_Data.LookupValues.Gender;

            foreach (var genderValue in gender_list)
            {
                var code = genderValue.Code;

              var ref_record=  ref_data_crm.ToList().FirstOrDefault(e =>
                {
                    var crm_code = e.GetAttributeValue<string>("adnic_key");
                    var category = e.GetAttributeValue<string>("adnic_type");

                    return crm_code == code && category.ToLower() == Constants.MasterData_Gender.ToLower();
                });

                UpsertRecordInRefMaster(tracingService, service, genderValue,  ref_record);

            }

            foreach (var lValue in ref_Data.LookupValues.MaritalStatus)
            {
                var code = lValue.Code;

                var ref_record = ref_data_crm.ToList().FirstOrDefault(e =>
                {
                    var crm_code = e.GetAttributeValue<string>("adnic_key");
                    var category = e.GetAttributeValue<string>("adnic_type");

                    return crm_code == code && category.ToLower() == Constants.MasterData_MARITAL_STATUS.ToLower();
                });

                UpsertRecordInRefMaster(tracingService, service, lValue,  ref_record);
            }

            foreach (var lValue in ref_Data.LookupValues.Commission)
            {
                var code = lValue.Code;

                var ref_record = ref_data_crm.ToList().FirstOrDefault(e =>
                {
                    var crm_code = e.GetAttributeValue<string>("adnic_key");
                    var category = e.GetAttributeValue<string>("adnic_type");

                    return crm_code == code && category.ToLower() == Constants.MasterData_COMMISSION.ToLower();
                });

                UpsertRecordInRefMaster(tracingService, service, lValue,  ref_record);
            }

            foreach (var lValue in ref_Data.LookupValues.Category)
            {
                var code = lValue.Code;

                var ref_record = ref_data_crm.ToList().FirstOrDefault(e =>
                {
                    var crm_code = e.GetAttributeValue<string>("adnic_key");
                    var category = e.GetAttributeValue<string>("adnic_type");

                    return crm_code == code && category.ToLower() == Constants.MasterData_Category.ToLower();
                });

                UpsertRecordInRefMaster(tracingService, service, lValue, ref_record);
            }

            foreach (var lValue in ref_Data.LookupValues.CityEmirates)
            {
                var code = lValue.Code;

                var ref_record = ref_data_crm.ToList().FirstOrDefault(e =>
                {
                    var crm_code = e.GetAttributeValue<string>("adnic_key");
                    var category = e.GetAttributeValue<string>("adnic_type");

                    return crm_code == code && category.ToLower() == Constants.MasterData_CITY_EMIRATES.ToLower();
                });

                UpsertRecordInRefMaster(tracingService, service, lValue, ref_record);
            }
        }

        private static void UpsertRecordInRefMaster(ITracingService tracingService, IOrganizationService service, LookupValue lookupValue, Entity ref_record)
        {
            var ref_entity = new Entity("adnic_refernce_data");

            if (ref_record != null)
            {
                var recordGuid = ref_record.Id;

                //tracingService.Trace($"existing Ref record found . ID {recordGuid}");

                ref_entity["adnic_value"] = lookupValue.DisplayValue;
                tracingService.Trace($"Foudn record in ref data :: {recordGuid}");
                ref_entity["adnic_refernce_dataid"] = recordGuid;
            }
            else
            {
                ref_entity["adnic_key"] = lookupValue.Code;
                ref_entity["adnic_value"] = lookupValue.DisplayValue;
                ref_entity["adnic_name"] = lookupValue.DisplayValue;
                ref_entity["adnic_type"] = lookupValue.Category;

                service.Create(ref_entity);
            }
        }

       

        private async Task<string> CallServiceForMasterData(IOrganizationService service, ITracingService tracingService)
        {
            string responseContent = string.Empty;

            try
            {
                var validtion_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_MasterDataReferenceURL");

                tracingService.Trace($"Master Data service url {validtion_url}");

                using (var client = new HttpClient())
                {

                    //client.DefaultRequestHeaders.Add("Authorization", "Bearer YOUR_TOKEN"); // if required

                    //var content = new StringContent(
                    //    jsonString,
                    //    Encoding.UTF8,
                    //    "application/json");

                    HttpResponseMessage response = await client.GetAsync(validtion_url);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    //tracingService.Trace(responseContent);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            return responseContent;
        }

        private async Task<string> CallServiceForCountries(IOrganizationService service, ITracingService tracingService)
        {
            string responseContent = string.Empty;

            try
            {
                var service_url = _census_Helper.GetEnvironmentVariableValue(service, "adnic_MasterDataNationalities");

                tracingService.Trace($"Master Data service url {service_url}");

                using (var client = new HttpClient())
                {

                    //client.DefaultRequestHeaders.Add("Authorization", "Bearer YOUR_TOKEN"); // if required

                    //var content = new StringContent(
                    //    jsonString,
                    //    Encoding.UTF8,
                    //    "application/json");

                    HttpResponseMessage response = await client.GetAsync(service_url);

                    responseContent = await response.Content.ReadAsStringAsync();

                    tracingService.Trace($"Status: {response.StatusCode}");
                    //tracingService.Trace(responseContent);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }

            return responseContent;
        }
    }
}

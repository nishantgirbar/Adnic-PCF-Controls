﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using System.Threading.Tasks;

namespace ADNIC.Plugins
{

    public class CensusData_RetrieveMulitple : IPlugin
    {
        private Census_helper census_Helper = null;
        private Guid _policy_guid;
        

        public void Execute(IServiceProvider serviceProvider)
        {
            string entityName = "adnic_census_data";
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                
                census_Helper = new Census_helper();
               
                var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                if (context.Depth > 1)
                {
                    tracingService.Trace("Depth {0} — exiting to prevent loop.", context.Depth);
                    return;
                }

                IOrganizationServiceFactory orgServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

                tracingService.Trace("Started");
                var service = orgServiceFactory.CreateOrganizationService(context.UserId);

                census_Helper.SetReferenceData(service, tracingService);

                var query = this.getQuery(tracingService, context, service);

                var retrieveAll = this.IsConditionExist("adnic_retrieve_all", query, tracingService);
                var retrievefromService = this.IsConditionExist("adnic_retrieve_from_service", query, tracingService);

                tracingService.Trace($"Retrieve all {retrieveAll}");
                tracingService.Trace($"retrievefromService {retrievefromService}");

                if (retrievefromService)
                {
                    RemoveCondition("adnic_retrieve_from_service", query, tracingService);

                    tracingService.Trace($"adnic_retrieve_from_service removed if exists.");

                    var policyGuid = GetPolicyIdFromQueryExpression(query, tracingService);
                    this._policy_guid = policyGuid;

                    tracingService.Trace($"Policy Guid {policyGuid}");

                    IList<Entity> total = new List<Entity>();
                    
                    UploadValidationResponse jsonObject = census_Helper.GetDataFromResponseJson(tracingService, service, policyGuid);

                    var ff = $@"<fetch version='1.0' mapping='logical' distinct='true'  no-lock='false'>
    <entity name='adnic_census_data'>
        <attribute name='adnic_birth_certificate_id' />
    <attribute name='adnic_category' />
    <attribute name='adnic_census_dataid' />
    <attribute name='adnic_change_of_status_date' />
    <attribute name='adnic_class_no' />
    <attribute name='adnic_coc_fine' />
    <attribute name='adnic_coc_payment_ref_no' />
    <attribute name='adnic_coc_status' />
    <attribute name='adnic_comission_id' />
    <attribute name='adnic_country_id' />
    <attribute name='adnic_dependency' />
    <attribute name='adnic_dob' />
    <attribute name='adnic_effective_date' />
    <attribute name='adnic_eid_visa_application_number' />
    <attribute name='adnic_email_id' />
    <attribute name='adnic_emirates_id' />
    <attribute name='adnic_entry_permit_file_no' />
    <attribute name='adnic_gender_id' />
    <attribute name='adnic_height' />
    <attribute name='adnic_is_matched' />
    <attribute name='adnic_marital_id' />
    <attribute name='adnic_med_dec_or_over_age' />
    <attribute name='adnic_medical_declaration' />
    <attribute name='adnic_member_category_id' />
    <attribute name='adnic_mobile_no' />
    <attribute name='adnic_name' />
    <attribute name='adnic_nationality_id' />
    <attribute name='adnic_passport_no' />
    <attribute name='adnic_pf_no' />
    <attribute name='adnic_policy_guid' />
    <attribute name='adnic_policy_id' />
    <attribute name='adnic_position' />
    <attribute name='adnic_pp_check_remarks' />
    <attribute name='adnic_pp_check_status' />
    <attribute name='adnic_previous_coverage_date' />
    <attribute name='adnic_relation' />
    <attribute name='adnic_residencelocation' />
    <attribute name='adnic_retrieve_all' />
    <attribute name='adnic_retrieve_from_service' />
    <attribute name='adnic_salary_band' />
    <attribute name='adnic_sno' />
    <attribute name='adnic_sponsor_id' />
    <attribute name='adnic_sponsor_type' />
    <attribute name='adnic_thiga_card_no' />
    <attribute name='adnic_validation_remarks' />
    <attribute name='adnic_validation_status' />
    <attribute name='adnic_visa_emirate_id' />
    <attribute name='adnic_visa_type_id' />
    <attribute name='adnic_weight' />
    <attribute name='adnic_work_location_id' />
    <attribute name='adnic_work_type_id' />
     <attribute name='ownerid' />
    <attribute name='owningbusinessunit' />
    <attribute name='statecode' />
    <attribute name='statuscode' />
        <filter type='and'>
            <condition attribute='statecode' operator='eq' value='0'/>
                    </filter>
        <link-entity name='adnic_policy' from='adnic_policyid' to='adnic_policy_id' alias='bb'>
            <filter type='and'>
                <condition attribute='adnic_policyid' operator='eq' value='{policyGuid}'/>
            </filter>
        </link-entity>
    </entity>
</fetch>";

                    var basic_data_resultset = service.RetrieveMultiple(new FetchExpression(ff));

                    var matched_members =this.census_Helper.GetMatchedMembers(entityName,service, tracingService, jsonObject, basic_data_resultset,_policy_guid);

                    tracingService.Trace($"Matched count {matched_members.Count}");

                    var mis_matched_members =this.census_Helper.GetMismatchedMembers(entityName,service, tracingService, jsonObject, basic_data_resultset,_policy_guid);

                    tracingService.Trace($"MisMatched count {mis_matched_members.Count}");

                    total = matched_members.Concat(mis_matched_members).ToList();

                    tracingService.Trace($"total {total.Count}");

                    var entityCollection = new EntityCollection() { EntityName = entityName, TotalRecordCount = total.Count };

                    entityCollection.Entities.AddRange(total);

                    tracingService.Trace($"entity collection  {entityCollection.Entities.Count}");

                    this.FilterEntityCollection(entityCollection, query, tracingService);
                    this.SortEntityCollection(entityCollection, query, tracingService);

                    entityCollection.TotalRecordCount = entityCollection.Entities.Count;

                    tracingService.Trace($"entity collection after filtering and sorting .. {entityCollection.Entities.Count}");

                    context.OutputParameters["BusinessEntityCollection"] = entityCollection;
                }
                else
                {
                    var generalQuery = getQuery(tracingService, context, service);
                    var resultsSet = service.RetrieveMultiple(generalQuery);

                    tracingService.Trace($"Results for general query {resultsSet.Entities.Count}");

                    context.OutputParameters["BusinessEntityCollection"] = resultsSet;
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(ex.Message);
            }
        }

        
        private Guid GetPolicyIdFromQueryExpression(
    QueryExpression query,
    ITracingService tracingService)
        {
            if (query.LinkEntities == null || query.LinkEntities.Count == 0)
            {
                tracingService.Trace("No link entities found.");
                return Guid.Empty;
            }

            foreach (LinkEntity linkEntity in query.LinkEntities)
            {
                tracingService.Trace("LinkEntity — Name: {0}, From: {1}, To: {2}",
                    linkEntity.LinkToEntityName,
                    linkEntity.LinkFromAttributeName,
                    linkEntity.LinkToAttributeName);

                if (linkEntity.LinkToEntityName != "adnic_policy") continue;

                // Check conditions inside link entity
                if (linkEntity.LinkCriteria?.Conditions == null) continue;

                foreach (ConditionExpression condition in
                    linkEntity.LinkCriteria.Conditions)
                {
                    tracingService.Trace("LinkEntity Condition — Field: {0}, Value: {1}",
                        condition.AttributeName,
                        condition.Values.Count > 0 ? condition.Values[0] : "null");

                    if (condition.AttributeName == "adnic_policyid" &&
                        condition.Values.Count > 0)
                    {
                        if (Guid.TryParse(
                            condition.Values[0].ToString(), out Guid policyId))
                        {
                            tracingService.Trace("Policy ID from LinkEntity: {0}",
                                policyId);
                            return policyId;
                        }
                    }
                }
            }

            tracingService.Trace("Policy ID not found in LinkEntities.");
            return Guid.Empty;
        }


       

        #region Filtering

        private EntityCollection FilterEntityCollection(
   EntityCollection entityCollection,
   QueryExpression query,
   ITracingService tracingService)
        {
            ApplyFilters(entityCollection, query, tracingService);
            ApplyConditions(entityCollection, query, tracingService);

            return entityCollection;
        }

        private EntityCollection ApplyFilters(EntityCollection entityCollection, QueryExpression query, ITracingService tracingService)
        {
            if (query.Criteria == null || query.Criteria.Filters.Count == 0)
            {
                tracingService.Trace("No filters applied. Returning as-is.");
                return entityCollection;
            }

            var entities = entityCollection.Entities.ToList();

            foreach (FilterExpression fe in query.Criteria.Filters)
            {
                foreach (ConditionExpression condition in fe.Conditions)
                {
                    tracingService.Trace("Applying filter — Field: {0}, Operator: {1}, Value: {2}",
                        condition.AttributeName,
                        condition.Operator,
                        condition.Values.Count > 0 ? condition.Values[0] : "null");

                    entities = entities.Where(e =>
                        MatchesCondition(e, condition, tracingService)).ToList();
                }

                tracingService.Trace("Filter applied. Remaining records: {0}",
               entities.Count);
            }

            entityCollection.Entities.Clear();
            foreach (var entity in entities)
                entityCollection.Entities.Add(entity);

            tracingService.Trace("Filter applied. Remaining records: {0}",
                entityCollection.Entities.Count);

            return entityCollection;
        }

        private EntityCollection ApplyConditions(EntityCollection entityCollection, QueryExpression query, ITracingService tracingService)
        {
            if (query.Criteria == null || query.Criteria.Conditions.Count == 0)
            {
                tracingService.Trace("No filters applied. Returning as-is.");
                return entityCollection;
            }

            var entities = entityCollection.Entities.ToList();

            foreach (ConditionExpression condition in query.Criteria.Conditions)
            {

                tracingService.Trace("Applying conditions — Field: {0}, Operator: {1}, Value: {2}",
                    condition.AttributeName,
                    condition.Operator,
                    condition.Values.Count > 0 ? condition.Values[0] : "null");

                entities = entities.Where(e =>
                    MatchesCondition(e, condition, tracingService)).ToList();

                tracingService.Trace("Filter applied. Remaining records: {0}",
               entities.Count);
            }

            entityCollection.Entities.Clear();
            foreach (var entity in entities)
                entityCollection.Entities.Add(entity);

            tracingService.Trace("Conditions applied. Remaining records: {0}",
                entityCollection.Entities.Count);

            return entityCollection;
        }
        #region Retrieve ALL exists
        private void RemoveCondition(string attributeName,
    QueryExpression query,
    ITracingService tracingService)
        {
            if (query?.Criteria == null) return;

            // Remove from top-level conditions
            var toRemove = query.Criteria.Conditions
                .Cast<ConditionExpression>()
                .Where(c => c.AttributeName == attributeName ||
                            string.IsNullOrEmpty(c.AttributeName))
                .ToList();

            foreach (var condition in toRemove)
            {
                query.Criteria.Conditions.Remove(condition);
                tracingService.Trace("Removed condition: {0}",
                    condition.AttributeName ?? "empty");
            }

            // Remove from nested filters
            if (query.Criteria.Filters != null)
            {
                foreach (FilterExpression filter in query.Criteria.Filters)
                {
                    RemoveConditionFromFilter(attributeName, filter, tracingService);
                }
            }
        }

        private void RemoveConditionFromFilter(string attributeName,
            FilterExpression filter,
            ITracingService tracingService)
        {
            if (filter?.Conditions == null) return;

            // Remove adnic_retrieve_all and empty conditions
            var toRemove = filter.Conditions
                .Cast<ConditionExpression>()
                .Where(c => c.AttributeName == attributeName ||
                            string.IsNullOrEmpty(c.AttributeName))
                .ToList();

            foreach (var condition in toRemove)
            {
                filter.Conditions.Remove(condition);
                tracingService.Trace("Removed from filter: {0}",
                    condition.AttributeName ?? "empty");
            }

            // Recursively clean child filters
            if (filter.Filters != null)
            {
                foreach (FilterExpression child in filter.Filters)
                {
                    RemoveConditionFromFilter(attributeName, child, tracingService);
                }
            }
        }
        private bool IsConditionExist(string attributeName,
    QueryExpression query,
    ITracingService tracingService)
        {

            if (query?.Criteria == null)
            {
                tracingService.Trace("Criteria is null.");
                return false;
            }

            try
            {
                // Check top-level conditions
                if (query.Criteria.Conditions != null &&
                    query.Criteria.Conditions.Count > 0)
                {
                    foreach (ConditionExpression condition in query.Criteria.Conditions)
                    {
                        if (condition.AttributeName == attributeName)
                        {
                            var value = condition.Values.Count > 0
                                ? condition.Values[0]?.ToString()
                                : null;

                            tracingService.Trace(
                                "{1} found in Conditions. Value: {0}",
                                value ?? "null", attributeName);

                            return value == "1" ||
                                   value?.ToLower() == "true" ||
                                   value?.ToLower() == "yes";
                        }
                    }
                }

                // Check nested filters
                if (query.Criteria.Filters != null &&
                    query.Criteria.Filters.Count > 0)
                {
                    foreach (FilterExpression filter in query.Criteria.Filters)
                    {
                        if (HasRetrieveAllCondition(attributeName, filter, tracingService))
                            return true;
                    }
                }

                tracingService.Trace("adnic_retrieve_all not found.");
                return false;
            }
            catch (Exception ex)
            {
                tracingService.Trace($"exception {ex.Message}");
            }

            return false;
        }

        private bool HasRetrieveAllCondition(string attributeName,
            FilterExpression filter,
            ITracingService tracingService)
        {
            if (filter?.Conditions == null) return false;

            foreach (ConditionExpression condition in filter.Conditions)
            {
                if (condition.AttributeName == attributeName)
                {
                    var value = condition.Values.Count > 0
                        ? condition.Values[0]?.ToString()
                        : null;

                    tracingService.Trace(
                        "{1} found in Filter. Value: {0}",
                        value ?? "null", attributeName);

                    return value == "1" ||
                           value?.ToLower() == "true" ||
                           value?.ToLower() == "yes";
                }
            }

            // Check child filters recursively
            if (filter.Filters != null)
            {
                foreach (FilterExpression child in filter.Filters)
                {
                    if (HasRetrieveAllCondition(attributeName, child, tracingService))
                        return true;
                }
            }

            return false;
        }

        #endregion
        private bool MatchesCondition(
     Entity entity,
     ConditionExpression condition,
     ITracingService tracingService)
        {
            var fieldName = condition.AttributeName;
            var filterValue = condition.Values.Count > 0
                ? condition.Values[0]?.ToString()
                : null;

            if (!entity.Contains(fieldName) || entity[fieldName] == null)
            {
                tracingService.Trace("Field {0} is null on entity.", fieldName);
                return condition.Operator == ConditionOperator.Null;
            }

            var rawValue = entity[fieldName];

            tracingService.Trace(
                "Matching — Field: {0}, Type: {1}, EntityValue: {2}, FilterValue: {3}, Op: {4}",
                fieldName,
                rawValue?.GetType()?.Name ?? "null",
                rawValue?.ToString() ?? "null",
                filterValue ?? "null",
                condition.Operator);

            switch (condition.Operator)
            {
                case ConditionOperator.Equal:
                    return AreEqual(rawValue, filterValue);

                case ConditionOperator.NotEqual:
                    return !AreEqual(rawValue, filterValue);

                case ConditionOperator.Like:
                case ConditionOperator.Contains:
                    {
                        var searchValue = StripWildcards(filterValue);
                        var entityString = GetStringValue(rawValue);
                        tracingService.Trace("Like — Searching '{0}' in '{1}'",
                            searchValue, entityString);
                        return entityString.IndexOf(searchValue,
                            StringComparison.OrdinalIgnoreCase) >= 0;
                    }

                case ConditionOperator.NotLike:
                    {
                        var searchValue = StripWildcards(filterValue);
                        return GetStringValue(rawValue)
                            .IndexOf(searchValue, StringComparison.OrdinalIgnoreCase) < 0;
                    }

                case ConditionOperator.BeginsWith:
                    {
                        var searchValue = filterValue?.TrimEnd('%');
                        return GetStringValue(rawValue)
                            .StartsWith(searchValue ?? "",
                                StringComparison.OrdinalIgnoreCase);
                    }

                case ConditionOperator.EndsWith:
                    {
                        var searchValue = filterValue?.TrimStart('%');
                        return GetStringValue(rawValue)
                            .EndsWith(searchValue ?? "",
                                StringComparison.OrdinalIgnoreCase);
                    }

                case ConditionOperator.Null:
                    return rawValue == null;

                case ConditionOperator.NotNull:
                    return rawValue != null;

                case ConditionOperator.GreaterThan:
                    return CompareValues(rawValue, filterValue) > 0;

                case ConditionOperator.GreaterEqual:
                    return CompareValues(rawValue, filterValue) >= 0;

                case ConditionOperator.LessThan:
                    return CompareValues(rawValue, filterValue) < 0;

                case ConditionOperator.LessEqual:
                    return CompareValues(rawValue, filterValue) <= 0;

                case ConditionOperator.In:
                    return condition.Values.Any(v => AreEqual(rawValue, v?.ToString()));

                case ConditionOperator.NotIn:
                    return !condition.Values.Any(v => AreEqual(rawValue, v?.ToString()));

                case ConditionOperator.Between:
                    if (condition.Values.Count == 2)
                        return CompareValues(rawValue, condition.Values[0].ToString()) >= 0 &&
                               CompareValues(rawValue, condition.Values[1].ToString()) <= 0;
                    return false;

                case ConditionOperator.Today:
                    return rawValue is DateTime dt && dt.Date == DateTime.Today;

                case ConditionOperator.ThisMonth:
                    return rawValue is DateTime dtm &&
                           dtm.Month == DateTime.Today.Month &&
                           dtm.Year == DateTime.Today.Year;

                case ConditionOperator.ThisYear:
                    return rawValue is DateTime dty &&
                           dty.Year == DateTime.Today.Year;

                default:
                    tracingService.Trace("Unhandled operator: {0}. Including record.",
                        condition.Operator);
                    return true;
            }
        }
        private string StripWildcards(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;

            // Remove leading and trailing % wildcards
            // %THREE%  → THREE
            // THREE%   → THREE
            // %THREE   → THREE
            return value.Trim('%').Replace("_", " ").Trim();
        }
        private string GetStringValue(object rawValue)
        {
            if (rawValue == null) return string.Empty;

            switch (rawValue)
            {
                case string s: return s;
                case OptionSetValue osv: return osv.Value.ToString();
                case EntityReference er: return er.Name ?? er.Id.ToString();
                case Money m: return m.Value.ToString();
                case DateTime dt: return dt.ToString("yyyy-MM-dd");
                default: return rawValue.ToString();
            }
        }
        private bool AreEqual(object rawValue, string filterValue)
        {
            if (rawValue == null) return false;

            switch (rawValue)
            {
                // String
                case string s:
                    return string.Equals(s, filterValue, StringComparison.OrdinalIgnoreCase);

                // OptionSet — compare int value
                case OptionSetValue osv:
                    return int.TryParse(filterValue, out int osvInt) && osv.Value == osvInt;

                // Lookup — compare Guid
                case EntityReference er:
                    return Guid.TryParse(filterValue, out Guid erGuid) && er.Id == erGuid;

                // DateTime
                case DateTime dt:
                    return DateTime.TryParse(filterValue, out DateTime filterDt) &&
                           dt.Date == filterDt.Date;

                // Money
                case Money m:
                    return decimal.TryParse(filterValue, out decimal moneyDec) &&
                           m.Value == moneyDec;

                // Boolean
                case bool b:
                    return bool.TryParse(filterValue, out bool filterBool) && b == filterBool;

                // Integer
                case int i:
                    return int.TryParse(filterValue, out int filterInt) && i == filterInt;

                // Decimal
                case decimal d:
                    return decimal.TryParse(filterValue, out decimal filterDec) && d == filterDec;

                // Fallback
                default:
                    return string.Equals(
                        rawValue.ToString(), filterValue,
                        StringComparison.OrdinalIgnoreCase);
            }
        }
        private int CompareValues(object entityValue, string filterValue)
        {
            if (entityValue == null) return -1;

            // DateTime comparison
            if (entityValue is DateTime dt && DateTime.TryParse(filterValue, out var filterDt))
                return dt.CompareTo(filterDt);

            // Numeric comparison
            if (decimal.TryParse(entityValue.ToString(), out var entityDecimal) &&
                decimal.TryParse(filterValue, out var filterDecimal))
                return entityDecimal.CompareTo(filterDecimal);

            // Money comparison
            if (entityValue is Money money &&
                decimal.TryParse(filterValue, out var moneyFilter))
                return money.Value.CompareTo(moneyFilter);

            // String fallback
            return string.Compare(
                entityValue.ToString(),
                filterValue,
                StringComparison.OrdinalIgnoreCase);
        }
        #endregion


        private EntityCollection SortEntityCollection(
                             EntityCollection entityCollection,
                             QueryExpression query,
                             ITracingService tracingService)
        {
            if (query.Orders == null || query.Orders.Count == 0)
            {
                tracingService.Trace("No sort orders. Returning as-is.");
                return entityCollection;
            }

            var entities = entityCollection.Entities.ToList();

            // Build ordered query dynamically from query.Orders
            IOrderedEnumerable<Entity> sortedEntities = null;

            for (int i = 0; i < query.Orders.Count; i++)
            {
                var order = query.Orders[i];
                bool isAscending = order.OrderType == OrderType.Ascending;
                string field = order.AttributeName;

                tracingService.Trace("Sorting by field: {0}, Direction: {1}",
                  field, isAscending ? "ASC" : "DESC");

                if (i == 0)
                {
                    // Primary sort
                    sortedEntities = isAscending
                ? entities.OrderBy(e => GetAttributeValue(e, field))
                : entities.OrderByDescending(e => GetAttributeValue(e, field));



                }
                else
                {
                    // Secondary sort (Shift+Click)
                    sortedEntities = isAscending
                ? sortedEntities.ThenBy(e => GetAttributeValue(e, field))
                : sortedEntities.ThenByDescending(e => GetAttributeValue(e, field));




                }
            }

            entityCollection.Entities.Clear();

            foreach (var entity in sortedEntities)
                entityCollection.Entities.Add(entity);

            return entityCollection;
        }

        private IComparable GetAttributeValue(Entity entity, string attributeName)
        {
            if (!entity.Contains(attributeName) || entity[attributeName] == null)
                return null;

            var value = entity[attributeName];

            // Handle all CRM field types
            switch (value)
            {
                case string s:
                    return s.ToLower(); // Text, Lookup name

                case DateTime dt:
                    return dt; // Date, DateTime

                case int i:
                    return i; // Integer, Picklist

                case decimal d:
                    return d; // Decimal

                case double db:
                    return db; // Float

                case bool b:
                    return b.ToString(); // Two Option

                case Money m:
                    return m.Value; // Currency

                case OptionSetValue osv:
                    return osv.Value; // Option Set

                case EntityReference er:
                    return er.Name?.ToLower(); // Lookup

                default:
                    return value.ToString();
            }
        }
        private QueryExpression getQuery(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService orgService)
        {

            QueryExpression query = null;

            // Method 1: Direct QueryExpression
            if (context.InputParameters.Contains("Query") &&
              context.InputParameters["Query"] is QueryExpression)
            {
                query = (QueryExpression)context.InputParameters["Query"];
                tracingService.Trace("Query found as QueryExpression.");
            }

            // Method 2: FetchXml — convert to QueryExpression
            else if (context.InputParameters.Contains("Query") &&
              context.InputParameters["Query"] is FetchExpression)
            {

                var fetchXml = ((FetchExpression)context.InputParameters["Query"]).Query;

                tracingService.Trace("Query found as FetchXml: {0}", fetchXml);

                //var orgServiceFactory = (IOrganizationServiceFactory)serviceProvider
                //  .GetService(typeof(IOrganizationServiceFactory));
                //var orgService = orgServiceFactory.CreateOrganizationService(context.UserId);
                var cc = new FetchXmlToQueryExpressionRequest
                {
                    FetchXml = fetchXml,
                };
                var cRes = (FetchXmlToQueryExpressionResponse)orgService.Execute(cc);
                query = cRes.Query;
                //query = ((QueryExpressionResponse)orgService.Execute(
                //  new FetchXmlToQueryExpressionRequest { FetchXml = fetchXml }
                //)).Query;
            }

            // Method 3: Wrapped in RetrieveMultipleRequest
            else if (context.InputParameters.Contains("Request"))
            {
                var request = context.InputParameters["Request"] as RetrieveMultipleRequest;
                if (request?.Query is QueryExpression qe)
                {
                    query = qe;
                    tracingService.Trace("Query found inside RetrieveMultipleRequest.");
                }
            }

            if (query == null)
            {
                // Log all available parameters for debugging
                tracingService.Trace("Available InputParameters:");
                foreach (var key in context.InputParameters.Keys)
                {
                    tracingService.Trace(" - Key: {0}, Type: {1}",
                      key, context.InputParameters[key]?.GetType()?.Name ?? "null");
                }
                throw new InvalidPluginExecutionException("Could not resolve Query from input parameters.");
            }
            return query;
        }
       
       
       

        



        #region Printout

        
        #endregion
    }
}

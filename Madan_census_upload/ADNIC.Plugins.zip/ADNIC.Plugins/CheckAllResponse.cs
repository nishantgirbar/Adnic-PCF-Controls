﻿namespace ADNIC.Plugins
{
    public class CheckAllResponse
    {
        public int PolicyId { get; set; }
        public string CocJobId { get; set; }
        public string PpJobId { get; set; }
        public string Status { get; set; }
        public string CocStatus { get; set; }
        public string PpStatus { get; set; }
    }
}

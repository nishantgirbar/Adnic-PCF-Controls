/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    DisplayHeader: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    HeaderText: ComponentFramework.PropertyTypes.StringProperty;
    DisplaySearch: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    DisplayPagination: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    EmptyMessage: ComponentFramework.PropertyTypes.StringProperty;
    SelectionMode: ComponentFramework.PropertyTypes.StringProperty;
    AllowSorting: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    AllowFiltering: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    IsEnabled: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    FieldConfigurations: ComponentFramework.PropertyTypes.StringProperty;
    DataSource: ComponentFramework.PropertyTypes.DataSet;
}
export interface IOutputs {
}

import * as React from "react";
import { PrimaryButton,DefaultPalette, Stack, IStackStyles, IStackTokens, MessageBar, MessageBarType } from "@fluentui/react";
import { ButtonStyle, itemStyles, numericalSpacingStackTokens, sectionStackTokens, SpanStyle, stackStyles, TopStackStyle } from "../css/styles";


export interface IFileUploadProps {
    onFileSelected: (file: File) => Promise<ApiResponse|string| null|undefined>
}

export const FileUpload: React.FC<IFileUploadProps> = ({
    onFileSelected
}) => {

    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const [fileName, setFileName] = React.useState<string>("");
    const [validationMsgs, setValidationMsgs] = React.useState<string>("");
    const [validationMsgs1, setValidationMsgs1] = React.useState<string[]>();
    
    // React.useEffect(() => {
    //     console.log("Component mounted");

    //     // initialization code
    //    const mm:string[]=["sdfjsdfhjsfh","sfjsgfjsdgfjsdgfjsd","shdgsjghsgfyerwetrwte"];
    //   //setValidationMsgs1(mm);

    // }, []);

    const setErrorMessage=(msg:string)=>{
        const erro_msg=[msg];
        setValidationMsgs1(erro_msg);
    }
    const handleChange =async (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        if (file) {
            setFileName(file.name);
            setValidationMsgs1([]);

           const api_response=await onFileSelected(file);
            const file_input=  event.target as HTMLInputElement;
          file_input.value="";

          if(typeof api_response ==="string"){
            if(api_response==="FileSize_Error"){
                setValidationMsgs1(["File size exceeded max file size."]);
            }
            else{
             setValidationMsgs1(["There is an error while processing the request."]);
            }
          }
          else{
          if(api_response!==null && api_response!==undefined){
          //const error_strings=  api_response.errors?.join("\n")??"";
            setValidationMsgs1(api_response.errors);
          }
        }
        }
    };

    return (
        <Stack enableScopedSelectors tokens={sectionStackTokens}>

      <Stack enableScopedSelectors verticalAlign="baseline" disableShrink horizontalAlign="space-between">
        <Stack enableScopedSelectors>
         
          <Stack enableScopedSelectors horizontal styles={stackStyles} tokens={numericalSpacingStackTokens}>
           <span style={SpanStyle}> Click here to upload a Document <br/> Upload files limit size 2MB</span>
             <PrimaryButton
                text="Click to Upload"
                onClick={() => fileInputRef.current?.click()}
                style={ButtonStyle}
            />
            
            {fileName && (
            <span style={SpanStyle} >
                 {fileName}
            </span>
                )}

                

            <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleChange}
                ref={fileInputRef}
                 style={{ display: "none" }}
            />
            </Stack>

            {validationMsgs1 && validationMsgs1.map((msg,index)=>{
            return (
                <MessageBar
                key={index}
                    messageBarType={
                         MessageBarType.error
                    }
                    onDismiss={() => {
                        setValidationMsgs1(prev=>prev?.filter((_,i)=>i!==index));
                    }
                    }
                    dismissButtonAriaLabel="Close">
                    {msg}
                </MessageBar>
            )
        })
        }
        </Stack>
        </Stack>
        </Stack>
       
    );
};
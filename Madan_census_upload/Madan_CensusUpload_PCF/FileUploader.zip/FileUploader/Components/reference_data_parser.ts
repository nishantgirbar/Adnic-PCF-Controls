import { Benefit, BenefitValue, Category, LookupValue, LookupValues, MasterDataResponse, MedicalQuestion, NetworkProvider, NetworkType, Product } from "./Reference_data";

export class MasterDataParser {

    private _data: MasterDataResponse;

    public parse(jsonString: string): MasterDataResponse {
        try {
            this._data = JSON.parse(jsonString) as MasterDataResponse;
            console.log("Master data parsed successfully.");
            console.log("Products:", this._data.products?.length);
            console.log("Benefits:", this._data.benefits?.length);
            console.log("Network Providers:", this._data.networkProviders?.length);
            return this._data;
        }
        catch (error) {
            console.error("Failed to parse master data:", error);
            throw new Error(`MasterData parse error: ${error}`);
        }
    }

    public getBusinessNatures(): LookupValue[] {
        return this._data?.lookupValues?.BUSINESS_NATURE ?? [];
    }

    public getCategories(): LookupValue[] {
        return this._data?.lookupValues?.CATEGORY ?? [];
    }

    public getCityEmirates(): LookupValue[] {
        return this._data?.lookupValues?.CITY_EMIRATES ?? [];
    }

    public getCommissions(): LookupValue[] {
        return this._data?.lookupValues?.COMMISSION ?? [];
    }

    public getDocumentCategories(): LookupValue[] {
        return this._data?.lookupValues?.DOCUMENT_CATEGORY ?? [];
    }

    public getGenders(): LookupValue[] {
        return this._data?.lookupValues?.GENDER ?? [];
    }

    public getMaritalStatuses(): LookupValue[] {
        return this._data?.lookupValues?.MARITAL_STATUS ?? [];
    }

    public getQuoteStates(): LookupValue[] {
        return this._data?.lookupValues?.QUOTE_STATE ?? [];
    }

    public getRelations(): LookupValue[] {
        return this._data?.lookupValues?.RELATION ?? [];
    }

    public getSalaryTypes(): LookupValue[] {
        return this._data?.lookupValues?.SALARY_TYPE ?? [];
    }

    public getSourceOfBusiness(): LookupValue[] {
        return this._data?.lookupValues?.SOURCE_OF_BUSINESS ?? [];
    }

    public getVisaLocations(): LookupValue[] {
        return this._data?.lookupValues?.VISA_LOCATION ?? [];
    }

    public getLookupByCode(
        category: keyof LookupValues,
        code: string): LookupValue | undefined {

        return this._data?.lookupValues?.[category]
            ?.find(v => v.code === code);
    }

    public getDisplayValue(
        category: keyof LookupValues,
        code: string): string {

        return this.getLookupByCode(category, code)
            ?.displayValue ?? code;
    }

    public getProducts(): Product[] {
        return this._data?.products ?? [];
    }

    public getProductByCode(code: string): Product | undefined {
        return this._data?.products
            ?.find(p => p.productCode === code);
    }

    public getNetworkProviders(): NetworkProvider[] {
        return this._data?.networkProviders ?? [];
    }

    public getNetworkProvidersByProduct(productId: number): NetworkProvider[] {
        return this._data?.networkProviders
            ?.filter(p => p.productId === productId) ?? [];
    }

    public getNetworkProviderById(id: number): NetworkProvider | undefined {
        return this._data?.networkProviders
            ?.find(p => p.id === id);
    }

    public getNetworkTypes(): NetworkType[] {
        return this._data?.networkTypes ?? [];
    }

    public getNetworkTypesByProvider(providerId: number): NetworkType[] {
        return this._data?.networkTypes
            ?.filter(n => n.networkProviderId === providerId) ?? [];
    }
    public getBenefits(): Benefit[] {
        return this._data?.benefits ?? [];
    }

    public getBenefitByCode(code: string): Benefit | undefined {
        return this._data?.benefits
            ?.find(b => b.code === code);
    }

    public getBenefitValues(code: string): BenefitValue[] {
        return this.getBenefitByCode(code)?.values ?? [];
    }

    // Specific benefit helpers
    public getAnnualLimits(): BenefitValue[] {
        return this.getBenefitValues("ANNUAL_LIMIT");
    }

    public getMaternityValues(): BenefitValue[] {
        return this.getBenefitValues("MATERNITY");
    }

    public getDeductibleValues(): BenefitValue[] {
        return this.getBenefitValues("DEDUCTIBLE");
    }

    public getCopaymentValues(): BenefitValue[] {
        return this.getBenefitValues("CO_PAYMENT");
    }

    public getDentalValues(): BenefitValue[] {
        return this.getBenefitValues("DENTAL");
    }

    public getOpticalValues(): BenefitValue[] {
        return this.getBenefitValues("OPTICAL");
    }

    public getPharmacyValues(): BenefitValue[] {
        return this.getBenefitValues("PHARMACY");
    }

    public getMedicalQuestions(): MedicalQuestion[] {
        return this._data?.medicalQuestions ?? [];
    }

    public getMedicalQuestionsByCategory(category: "LEFT" | "RIGHT"): MedicalQuestion[] {
        return this._data?.medicalQuestions
            ?.filter(q => q.category === category)
            ?.sort((a, b) => a.displayOrder - b.displayOrder) ?? [];
    }

    public getPolicyCategories(): Category[] {
        return this._data?.categories ?? [];
    }
    public toDropdownOptions(
        items: LookupValue[]): { key: string; text: string }[] {

        return items
            .sort((a, b) => a.sortOrder - b.sortOrder)
            .map(item => ({
                key:  item.code,
                text: item.displayValue
            }));
    }

    public toBenefitDropdownOptions(
        values: BenefitValue[]): { key: number; text: string }[] {

        return values.map(v => ({
            key:  v.id,
            text: v.value
        }));
    }
}
interface Member {
    rowNumber: number;
    memberName: string;
    pfNo: string;
    dateOfBirth: string;
    gender: string;
    relation: string;
    dependency: string;
    emiratesId: string;
    nationality: string;
    passportNo: string;
    recordStatus: string;
    validationErrors: string[];
    effectiveDate: string;
    visaLocation: string;
    memberCategory: string;
    
}

interface MismatchedMember {
    member: Member;
    matchStatus: string;
    matchReasons: string[];
}

interface MatchedMember {
    member: Member;
    matchStatus: string;
    matchReasons: string[];
}

interface ApiResponse {
    members: Member[];
    matchedMembers: MatchedMember[];
    mismatchedMembers: MismatchedMember[];
    errors: string[];
    warnings: string[];
    summary: {
        totalUploadedMembers: number;
        matchedMembersCount: number;
        mismatchedMembersCount: number;
        validationErrorCount: number;
        validationWarningCount: number;
    };
    valid: boolean;
}
export interface LookupValue {
    id:           number;
    category:     string;
    code:         string;
    displayValue: string;
    sortOrder:    number;
    requiresUw:   boolean;
}

export interface MedicalQuestion {
    id:           number;
    question:     string;
    category:     string;
    displayOrder: number;
}

export interface Product {
    id:          number;
    productName: string;
    productCode: string;
}

export interface NetworkProvider {
    id:        number;
    code:      string;
    name:      string;
    productId: number;
}

export interface NetworkType {
    id:                number;
    code:              string;
    name:              string;
    networkProviderId: number;
}

export interface BenefitValue {
    id:        number;
    value:     string;
    benefitId: number;
}

export interface Benefit {
    id:     number;
    name:   string;
    code:   string;
    values: BenefitValue[];
}

export interface Category {
    id:   number;
    name: string;
}

export interface LookupValues {
    BUSINESS_NATURE:          LookupValue[];
    CATEGORY:                 LookupValue[];
    CITY_EMIRATES:            LookupValue[];
    COMMISSION:               LookupValue[];
    DOCUMENT_CATEGORY:        LookupValue[];
    EBP_ANNUAL_LIMIT_MAP:     LookupValue[];
    EBP_ECARE_PLAN_TIER:      LookupValue[];
    EBP_ECARE_THRESHOLD:      LookupValue[];
    EBP_FMC_PLAN_TIER:        LookupValue[];
    EBP_FMC_THRESHOLD:        LookupValue[];
    EBP_NETWORK_TYPE_MAP:     LookupValue[];
    EBP_SALARY_TYPE:          LookupValue[];
    GENDER:                   LookupValue[];
    MARITAL_STATUS:           LookupValue[];
    QUOTE_STATE:              LookupValue[];
    RELATION:                 LookupValue[];
    SALARY_TYPE:              LookupValue[];
    SOURCE_OF_BUSINESS:       LookupValue[];
    VISA_LOCATION:            LookupValue[];
}

export interface MasterDataResponse {
    lookupValues:     LookupValues;
    medicalQuestions: MedicalQuestion[];
    productDetails:   unknown[];
    products:         Product[];
    networkProviders: NetworkProvider[];
    networkTypes:     NetworkType[];
    benefits:         Benefit[];
    networkBenefits:  unknown[];
    categories:       Category[];
}
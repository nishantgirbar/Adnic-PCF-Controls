import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as ReactDOM from "react-dom";
import { FileUpload } from "./Components/FileUpload";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { MasterDataParser } from "./Components/reference_data_parser";
import { LookupValue } from "./Components/Reference_data";


export class FileUploader implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container: HTMLDivElement;
    private fileInput: HTMLInputElement;
    private notifyOutputChanged: () => void;
    private uploadedContent = "";
    private uploadedFileContent = "";
    private root!: Root;
    private apiResponse: string;
    private _context: ComponentFramework.Context<IInputs>;
     private _state:ComponentFramework.Dictionary;
     private _finalResponse:string="";

    /**
     * Empty constructor.
     */
    constructor() {
        // Empty
    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        // Add control initialization code
        this._context = context;
        this.container = container;
        this._state=state;
        
        this.notifyOutputChanged = notifyOutputChanged;
        this.root = createRoot(container);
        this.onUpload = this.onUpload.bind(this);
        this.getEnvironmentalVariables = this.getEnvironmentalVariables.bind(this);
    }
    private renderControl(): void {

        this.root.render(React.createElement(FileUpload, {
            onFileSelected: this.onUpload
        }));
    }

    
    private getEnvironmentalVariables = async (schemaname: string): Promise<string> => {
        let finalValue = "";
        const result = await this._context.webAPI.retrieveMultipleRecords(
            "environmentvariabledefinition",
            `?$select=schemaname
      &$filter=schemaname eq '${schemaname}'
      &$expand=environmentvariabledefinition_environmentvariablevalue($select=value)`
        );

        if (result.entities.length > 0) {
            const envVar = result.entities[0];

            const values = envVar.environmentvariabledefinition_environmentvariablevalue;

            if (values && values.length > 0) {
                const value = values[0].value;
                finalValue = value;
                console.log(value);
            }
        }
        console.log(finalValue);
        return finalValue;
    }


    private getReferenceData= async ():Promise<void>=>{
        const reference_data_url = await this.getEnvironmentalVariables("adnic_ReferenceData");

        console.log(reference_data_url);

        const inputData = {
                method: "GET",
            }

        const response = await fetch(reference_data_url, inputData);

            if (!response.ok) {
                const errorText = await response.text();
                console.error("fetching reference data failed:", errorText);
                this.apiResponse = `Error: ${response.status}`;
                return;
            }

            const data = await response.json();

            const reference_data=new MasterDataParser();

            const masterData= reference_data.parse(data);
           const genderValues= reference_data.getGenders();
           const martialValues= reference_data.getMaritalStatuses();
           const emirateValues= reference_data.getCityEmirates();

           this.pushDataToCRM(genderValues);
           this.pushDataToCRM(martialValues);
           this.pushDataToCRM(emirateValues);
           
            //}

           
        
    }

    private pushDataToCRM= async (masterValues:LookupValue[]):Promise<void>=>{

        for (let index = 0; index < masterValues.length; index++) {
            
            const element = masterValues[index];
           const ref_rec_guid=  await this.getExistingReferenceRecord(element.code,element.displayValue,element.category);

        //     if(ref_rec_guid!==null){
        //          const entity_data: ComponentFramework.WebApi.Entity = {
        //             "adnic_key": element.code,
        //             "adnic_value": element.displayValue,
        //             "adnic_name": element.code,
        //             "adnic_type":element.category
        //         };

        // console.log("Updating record with data:", entity_data);

        // const result = await this._context.webAPI.updateRecord("adnic_refernce_data",ref_rec_guid, entity_data);
        //     }else{
            if(ref_rec_guid===null){
                const entity_data: ComponentFramework.WebApi.Entity = {
                    "adnic_key": element.code,
                    "adnic_value": element.displayValue,
                    "adnic_name": element.code,
                    "adnic_type":element.category
                };

        console.log("Saving record with data:", entity_data);

        const result = await this._context.webAPI.createRecord("adnic_refernce_data", entity_data);
            }
        }
    }
        private onUpload = async (file: File): Promise<ApiResponse|string| null|undefined> => {
            
        try {
            console.log("Deleting census data");
            const policyEntityId = (this._context.mode as any).contextInfo.entityId;
            const maxFileSizeInBytes=2*1024*1024; //2MB

            if(file.size>maxFileSizeInBytes){
                return "FileSize_Error";
            }
            await this.deleteExistingMembers(policyEntityId);
            await this.deleteExistingMembers_PPCOC(policyEntityId);  

           const policy_number=  await this.getCurrentPolicyRecord(policyEntityId);
            const serviceUrl = await this.getEnvironmentalVariables("adnic_census_upload_url");
            console.log(serviceUrl);
            console.log(`Policy number ${policy_number}`);

            if (!serviceUrl) {
                console.log("Service url not found");
                return null;
            }

             if (policy_number==="" || policy_number===null) {
                console.log("Policy number is empty.");
                return null;
             }

            const formData = new FormData();
            formData.append("file", file, file.name);
            formData.append("policyId", policy_number);

            const inputData = {
                method: "POST",
                body: formData,
            }

            const response = await fetch(serviceUrl, inputData);

            if (!response.ok) {
                const errorText = await response.text();
                console.error("Upload failed:", errorText);
                this.apiResponse = `Error: ${response.status}`;
                // this.notifyOutputChanged();
                  
                return  this.apiResponse;
            }

            const data = await response.json();

            console.log("API Response:", data);
            this.apiResponse = JSON.stringify(data);
            this.saveRecord(policy_number, this.apiResponse);
            const jsonObj = this.parseApiResponse(this.apiResponse);
            this._finalResponse="Success";
            this.notifyOutputChanged();
            return jsonObj;
            //this.createRecordForValidation();
            
        }
        catch (e) {
            console.log(e);
            this._finalResponse="Error";
            this.notifyOutputChanged();
        }
        return null;
    }

    private async saveRecord(
        policy_number:string,
        jsonResponse: string): Promise<void> {

        //const policyEntityName = 
        const policyEntityId = (this._context.mode as any).contextInfo.entityId;
        const policyEntityName = (this._context.mode as any).contextInfo.entityTypeName;

        // [`adnic_policy_id@odata.bind`]: 
        //             `/${policyEntityName}s(${policyEntityId})`,
        const data: ComponentFramework.WebApi.Entity = {
            "adnic_json_string": jsonResponse,
            "adnic_policy_guid": policyEntityId,
            "adnic_name": "CensusUpload",
            "adnic_policyid": policy_number,
            "adnic_source": "PolicyIssuance"
        };

        console.log("Saving record with data:", data);

        const result = await this._context.webAPI.createRecord("adnic_external_data", data);
        const jsonObj = this.parseApiResponse(jsonResponse);
        this.insertMembers(jsonObj, policyEntityId);

        console.log("Record saved. ID:", result.id);
    }
   
    private async getExistingReferenceRecord(
        code: string, displayValue:string, category:string): Promise<string | null> {

        try {
            const query = `?$select=adnic_refernce_dataid` +
                `&$filter=adnic_key eq '${code}'` +
                ` and adnic_value eq '${displayValue}'` +
                ` and adnic_type eq '${category}'` +
                `&$top=1`;

            console.log("Checking existing record. Query:", query);

            const result = await this._context.webAPI
                .retrieveMultipleRecords("adnic_refernce_data", query);

            if (result.entities.length > 0) {
                const existingId = result.entities[0]
                ["adnic_refernce_dataid"] as string;
                console.log("Existing record found:", existingId);
                return existingId;
            }

            console.log("No existing record found.");
            return null;
        }
        catch (error) {
            console.error("getExistingRecord error:", error);
            return null;
        }
    }

     private async getCurrentPolicyRecord(policyGuid:string): Promise<string | null> {
       let policy_number:string="";

        try {
            const query = `?$select=adnic_policy_number` +
                `&$filter=adnic_policyid eq '${policyGuid}'`;
              

            console.log("Checking existing record. Query:", query);

            const result = await this._context.webAPI
                .retrieveMultipleRecords("adnic_policy", query);

            if (result.entities.length > 0) {
                const policy_no = result.entities[0]
                ["adnic_policy_number"] as string;
                console.log("Existing policy number found:", policy_no);
                policy_number=policy_no;
            }

            console.log("No existing record found.");
            
        }
        catch (error) {
            console.error("getExistingRecord error:", error);
        }

        return policy_number;
    }

    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Add code to update control view
        this.renderControl();
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        return {
            uploadResponse:this._finalResponse
        };
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        // Add code to cleanup control if necessary
        //ReactDOM.unmountComponentAtNode(this.container);
        this.root.unmount();
    }

    private parseApiResponse(jsonResponse: string): ApiResponse {
        return JSON.parse(jsonResponse) as ApiResponse;
    }

    private getMatchedMembers(response: ApiResponse): Member[] {
        // matchedMembers array from API
        //return response.matchedMembers || [];
         return (response.matchedMembers || [])
            .map(m => ({
                ...m.member,
                matchStatus: m.matchStatus,
                matchReasons: m.matchReasons
            }));
    }

    private getMismatchedMembers(response: ApiResponse): Member[] {
        // Extract member object from mismatchedMembers
        return (response.mismatchedMembers || [])
            .map(m => ({
                ...m.member,
                matchStatus: m.matchStatus,
                matchReasons: m.matchReasons
            }));
    }

    private getAllMembers(response: ApiResponse): Member[] {
        // All uploaded members regardless of status
        return response.members || [];
    }

    private async insertMembers(
        response: ApiResponse,
        policyGuid: string): Promise<void> {

        const matched = this.getMatchedMembers(response);
        const mismatched = this.getMismatchedMembers(response);

        console.log("Matched members:", matched.length);
        console.log("Mismatched members:", mismatched.length);

        // Insert matched members
        for (const member of matched) {
            await this.insertMemberRecord(
                member, policyGuid, "MATCHED", "");
        }

        // Insert mismatched members
        for (const mm of response.mismatchedMembers) {
            await this.insertMemberRecord(
                mm.member,
                policyGuid,
                "MISMATCHED",
                mm.matchStatus,
            );
        }

        console.log("All members inserted.");
    }

    private async insertMemberRecord(
        member: Member,
        policyGuid: string,
        matchType: string,
        matchStatus: string): Promise<void> {

        const data: ComponentFramework.WebApi.Entity = {
            // Lookup to Policy
            "adnic_policy_id@odata.bind":
                `/adnic_policies(${policyGuid})`,

            "adnic_name": member.memberName,
            "adnic_pf_no": member.pfNo,
            "adnic_is_matched": matchType === "MATCHED",
        };

        try {
            const result = await this._context.webAPI.createRecord("adnic_census_data", data);
            console.log(`Inserted ${matchType} — ${member.memberName}:`,
                result.id);
        }
        catch (error) {
            console.error(error);

        }
    }
    private async deleteExistingMembers(policyGuid: string): Promise<void> {
        try {
            const query = `?$select=adnic_census_dataid` +
                `&$filter=_adnic_policy_id_value eq '${policyGuid}'`;

            const existing = await this._context.webAPI
                .retrieveMultipleRecords("adnic_census_data", query);

            console.log("Deleting existing records:", existing.entities.length);

            for (const record of existing.entities) {
                await this._context.webAPI.deleteRecord(
                    "adnic_census_data",
                    record["adnic_census_dataid"] as string);
            }

            console.log("Existing records deleted.");
        }
        catch (error) {
            console.log(error);
        }
    }

     private async deleteExistingMembers_PPCOC(policyGuid: string): Promise<void> {
        try {
            const query = `?$select=adnic_pp_coc_checkid` +
                `&$filter=_adnic_policy_id_value eq '${policyGuid}'`;

            const existing = await this._context.webAPI
                .retrieveMultipleRecords("adnic_pp_coc_check", query);

            console.log("Deleting existing records:", existing.entities.length);

            for (const record of existing.entities) {
                await this._context.webAPI.deleteRecord(
                    "adnic_pp_coc_checkid",
                    record["adnic_pp_coc_checkid"] as string);
            }

            console.log("Existing COC PP records deleted.");
        }
        catch (error) {
            console.log(error);
        }
    }

}

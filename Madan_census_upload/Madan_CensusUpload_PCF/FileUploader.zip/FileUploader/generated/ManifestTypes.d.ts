/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    uploadedFile: ComponentFramework.PropertyTypes.StringProperty;
    uploadResponse: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    uploadedFile?: string;
    uploadResponse?: string;
}

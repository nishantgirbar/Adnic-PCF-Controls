/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    Validator: ComponentFramework.PropertyTypes.StringProperty;
    ValidatorResponse_: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    Validator?: string;
    ValidatorResponse_?: string;
}

import * as React from "react";
import { useState } from "react";
import {
    Stack,
    Label,
    DefaultButton,
    PrimaryButton,
    IStackStyles,
    IStackTokens,
    IButtonStyles,
    Spinner,
    SpinnerSize,
    MessageBar,
    MessageBarType,
    ITextStyles
} from "@fluentui/react";

export interface ICensusValidatorProps {
    label: string;
    buttonText: string;
    isDisabled?: boolean;
    onButtonClick: () => Promise<void>;
}

export const CensusPPCheck: React.FC<ICensusValidatorProps> = (props) => {

    const [isLoading, setIsLoading] = useState(false);
    const [message,   setMessage]   = useState<string | null>(null);
    const [isError,   setIsError]   = useState(false);

    // ─────────────────────────────────────────────────────────────
    // STYLES
    // ─────────────────────────────────────────────────────────────

    const line1Styles: ITextStyles = {
        root: {
            fontSize:   14,
            fontWeight: 600,
            color:      "#323130",
            display:    "block",
            textAlign:  "left"
        }
    };

    const line2Styles: ITextStyles = {
        root: {
            fontSize:  12,
            color:     "#605e5c",
            display:   "block",
            textAlign: "left",
            //marginTop: 4
        }
    };

    const containerStyles: IStackStyles = {
        root: {
            width:      "auto",
            // padding:    "8px 12px",
            background: "#ffffff",
            // border:     "0px solid #edebe9",
            // borderRadius: 0
        }
    };

    const labelRowStyles: IStackStyles = {
        root: {
            width:      "100%",
            padding:    "4px 0"
        }
    };

    const buttonRowStyles: IStackStyles = {
        root: {
            width:      "auto",
            // padding:    "8px 0 4px 0",
            margin:"20px 0 0 0"
            
        }
    };

    const buttonStyles: IButtonStyles = {
        root: {
            minWidth:     120,
            borderRadius: 2
        }
    };

    const stackTokens: IStackTokens = {
        childrenGap: 8
    };

    // ─────────────────────────────────────────────────────────────
    // HANDLERS
    // ─────────────────────────────────────────────────────────────

    const handleButtonClick = async (): Promise<void> => {
        try {
            setIsLoading(true);
            setMessage(null);
            setIsError(false);

            await props.onButtonClick();

            //setMessage("Operation completed successfully.");
            setIsError(false);
        }
        catch (error) {
            console.error("Button click error:", error);
            setMessage("Operation failed. Please try again.");
            setIsError(true);
        }
        finally {
            setIsLoading(false);
        }
    };

    // ─────────────────────────────────────────────────────────────
    // RENDER
    // ─────────────────────────────────────────────────────────────

    return (
        <Stack styles={containerStyles} tokens={stackTokens}>

            {/* Row 1 — Label */}
             {/* <Stack styles={labelRowStyles}>
                <Label  styles={line2Styles}>
                    Info:
                    </Label>
                <Label styles={line2Styles}>
                    Member Count Difference Between Quote And Policy Exceeds 10%. Please Either Delete The Additional Members Or Regenerate The Quote With The Complete Member List And Obtain Signed Approval From The Insured.
                </Label>
            </Stack> */}

            {/* Message Bar */}
            {message && (
                <MessageBar
                    messageBarType={
                        isError
                            ? MessageBarType.error
                            : MessageBarType.success
                    }
                    onDismiss={() => setMessage(null)}
                    dismissButtonAriaLabel="Close">
                    {message}
                </MessageBar>
            )}

            {/* Row 2 — Button right aligned */}
            <Stack
                styles={buttonRowStyles}
                horizontal
                horizontalAlign="start">

                {isLoading ? (
                    <Spinner size={SpinnerSize.small} label="Processing..." />
                ) : (
                    
                    
                    <PrimaryButton
                        text={props.buttonText}
                        styles={buttonStyles}
                        disabled={props.isDisabled || isLoading}
                        onClick={handleButtonClick}
                    />
                    
                )}

            </Stack>

        </Stack>
    );
};